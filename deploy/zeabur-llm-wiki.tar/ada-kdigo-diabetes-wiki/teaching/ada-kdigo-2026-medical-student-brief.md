---
title: ADA-KDIGO 2026 Medical Student Brief
type: teaching
created: 2026-05-19
updated: 2026-05-20
tags: [output, teaching, medical-students, diabetes, ckd, ada, kdigo]
sources:
  - ../guidelines/ada-standards-of-care-2026.md
  - ../guidelines/kdigo-diabetes-management-in-ckd-2026.md
evidence_level: guideline
clinical_use: teaching
confidence: medium
last_verified: 2026-05-19
status: draft
obsidian_type: output
aliases:
  - ADA KDIGO medical student teaching
  - ADA KDIGO 2026 student brief
  - diabetes CKD teaching brief
  - organ-centric care teaching
  - medical student diabetes guideline summary
  - 醫學生 ADA KDIGO 教學
  - 糖尿病 CKD 醫學生重點
  - older adults diabetes teaching
  - pregnancy diabetes teaching
  - hypoglycemia teaching
  - steroid hyperglycemia teaching
entities:
  - ADA 2026
  - KDIGO 2026
  - medical students
  - diabetes
  - CKD
  - A1C
  - CGM
  - SGLT2 inhibitor
  - GLP-1 receptor agonist
  - eGFR
  - UACR
  - hypoglycemia
  - older adults
  - pregnancy
  - steroid hyperglycemia
  - metformin
  - finerenone
  - organ-centric diabetes care
owner_agent: hermes
write_policy: hermes-maintained
---

# ADA-KDIGO 2026 Medical Student Brief

## One-Sentence Frame

Modern diabetes care is not only "lower the A1C"; it is risk-based care that protects the heart, kidney, eyes, nerves, weight, pregnancy outcomes, older-adult function, and daily quality of life.

## Starter Teaching Flow

1. Classify diabetes and assess comorbidities.
2. Set glycemic goals while considering hypoglycemia and patient burden.
3. Add technology when it improves monitoring, safety, or self-management.
4. Treat obesity and cardiometabolic risk as part of diabetes care.
5. Screen and manage CKD risk using kidney-specific guidance.
6. Choose medications based on glycemia, cardiovascular risk, kidney risk, weight, safety, and access.

## Links

- [[../guidelines/ada-standards-of-care-2026]]
- [[../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[../concepts/organ-centric-diabetes-care]]
- [[../concepts/diabetes-ckd-risk-stratification]]

## Caveat

This is a teaching scaffold. Before using it as a slide deck or clinical handout, extract the exact ADA and KDIGO recommendation wording into source-grounded cards.
