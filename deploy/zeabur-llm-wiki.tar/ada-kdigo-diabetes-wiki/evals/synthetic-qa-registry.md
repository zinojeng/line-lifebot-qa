---
title: ADA-KDIGO Synthetic QA Registry
type: workflow
created: 2026-05-20
updated: 2026-05-22
tags: [synthetic-qa, regression, line-qa, llm-wiki, hermes]
sources:
  - docs/llm-wiki-self-improvement-loop.md
  - reports/wiki-self-improvement-audit.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-22
status: active
obsidian_type: registry
aliases:
  - synthetic QA registry
  - answer regression tests
  - LINE QA evals
entities:
  - Hermes Agent
  - LINE QA
owner_agent: hermes
write_policy: hermes-maintained
summary: "ADA-KDIGO Synthetic QA Registry Synthetic QA is not clinical truth. It is a maintenance tool: generate likely LINE questions from existing pages, run retrieval checks, and convert repeated failures into aliases, topic-ma..."
related: []
---

# ADA-KDIGO Synthetic QA Registry

Synthetic QA is not clinical truth. It is a maintenance tool: generate likely
LINE questions from existing pages, run retrieval checks, and convert repeated
failures into aliases, topic-map routes, claim cards, or research requests.

Related pages: [[../docs/llm-wiki-self-improvement-loop]],
[[../_meta/typed-relationships]], [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]].

## Initial High-Value Test Families

| family | example user question | must route to |
|---|---|---|
| CKD recommendation grade | 58歲第二型糖尿病 eGFR 42 UACR 380，ADA/KDIGO 哪些是 strong recommendation，哪些證據等級較低？ | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| GDM pharmacotherapy evidence | Metformin in GDM evidence | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| Retinopathy treatment evidence grade | 嚴重眼病變治療 證據等級是？ | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| Neuropathy medication evidence grade | 糖尿病神經病變藥物的證據等級是？ | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| SGLT2i eGFR threshold | 排糖藥 eGFR 小於 20 還沒洗腎可以繼續嗎？ | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| GLP-1 dialysis | 洗腎病人可以用 GLP-1RA 嗎？ | [[../drugs/glp1-based-therapy-on-dialysis]] |
| Bone health | 糖尿病與骨質疏鬆，治療是否與一般人不同？ | [[../concepts/diabetes-bone-health-osteoporosis]] |
| GLP-1 muscle loss | GLP1 減重後 SMI 降低、握力下降，我會不會肌少症？ | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |

## Promotion Rule

Promote a synthetic QA item into `scripts/retrieval_smoke_tests.py` only when it
guards a common LINE wording, a prior failure, or a clinically important routing
behavior. Keep pure brainstorming questions in reports instead of production
tests.

## Exclusion Rule

Do not generate routine LINE regression cases from root operating files such as
[[../HERMES]], [[../SCHEMA]], [[../index]], and [[../log]]. These files remain
retrievable through the wiki index and graph, but synthetic QA should focus on
clinical routing, evidence-grade answers, durable MOC behavior, and prior LINE
failure patterns rather than testing bare root-page title lookup.
