---
title: ADA 2026 Bone Health Osteoporosis Claim Registry
type: claim
created: 2026-05-21
updated: 2026-05-21
tags: [ada, diabetes, osteoporosis, bone-health, fracture-risk, claim-registry, line-qa]
sources:
  - concepts/diabetes-bone-health-osteoporosis.md
  - guidelines/ada-standards-of-care-2026.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: medium
last_verified: 2026-05-21
status: active
obsidian_type: registry
aliases:
  - bone health claim registry
  - osteoporosis diabetes claims
  - 骨質疏鬆 claim
entities:
  - ADA 2026 Section 4
  - osteoporosis
  - fracture risk
  - DXA
  - BMD
  - T-score
  - FRAX
  - TZD
  - sulfonylureas
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware claim page for ADA 2026 Bone Health Osteoporosis Claim Registry; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 2 listed source(s) before changing recommendations."
related: 
  - "concepts/diabetes-bone-health-osteoporosis"
  - "_meta/typed-relationships"
  - "evidence-ledger/bone-health-osteoporosis-ledger"
  - "guidelines/ada-standards-of-care-2026"
  - queries/bone-glp1-muscle-line-questions
---

# ADA 2026 Bone Health Osteoporosis Claim Registry

Use this page for common LINE questions about diabetes and osteoporosis. It is
derived from [[../concepts/diabetes-bone-health-osteoporosis]] and should be
checked against raw ADA 2026 Section 4 before adding exact recommendation
numbers.

Related pages: [[../concepts/diabetes-bone-health-osteoporosis]],
[[../_meta/typed-relationships]], [[../evidence-ledger/bone-health-osteoporosis-ledger]].

## Claim Cards

| claim_id | source | grade | population | action | answer_role |
|---|---|---|---|---|---|
| `bone-health-routine-risk-assessment-ada-2026` | ADA 2026 Section 4 via concept page | pending exact grade | Older adults with diabetes and younger adults with multiple risk factors | Assess fracture risk as part of routine diabetes care. | Explain that bone health is part of diabetes comprehensive assessment. |
| `bone-health-dxa-bmd-follow-up-ada-2026` | ADA 2026 Section 4 via concept page | pending exact grade | Older adults with diabetes age 65 or older, or younger people with multiple risk factors | Consider DXA/BMD monitoring and repeat assessment interval based on risk. | Mention DXA/BMD without saying every patient needs immediate testing. |
| `bone-health-bmd-frax-underestimate-diabetes` | ADA 2026 Section 4 via concept page | pending exact grade | Especially type 2 diabetes | BMD and FRAX may underestimate fracture risk. | Answer why diabetes evaluation differs from general population. |
| `bone-health-medication-selection-tzd-su` | ADA 2026 Section 4 via concept page | pending exact grade | Diabetes with elevated fracture or fall risk | Consider skeletal effects of glucose-lowering therapy; avoid or use caution with TZD and sulfonylureas when fracture/fall risk is high. | Keep as medication-safety discussion, not patient-directed discontinuation. |
| `bone-health-osteoporosis-drugs-general-population` | ADA 2026 Section 4 via concept page | pending exact grade | Diabetes with osteoporosis or elevated fracture risk | Osteoporosis medication classes are broadly similar to the general population, but risk interpretation differs. | Directly answers "治療是否與一般人不同". |
