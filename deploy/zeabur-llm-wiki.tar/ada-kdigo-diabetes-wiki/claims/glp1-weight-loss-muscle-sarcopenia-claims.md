---
title: GLP-1 Weight Loss Muscle Sarcopenia Claim Registry
type: claim
created: 2026-05-21
updated: 2026-05-21
tags: [glp1, obesity, weight-loss, sarcopenia, muscle, smi, claim-registry, line-qa]
sources:
  - concepts/glp1-weight-loss-muscle-sarcopenia.md
evidence_level: guideline
clinical_use: [clinical-reference, patient-education, teaching, line-qa]
confidence: high
last_verified: 2026-05-21
status: active
obsidian_type: registry
aliases:
  - GLP-1 sarcopenia claims
  - muscle loss claim registry
  - 肌少症 claim
entities:
  - GLP-1 receptor agonist
  - semaglutide
  - tirzepatide
  - SMI
  - handgrip strength
  - chair stand test
  - AWGS 2019
  - EWGSOP2
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware claim page for GLP-1 Weight Loss Muscle Sarcopenia Claim Registry; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 1 listed source(s) before changing recommendations."
related: 
  - "concepts/glp1-weight-loss-muscle-sarcopenia"
  - "concepts/diabetes-bone-health-osteoporosis"
  - "evidence-ledger/glp1-muscle-sarcopenia-ledger"
  - queries/bone-glp1-muscle-line-questions
---

# GLP-1 Weight Loss Muscle Sarcopenia Claim Registry

Use this page when the user asks whether GLP-1-related weight loss, lower SMI,
weaker handgrip, or weak legs means sarcopenia.

Related pages: [[../concepts/glp1-weight-loss-muscle-sarcopenia]],
[[../concepts/diabetes-bone-health-osteoporosis]],
[[../evidence-ledger/glp1-muscle-sarcopenia-ledger]].

## Claim Cards

| claim_id | source | grade | population | action | answer_role |
|---|---|---|---|---|---|
| `sarcopenia-not-diagnosed-by-smi-alone` | AWGS/EWGSOP synthesis via concept page | consensus/guideline synthesis | Adults with low SMI after weight loss | Do not diagnose sarcopenia from SMI alone; assess muscle strength and physical performance. | Main safety line for LINE answers. |
| `sarcopenia-suspect-when-function-declines` | AWGS/EWGSOP synthesis via concept page | consensus/guideline synthesis | Lower SMI plus weaker handgrip, weak legs, slow gait, chair-rise difficulty, or falls | Recommend clinician assessment for sarcopenia and other causes. | Avoid overdiagnosis while validating symptoms. |
| `glp1-weight-loss-can-reduce-lean-mass` | FDA semaglutide review and concept page | regulatory review / clinical-trial substudy | People losing weight with GLP-1-based therapy | Weight loss can reduce lean mass as well as fat mass; function determines clinical concern. | Explain why muscle monitoring matters during weight loss. |
| `glp1-sarcopenia-do-not-stop-without-clinician` | Concept page clinical-safety synthesis | expert synthesis | People on GLP-1 reporting weakness or low intake | Do not stop GLP-1 abruptly without discussing with the prescribing clinician; consider nutrition, resistance training, dose/pace review, and evaluation for other causes. | Patient-safety close. |
