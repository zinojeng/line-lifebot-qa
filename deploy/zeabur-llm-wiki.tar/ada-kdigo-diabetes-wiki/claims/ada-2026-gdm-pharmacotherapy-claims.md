---
title: ADA 2026 GDM Pharmacotherapy Claim Registry
type: claim
created: 2026-05-22
updated: 2026-05-22
tags: [ada, pregnancy, gdm, pharmacotherapy, metformin, glyburide, insulin, claim-registry, line-qa]
sources:
  - evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades.md
  - concepts/diabetes-pregnancy-gdm-cgm.md
  - raw/guidelines/local-guideline-file-registry.md
evidence_level: guideline
clinical_use: [clinical-reference, patient-education, teaching, line-qa]
confidence: high
last_verified: 2026-05-22
status: active
obsidian_type: registry
aliases:
  - GDM pharmacotherapy claims
  - GDM pharmacotherapy
  - Metformin in GDM evidence
  - metformin GDM
  - metformin in gestational diabetes
  - metformin GDM claim
  - gestational diabetes medication
  - diabetes in pregnancy medication
  - pregnancy diabetes medication claims
  - 妊娠糖尿病 metformin
  - 妊娠糖尿病 metformin claim
  - 妊娠糖尿病 口服藥
  - 懷孕糖尿病 用藥
entities:
  - ADA 2026
  - GDM
  - gestational diabetes
  - insulin
  - metformin
  - glyburide
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware claim page for ADA 2026 GDM Pharmacotherapy Claim Registry; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 3 listed source(s) before changing recommendations."
related: 
  - "evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades"
  - "concepts/diabetes-pregnancy-gdm-cgm"
  - "evidence-ledger/gdm-pharmacotherapy-ledger"
  - queries/gdm-pharmacotherapy-line-questions
---

# ADA 2026 GDM Pharmacotherapy Claim Registry

This page turns ADA 2026 Section 15 GDM/diabetes-in-pregnancy pharmacotherapy
recommendations into small claims for LINE routing. Use it when users ask about
metformin, glyburide, insulin, oral agents, or evidence strength in GDM.

Related pages: [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]],
[[../concepts/diabetes-pregnancy-gdm-cgm]],
[[../evidence-ledger/gdm-pharmacotherapy-ledger]].

## Claim Cards

| claim_id | source | grade | population | action | answer_role |
|---|---|---|---|---|---|
| `gdm-lifestyle-first-ada-15-15` | ADA 2026 15.15 | Grade A | GDM | Lifestyle behavior change is essential and may be enough for many; add insulin if needed for glycemic goals. | Start the answer with lifestyle plus insulin escalation when needed. |
| `gdm-insulin-preferred-ada-15-17` | ADA 2026 15.17 GDM clause | Grade A | GDM | Use insulin as the preferred pharmacologic agent. | Main answer for "first-line GDM drug" questions. |
| `pregnancy-metformin-glyburide-not-first-line-ada-15-21a` | ADA 2026 15.21 placenta-crossing clause | Grade A | Diabetes in pregnancy | Metformin/glyburide, individually or in combination, should not be used as first-line agents because both cross the placenta. | Explain why metformin/glyburide are not first-line. |
| `pregnancy-metformin-glyburide-may-not-meet-goals-ada-15-21b` | ADA 2026 15.21 glycemic-sufficiency clause | Grade B | Diabetes in pregnancy | Metformin/glyburide may not be sufficient to achieve glycemic goals. | Add nuance that insulin may be needed to meet targets. |
| `pregnancy-other-noninsulin-agents-not-recommended-ada-15-21e` | ADA 2026 15.21 other-agent clause | Grade E | Diabetes in pregnancy | Other oral and noninsulin injectable glucose-lowering medications lack long-term safety data and are not recommended. | Safety boundary for extrapolated agents. |

## Answer Template For Metformin In GDM

For `Metformin in GDM evidence` or `妊娠糖尿病 metformin`:

- ADA 2026: lifestyle behavior change is essential in GDM; insulin is added if
  needed to meet glycemic goals.
- ADA 2026: insulin is the preferred pharmacologic agent for GDM.
- Metformin/glyburide are not first-line because both cross the placenta.
- Metformin/glyburide may not be sufficient to achieve pregnancy glycemic goals.
- Phrase carefully: not first-line does not mean "never use"; it means use must
  be individualized with the pregnancy care team.

Do not answer "no loaded guideline evidence" if this claim registry or
[[../concepts/diabetes-pregnancy-gdm-cgm]] is retrieved.
