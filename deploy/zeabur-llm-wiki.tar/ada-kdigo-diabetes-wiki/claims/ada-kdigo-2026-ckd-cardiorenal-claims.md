---
title: ADA KDIGO 2026 CKD Cardiorenal Claim Registry
type: claim
created: 2026-05-20
updated: 2026-05-20
tags: [ada, kdigo, diabetes, ckd, claim-registry, recommendation-grade, sglt2i, glp1, finerenone, metformin]
sources:
  - evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades.md
  - /Users/ander/Documents/medical/guidelines/ada/dc26s009.md
  - /Users/ander/Documents/medical/guidelines/ada/dc26s010.md
  - /Users/ander/Documents/medical/guidelines/ada/dc26s011.md
  - /Users/ander/Documents/medical/guidelines/kdigo/KDIGO-2026-Diabetes-and-CKD-Guideline-Update-Public-Review-Draft-March-2026.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-20
status: active
obsidian_type: registry
aliases:
  - claim registry diabetes CKD
  - recommendation claims ADA KDIGO
  - strong recommendation claim map
  - evidence grade claim map
  - 證據等級 claim
  - 建議等級 claim
entities:
  - ADA 2026
  - KDIGO 2026
  - SGLT2 inhibitor
  - GLP-1 receptor agonist
  - finerenone
  - metformin
  - ACE inhibitor
  - ARB
  - CKD
  - eGFR
  - UACR
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware claim page for ADA KDIGO 2026 CKD Cardiorenal Claim Registry; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 5 listed source(s) before changing recommendations."
related: 
  - "evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades"
  - "comparisons/ada-kdigo-2026-evidence-strength-map"
  - "comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd"
  - evidence-ledger/ckd-cardiorenal-ledger
---

# ADA KDIGO 2026 CKD Cardiorenal Claim Registry

This page turns the long evidence card into small, reusable claims. Hermes and
the LINE bot should use it when a user asks "which recommendation is strong?",
"which evidence is lower certainty?", or asks a follow-up like "哪些證據等級較低".

Related pages: [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]],
[[../comparisons/ada-kdigo-2026-evidence-strength-map]],
[[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]].

## Claim Fields

Each claim uses:

- `claim_id`: stable identifier for regression tests and future tool calls.
- `source`: guideline and recommendation number.
- `grade`: ADA grade or KDIGO GRADE strength/certainty.
- `population`: the patient group the claim applies to.
- `action`: concise clinical action.
- `answer_role`: how the answer should phrase the claim.
- `certainty_bucket`: `strong_or_high_certainty`, `moderate`, `lower_certainty`,
  or `practice_point`.

## Strong Or High-Certainty Core Claims

| claim_id | source | grade | population | action | answer_role |
|---|---|---|---|---|---|
| `ckd-sglt2i-initiate-ada-11-7a` | ADA 2026 11.7a | Grade A | T2DM plus CKD | Use an SGLT2 inhibitor with demonstrated benefit when eGFR is at least 20 mL/min/1.73 m2 and continue until kidney failure. | Describe as a strong ADA core recommendation for cardiorenal protection. |
| `ckd-sglt2i-initiate-kdigo-4-3-1` | KDIGO 2026 Recommendation 4.3.1 | 1A | Adults with T2DM, CKD, and eGFR at least 20 mL/min/1.73 m2 | Treat with an SGLT2 inhibitor. | Describe as strong recommendation, high-certainty evidence. |
| `ckd-glp1ra-ada-11-7b` | ADA 2026 11.7b | Grade A | T2DM plus CKD | Use a GLP-1 agonist with demonstrated kidney and cardiovascular benefit. | Describe as strong/high-certainty option, especially when CV/kidney risk or weight is relevant. |
| `ckd-glp1-based-kdigo-4-5-1` | KDIGO 2026 Recommendation 4.5.1 | 1A | T2DM with CKD at high risk of major CV or kidney events, or not at individualized glycemic target | Use a GLP-1-based therapy with proven CV or kidney benefit. | Describe as strong recommendation, high-certainty evidence. |
| `ckd-finerenone-ada-11-8` | ADA 2026 11.8 | Grade A | T2DM plus CKD and albuminuria, with adequate eGFR and potassium monitoring | Use a nonsteroidal MRA shown effective in trials. | Describe as strong add-on when albuminuria persists and criteria fit. |
| `ckd-finerenone-kdigo-4-4-1` | KDIGO 2026 Recommendation 4.4.1 | 1A | T2DM, eGFR at least 25, normal potassium, albuminuria at least 30 mg/g, and maximum tolerated RAS inhibitor | Add nsMRA with proven kidney or CV benefit. | Describe as strong recommendation, high-certainty evidence. |

## Moderate Or Conditional Claims

| claim_id | source | grade | population | action | answer_role |
|---|---|---|---|---|---|
| `ckd-ace-arb-ada-11-6a-uacr-high` | ADA 2026 11.6a | Grade A for UACR at least 300 mg/g and/or eGFR below 60 | Diabetes plus hypertension and albuminuria | Use ACEi or ARB and titrate when indicated. | Strong ADA support when albuminuria is high or eGFR is reduced. |
| `ckd-ace-arb-kdigo-4-2-1` | KDIGO 2026 Recommendation 4.2.1 | 1B | Diabetes, hypertension, and albuminuria | Start ACEi or ARB and titrate to highest approved tolerated dose. | Strong recommendation with moderate-certainty evidence. |
| `ckd-metformin-kdigo-4-6-1` | KDIGO 2026 Recommendation 4.6.1 | 1B | T2DM with CKD and eGFR at least 30 when individualized glycemic targets are not achieved despite SGLT2i and GLP-1-based therapies, or when they cannot be used | Use metformin with eGFR monitoring and dose adjustment; stop below 30 or when dialysis starts. | Useful glycemic medication, not the main cardiorenal-protection priority. |
| `stable-hf-metformin-ada-10-45` | ADA 2026 10.45 | Grade B | T2DM with stable heart failure and eGFR above 30 | Metformin may be continued; avoid in unstable or hospitalized heart failure. | Phrase as conditional/monitoring guidance. |

## Lower-Certainty Or Practice-Point Claims

| claim_id | source | grade | population | action | answer_role |
|---|---|---|---|---|---|
| `sglt2i-continue-under-20-ada-11-11a` | ADA 2026 11.11a | Grade B for CKD progression; Grade C for CV benefits | eGFR below 20 mL/min/1.73 m2 and not on dialysis | SGLT2i can be safely continued if already used and tolerated. | Lower-certainty than initiation guidance; answer as "can continue when tolerated", not "must start". |
| `glp1-dialysis-ada-11-11b` | ADA 2026 11.11b | Grade C | People on dialysis | GLP-1-based therapy not dependent on kidney clearance can be initiated or continued to reduce CV risk and mortality. | Lower-certainty; avoid implying all GLP-1 agents are interchangeable in dialysis. |
| `sglt2i-practical-use-kdigo-4-3-practice-points` | KDIGO 2026 Practice Points 4.3.1-4.3.6 | Practice point | T2DM with CKD using SGLT2i | Withhold during prolonged fasting, major surgery, or critical illness; assess hypovolemia risk; early eGFR dip alone is usually not a stop reason; continuing below eGFR 20 is reasonable unless not tolerated or KRT starts. | Practical safety guidance, not a GRADE recommendation. |
| `hba1c-monitoring-ckd-kdigo-2-1-1` | KDIGO 2026 Recommendation 2.1.1 | 1C | Diabetes with CKD | Use HbA1c to monitor glycemic control; reliability declines in CKD G4-G5 and dialysis; CGM-derived GMI can help when HbA1c mismatches measured glycemia. | Recommended but lower-certainty; mention CKD/dialysis caveat. |
| `combined-sglt2i-glp1ra-ada-10-40d` | ADA 2026 10.40d | Grade B | T2DM with ASCVD/risk factors/CKD where additive event reduction is considered | Combined SGLT2i plus GLP-1RA may additively reduce adverse cardiovascular and kidney events. | Phrase as additive strategy with lower certainty than each individual class recommendation. |
| `simultaneous-sglt2i-finerenone-ada-11-9` | ADA 2026 11.9 | Grade B | Adults with T2DM, UACR at least 100 mg/g, eGFR 30-90, and on RAS inhibitor | Simultaneous initiation of SGLT2i plus finerenone can be considered. | Phrase as "can be considered", not mandatory. |

## Answer Template For Evidence-Grade Follow-Up

When the user asks "哪些證據等級較低?", answer from the lower-certainty section:

- ADA 11.11a continuing SGLT2i below eGFR 20 before dialysis: Grade B for CKD
  progression, Grade C for cardiovascular benefits.
- ADA 11.11b GLP-1-based therapy on dialysis: Grade C.
- KDIGO HbA1c monitoring in CKD: Recommendation 2.1.1 is 1C, and reliability
  declines in CKD G4-G5 and dialysis.
- ADA 10.40d combined SGLT2i plus GLP-1RA and ADA 11.9 simultaneous SGLT2i plus
  finerenone are Grade B; phrase these as conditional or "can be considered".
- KDIGO practice points are practical guidance and usually do not carry a GRADE
  strength/certainty label.

Do not mention AACE unless the user explicitly asks for non-ADA/KDIGO sources and
those sources have been loaded.
