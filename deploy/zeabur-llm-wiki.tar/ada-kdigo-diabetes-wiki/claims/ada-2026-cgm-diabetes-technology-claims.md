---
title: ADA 2026 CGM Diabetes Technology Claim Registry
type: claim
created: 2026-05-21
updated: 2026-05-21
tags: [ada, diabetes-technology, cgm, aid, glycemic-monitoring, claim-registry, line-qa]
sources:
  - concepts/diabetes-technology-cgm-aid.md
  - guidelines/ada-standards-of-care-2026.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: needs-source
last_verified: 2026-05-21
status: needs-source
obsidian_type: registry
aliases:
  - CGM claim registry
  - diabetes technology claims
  - 連續血糖監測 claim
entities:
  - ADA 2026
  - CGM
  - rtCGM
  - isCGM
  - AID
  - BGM
  - TIR
owner_agent: hermes
write_policy: hermes-maintained
---

# ADA 2026 CGM Diabetes Technology Claim Registry

Purpose: split CGM/AID guidance into small claims for LINE routing. This page is
currently a `needs-source` registry because exact ADA 2026 recommendation
numbers and grades still need extraction from raw Section 7 before canonical
clinical use.

Related pages: [[../concepts/diabetes-technology-cgm-aid]],
[[../guidelines/ada-standards-of-care-2026]], [[../evals/synthetic-qa-registry]].

## Draft Claims Awaiting Raw Extraction

| claim_id | source | grade | population | action | answer_role |
|---|---|---|---|---|---|
| `cgm-indication-insulin-therapy-ada-2026-pending` | ADA 2026 Section 7 pending extraction | pending | People with diabetes using insulin therapy | Extract exact CGM recommendation number, grade, and eligible treatment patterns. | Use only as routing until raw source verification is complete. |
| `cgm-hypoglycemia-risk-ada-2026-pending` | ADA 2026 Section 7 pending extraction | pending | People at risk for hypoglycemia or needing glucose-pattern review | Extract exact role of CGM for detecting hypoglycemia and glycemic variability. | Route LINE questions about low sugar, TIR, and CGM metrics. |
| `aid-insulin-delivery-ada-2026-pending` | ADA 2026 Section 7 pending extraction | pending | People using intensive insulin therapy or pump-compatible care | Extract exact AID recommendation and safety framing. | Route AID questions; do not overclaim before extraction. |

## Next Raw Verification Tasks

- Extract ADA 2026 Section 7 recommendation numbers and grades for CGM.
- Extract ADA 2026 Section 7 recommendation numbers and grades for AID.
- Add smoke tests for "CGM 適合哪些病人", "連續血糖監測", "time in range", and "AID".
