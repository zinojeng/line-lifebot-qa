---
title: ADA 2026 Retinopathy Foot PAD Claim Registry
type: claim
created: 2026-05-21
updated: 2026-05-21
tags: [ada, retinopathy, foot-care, pad, complications, claim-registry, research-request]
sources:
  - inbox/research-requests/2026-05-20-self-audit-diabetes-retinopathy-screening-and-follow-up.md
  - inbox/research-requests/2026-05-20-self-audit-diabetes-foot-care-and-pad-risk.md
  - guidelines/ada-standards-of-care-2026.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: needs-source
last_verified: 2026-05-21
status: needs-source
obsidian_type: registry
aliases:
  - retinopathy claims
  - foot care PAD claims
  - 視網膜 claim
  - 糖尿病足 claim
entities:
  - ADA 2026
  - diabetic retinopathy
  - foot care
  - PAD
  - screening
owner_agent: hermes
write_policy: hermes-maintained
---

# ADA 2026 Retinopathy Foot PAD Claim Registry

This is a placeholder registry for two open daily self-improvement requests. Do
not use it as final clinical authority until raw ADA 2026 complications sections
are extracted into exact claim cards.

Related pages: [[../guidelines/ada-standards-of-care-2026]],
[[../inbox/research-requests/2026-05-20-self-audit-diabetes-retinopathy-screening-and-follow-up]],
[[../inbox/research-requests/2026-05-20-self-audit-diabetes-foot-care-and-pad-risk]].

## Draft Claims Awaiting Raw Extraction

| claim_id | source | grade | population | action | answer_role |
|---|---|---|---|---|---|
| `retinopathy-screening-follow-up-ada-2026-pending` | ADA 2026 complications section pending extraction | pending | People with diabetes needing eye screening or follow-up | Extract exact screening interval, referral, and follow-up recommendations. | Route retinopathy questions to research request until source extraction is complete. |
| `foot-care-pad-screening-ada-2026-pending` | ADA 2026 foot care/PAD section pending extraction | pending | People with diabetes needing foot/PAD risk evaluation | Extract exact foot exam, PAD risk, and referral recommendations. | Route foot/PAD questions to research request until source extraction is complete. |

## Next Raw Verification Tasks

- Process retinopathy research request.
- Process foot care/PAD research request.
- Create dedicated concept pages only after raw ADA sections are checked.
