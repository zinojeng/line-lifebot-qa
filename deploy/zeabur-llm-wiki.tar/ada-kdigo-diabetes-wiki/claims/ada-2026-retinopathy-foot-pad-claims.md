---
title: ADA 2026 Retinopathy Foot PAD Claim Registry
type: claim
created: 2026-05-21
updated: 2026-05-21
tags: [ada, retinopathy, foot-care, pad, complications, claim-registry]
sources:
  - concepts/diabetes-retinopathy-screening.md
  - concepts/diabetes-foot-care-pad.md
  - raw/guidelines/ada-standards-of-care-2026-source-map.md
  - raw/guidelines/local-guideline-file-registry.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-21
status: active
obsidian_type: registry
aliases:
  - retinopathy claims
  - foot care PAD claims
  - 視網膜 claim
  - 糖尿病足 claim
entities:
  - ADA 2026
  - diabetic retinopathy
  - foot care
  - PAD
  - screening
owner_agent: hermes
write_policy: hermes-maintained
---

# ADA 2026 Retinopathy Foot PAD Claim Registry

This registry routes recurring LINE and teaching questions about ADA 2026 retinopathy screening/follow-up and diabetes foot/PAD risk. It is supported by [[../concepts/diabetes-retinopathy-screening]], [[../concepts/diabetes-foot-care-pad]], and [[../guidelines/ada-standards-of-care-2026]].

## Source-Verified Claim Cards

| claim_id | source | grade | population | action | answer_role |
|---|---|---|---|---|---|
| `retinopathy-initial-eye-exam-t1d-ada-2026-12-3` | ADA 2026 Section 12, rec 12.3 | B | Adults with type 1 diabetes | Initial dilated and comprehensive eye exam by ophthalmologist or optometrist 5 years after diabetes onset. | Answer timing questions for type 1 diabetes eye screening. |
| `retinopathy-initial-eye-exam-t2d-ada-2026-12-4` | ADA 2026 Section 12, rec 12.4 | B | People with type 2 diabetes | Initial dilated and comprehensive eye exam by ophthalmologist or optometrist at diabetes diagnosis. | Answer timing questions for type 2 diabetes eye screening. |
| `retinopathy-follow-up-interval-ada-2026-12-5` | ADA 2026 Section 12, rec 12.5 | B | People with diabetes after prior eye exam(s) | If one or more annual exams show no retinopathy and glycemic indicators are within goal, consider a 1–2 year interval; any retinopathy needs at least annual exams and progressing/sight-threatening disease needs more frequent ophthalmologist exams. | Answer interval and follow-up questions while preserving ADA caveats. |
| `retinopathy-photo-ai-screening-ada-2026-12-6` | ADA 2026 Section 12, rec 12.6 | B | People with diabetes needing access to retinopathy screening | Retinal photography with remote reading or FDA-approved AI algorithms are appropriate screening strategies if timely comprehensive eye-exam referral pathways exist when indicated. | Answer AI/tele-retinal screening questions with referral caveat. |
| `retinopathy-pregnancy-counseling-ada-2026-12-7` | ADA 2026 Section 12, rec 12.7 | B | Individuals of childbearing potential with preexisting type 1 or type 2 diabetes planning pregnancy or pregnant | Counsel on risk of development and/or progression of diabetic retinopathy. | Answer preconception/pregnancy retinopathy counseling questions. |
| `retinopathy-pregnancy-eye-exam-ada-2026-12-8` | ADA 2026 Section 12, rec 12.8 | B | Individuals with preexisting type 1 or type 2 diabetes before and during pregnancy | Eye exam before pregnancy and in the first trimester; monitor every trimester and for 1 year postpartum as indicated by retinopathy degree. | Answer pregnancy eye-exam follow-up questions. |
| `foot-comprehensive-evaluation-ada-2026-12-23` | ADA 2026 Section 12, rec 12.23 | A | People with diabetes | Perform comprehensive foot evaluation at least annually to identify risk factors for ulcers and amputations. | Answer annual foot-exam questions. |
| `foot-exam-components-ada-2026-12-24` | ADA 2026 Section 12, rec 12.24 | B | People with diabetes undergoing foot exam | Include skin inspection, foot deformity assessment, neurologic assessment using 10-g monofilament or Ipswich touch test plus at least one additional assessment, and vascular assessment including leg/foot pulses. | Answer what a diabetic foot exam includes. |
| `foot-every-visit-high-risk-ada-2026-12-25` | ADA 2026 Section 12, rec 12.25 | A | Sensory loss or prior ulceration/amputation | Inspect feet at every visit. | Answer high-risk follow-up frequency questions. |
| `foot-risk-history-ada-2026-12-26` | ADA 2026 Section 12, rec 12.26 | B | People with diabetes undergoing foot-risk evaluation | Obtain history of ulceration, amputation, Charcot foot, angioplasty or vascular surgery, cigarette smoking, retinopathy, renal disease, and current neuropathy or vascular symptoms. | Answer what history belongs in foot/PAD risk assessment. |
| `pad-initial-screening-ada-2026-12-27` | ADA 2026 Section 12, rec 12.27 | B | People with diabetes needing PAD screening | Assess pulses, capillary refill, dependent rubor, elevation pallor, venous filling time; concerning symptoms or decreased/absent pulses route to ABI with toe pressures and further vascular assessment. | Answer PAD screening and referral-threshold questions. |
| `foot-interprofessional-high-risk-ada-2026-12-28` | ADA 2026 Section 12, rec 12.28 | B | Individuals with foot ulcers or high-risk feet | Use an interprofessional approach facilitated by a podiatrist with appropriate team members for foot ulcers and high-risk feet, including dialysis, Charcot foot, prior ulcers/amputation, and PAD. | Answer team/referral questions for high-risk feet. |
| `foot-specialist-lifelong-surveillance-ada-2026-12-29` | ADA 2026 Section 12, rec 12.29 referral statement | B | People who smoke with prior lower-extremity complications, LOPS, structural abnormality, or PAD | Refer to foot care specialists for preventive care and lifelong surveillance. | Answer referral and surveillance questions. |
| `foot-smoking-cessation-counseling-ada-2026-12-29` | ADA 2026 Section 12, rec 12.29 smoking-cessation statement | A | People who smoke with prior lower-extremity complications, LOPS, structural abnormality, or PAD | Provide smoking-cessation information and refer for smoking-cessation counseling. | Answer smoking/PAD/foot-risk prevention questions without merging the A grade into the referral statement. |

## Cautions for Answers

- Do not say AI retinal screening replaces dilated comprehensive eye exams; ADA requires referral pathways and notes in-person exams when image quality is inadequate or abnormalities are detected.
- Do not treat ABI alone as definitive in diabetes; ADA notes ABI can be inaccurate because of noncompressible vessels, and toe pressure tends to be more accurate.
- Active ulcers, infection, gangrene, suspected limb ischemia, or Charcot foot should be treated as urgent specialist/referral questions, not routine screening questions.
- ADA 2026 recommendation 12.29 places **B** after the specialist referral/lifelong surveillance sentence and **A** after the smoking-cessation information/counseling sentence; the claim cards split those two source-graded actions to avoid reporting a composite `B/A` grade.

## Related Pages

- [[../concepts/diabetes-retinopathy-screening]]
- [[../concepts/diabetes-foot-care-pad]]
- [[../evidence-ledger/retinopathy-foot-pad-ledger]]
