---
title: ADA 2026 MASLD MASH Claim Registry
type: claim
created: 2026-05-23
updated: 2026-05-23
tags: [ada, diabetes, masld, mash, liver, fibrosis, glp1, pioglitazone, claim-registry, line-qa]
sources:
  - concepts/diabetes-masld-mash.md
  - raw/guidelines/local-guideline-file-registry.md
  - raw/guidelines/ada-standards-of-care-2026-source-map.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: registry
aliases:
  - MASLD MASH claim registry
  - diabetes MASLD claims
  - diabetes MASH claims
  - fatty liver diabetes claim
  - ADA 2026 MASLD recommendations
  - 糖尿病脂肪肝 claim
  - 糖尿病 MASH 建議等級
  - MASH 建議等級
  - 糖尿病脂肪肝 建議等級
entities:
  - ADA 2026 Section 4
  - MASLD
  - MASH
  - FIB-4
  - liver stiffness measurement
  - ELF test
  - GLP-1 receptor agonist
  - dual GIP and GLP-1 receptor agonist
  - pioglitazone
  - semaglutide
  - resmetirom
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-verified ADA 2026 claim registry for diabetes with MASLD/MASH screening, fibrosis-risk routing, lifestyle, GLP-1/pioglitazone, resmetirom referral, cardiovascular risk, and cirrhosis cautions."
related:
  - concepts/diabetes-masld-mash
  - evidence-ledger/masld-mash-ledger
  - guidelines/ada-standards-of-care-2026
  - raw/guidelines/local-guideline-file-registry
  - queries/masld-mash-line-questions
---

# ADA 2026 MASLD MASH Claim Registry

Use this page for common LINE questions about diabetes with MASLD/MASH, fatty liver, liver fibrosis screening, GLP-1 RA, pioglitazone, resmetirom, and 糖尿病 MASH 建議等級 / 糖尿病脂肪肝 建議等級。 It is derived from [[../concepts/diabetes-masld-mash]] and source-verified against ADA 2026 Section 4 (`dc26s004.md`) through [[../raw/guidelines/local-guideline-file-registry]].

Related pages: [[../concepts/diabetes-masld-mash]], [[../evidence-ledger/masld-mash-ledger]], [[../guidelines/ada-standards-of-care-2026]].

## Chinese Routing Terms

- 糖尿病 MASH 建議等級
- 糖尿病脂肪肝 建議等級
- 脂肪肝 GLP-1 證據等級
- 脂肪肝 pioglitazone 證據等級

## Claim Cards

| claim_id | source | grade | population | action | answer_role |
|---|---|---|---|---|---|
| `masld-screen-fib4-ada-4-22a` | ADA 2026 Section 4 Recommendation 4.22a | Grade B | Adults with type 2 diabetes or prediabetes, especially with obesity, other cardiometabolic risk factors, or established CVD | Screen for risk of cirrhosis related to MASH using FIB-4, even if liver enzymes are normal. | First-line answer for screening and “fatty liver risk” questions. |
| `masld-alt-other-causes-ada-4-22b` | ADA 2026 Section 4 Recommendation 4.22b | Grade B | Diabetes or prediabetes with persistently elevated plasma aminotransferases for more than 6 months and low FIB-4 | Evaluate for other causes of liver disease. | Prevents over-attributing all abnormal liver enzymes to MASLD/MASH. |
| `masld-fib4-lsm-elf-ada-4-23` | ADA 2026 Section 4 Recommendation 4.23 | Grade B | Adults with type 2 diabetes or prediabetes and FIB-4 at least 1.3 | Perform additional risk stratification with liver stiffness measurement by transient elastography, or ELF if unavailable. | Routes exact FIB-4/LSM/ELF threshold questions. |
| `masld-hepatology-referral-ada-4-24` | ADA 2026 Section 4 Recommendation 4.24 | Grade B | Adults with type 2 diabetes or prediabetes at higher risk for significant liver fibrosis by FIB-4, liver stiffness measurement, or ELF | Refer to gastroenterologist or hepatologist for further evaluation and management. | Safety routing for high-fibrosis-risk questions. |
| `masld-lifestyle-cardiometabolic-ada-4-25-grade-b` | ADA 2026 Section 4 Recommendation 4.25 | Grade B | Adults with type 2 diabetes or prediabetes, especially with overweight/obesity, and MASLD | Recommend interprofessional lifestyle changes promoting weight loss through structured nutrition and physical activity for cardiometabolic benefits. | Core management answer before medications. |
| `masld-lifestyle-histology-ada-4-25-grade-c` | ADA 2026 Section 4 Recommendation 4.25 | Grade C | Same as above | Lifestyle changes may support histological improvement. | Keeps the histology evidence grade separate from cardiometabolic benefit. |
| `masld-obesity-glp1-mash-benefit-ada-4-26a` | ADA 2026 Section 4 Recommendation 4.26 | Grade A | Adults with type 2 diabetes, MASLD, and overweight/obesity | Consider GLP-1 RA with demonstrated benefits in MASH as adjunctive obesity therapy to lifestyle interventions for weight loss. | Route GLP-1/MASH obesity-treatment questions. |
| `masld-obesity-dual-gip-glp1-ada-4-26b` | ADA 2026 Section 4 Recommendation 4.26 | Grade B | Adults with type 2 diabetes, MASLD, and overweight/obesity | Consider dual GIP/GLP-1 RA with potential benefits in MASH as adjunctive obesity therapy to lifestyle interventions for weight loss. | Keeps dual agonist evidence separate from GLP-1 RA Grade A clause. |
| `mash-glycemic-glp1-preferred-ada-4-27a` | ADA 2026 Section 4 Recommendation 4.27a | Grade A | Adults with type 2 diabetes and biopsy-proven MASH or high risk for liver fibrosis by noninvasive tests | Prefer GLP-1 RA for glycemic management due to beneficial effects on MASH. | Preferred GLP-1 RA drug-positioning answer for high-risk MASH; preserve the separate Grade B options below. |
| `mash-glycemic-pioglitazone-consider-ada-4-27a` | ADA 2026 Section 4 Recommendation 4.27a | Grade B | Same high-risk MASH population | Pioglitazone can be considered for glycemic management due to potential beneficial effects on MASH. | Routes pioglitazone/TZD questions while preserving grade. |
| `mash-glycemic-dual-gip-glp1-consider-ada-4-27a` | ADA 2026 Section 4 Recommendation 4.27a | Grade B | Same high-risk MASH population | Dual GIP/GLP-1 RA can be considered for glycemic management due to potential beneficial effects on MASH. | Routes tirzepatide/dual agonist questions. |
| `mash-pioglitazone-glp1-combo-ada-4-27b` | ADA 2026 Section 4 Recommendation 4.27b | Grade B | Adults with type 2 diabetes with biopsy-proven MASH or high fibrosis risk by noninvasive tests | Combination pioglitazone plus GLP-1 RA can be considered for hyperglycemia because of potential beneficial effects on MASH. | Answers combination-therapy questions without implying universal use. |
| `masld-resmetirom-hepatology-referral-ada-4-28` | ADA 2026 Section 4 Recommendation 4.28 | Grade A | Adults with type 2 diabetes or prediabetes with MASLD and moderate F2 or advanced F3 fibrosis by histology or validated imaging/blood test | For thyroid hormone receptor-beta agonist treatment consideration, refer to gastroenterologist/hepatologist with MASLD expertise. | Routes resmetirom questions to specialist evaluation. |
| `masld-treatment-shared-decision-ada-4-29` | ADA 2026 Section 4 Recommendation 4.29 | Grade B | Adults starting or monitoring MASLD/MASH therapy | Individualize treatment within an interprofessional team including gastroenterology/hepatology, preferences, and shared cost-benefit discussion. | Safety close for patient-facing answers. |
| `masld-other-glucose-drugs-lack-mash-benefit-ada-4-30a` | ADA 2026 Section 4 Recommendation 4.30a | Grade B | Adults with type 2 diabetes and MASLD | Glucose-lowering therapies other than pioglitazone or GLP-1 RAs may continue as clinically indicated but lack evidence of benefit in MASH. | Prevents overclaiming metformin/SGLT2i/insulin histologic MASH benefit. |
| `masld-decompensated-cirrhosis-insulin-ada-4-30b` | ADA 2026 Section 4 Recommendation 4.30b | Grade C | Adults with type 2 diabetes and decompensated cirrhosis | Insulin is preferred for hyperglycemia treatment. | Cirrhosis safety branch. |
| `masld-cv-risk-management-ada-4-31a` | ADA 2026 Section 4 Recommendation 4.31a | Grade B | Adults with type 2 diabetes and MASLD | Provide comprehensive cardiovascular risk-factor management. | Links liver disease to organ-centric diabetes care. |
| `masld-statin-compensated-cirrhosis-ada-4-31b` | ADA 2026 Section 4 Recommendation 4.31b | Grade B | Adults with type 2 diabetes and compensated cirrhosis from MASLD | Statin therapy is safe and should be initiated or continued for cardiovascular risk reduction as clinically indicated. | Answers “can statins be used in compensated cirrhosis?” questions. |
| `masld-statin-decompensated-cirrhosis-ada-4-31b` | ADA 2026 Section 4 Recommendation 4.31b | Grade B | Adults with type 2 diabetes and decompensated cirrhosis from MASLD | Statin therapy should be used with caution and close monitoring, given limited safety and efficacy data. | Cirrhosis safety branch for statin questions. |
| `mash-metabolic-surgery-mash-ada-4-32a` | ADA 2026 Section 4 Recommendation 4.32a | Grade B | Appropriate adult candidates with type 2 diabetes and obesity | Consider metabolic surgery as an option to treat MASH. | Routes metabolic-surgery-for-MASH questions without making surgery solely liver-indicated. |
| `mash-metabolic-surgery-cv-ada-4-32a` | ADA 2026 Section 4 Recommendation 4.32a | Grade B | Appropriate adult candidates with type 2 diabetes and obesity | Consider metabolic surgery to improve cardiovascular outcomes. | Keeps liver and CV outcome clauses separate. |
| `masld-metabolic-surgery-cirrhosis-ada-4-32b` | ADA 2026 Section 4 Recommendation 4.32b | Grade B | Adults with type 2 diabetes and compensated or decompensated cirrhosis from MASLD | Use metabolic surgery with caution in compensated cirrhosis and do not recommend it in decompensated cirrhosis. | Cirrhosis safety branch for surgery questions. |

## Verification Notes

- Verified against local raw ADA 2026 Section 4: `/Users/ander/Documents/medical/guidelines/ada/dc26s004.md`, lines 1285-1517, including recommendations 4.22a-4.32b.
- Clauses with separate evidence grades are split into distinct claim cards to avoid ambiguous combined grades.
- KDIGO sources were not used because the selected request concerns ADA 2026 MASLD/MASH content, not diabetes + CKD pharmacotherapy.
