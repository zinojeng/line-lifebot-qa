---
title: Hospital Steroid Hyperglycemia LINE Questions
type: query
created: 2026-05-23
updated: 2026-05-23
tags: [query, line-qa, hospital-care, steroid, glucocorticoid, hyperglycemia]
sources:
  - concepts/hospital-steroid-hyperglycemia.md
  - guidelines/ada-standards-of-care-2026.md
  - raw/guidelines/local-guideline-file-registry.md
evidence_level: local-practice
clinical_use: [workflow, line-qa]
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: output
aliases:
  - hospital steroid hyperglycemia query
  - glucocorticoid hyperglycemia LINE question
  - prednisone NPH insulin question
  - 類固醇高血糖
  - 住院 steroid 高血糖
  - dexamethasone hyperglycemia
entities:
  - ADA 2026 Section 16
  - glucocorticoids
  - prednisone
  - prednisolone
  - dexamethasone
  - NPH insulin
owner_agent: hermes
write_policy: hermes-maintained
summary: "Reusable query page for LINE questions about inpatient glucocorticoid/steroid hyperglycemia, NPH matching, basal/prandial insulin principles, and hospital-team safety routing."
related:
  - concepts/hospital-steroid-hyperglycemia
  - guidelines/ada-standards-of-care-2026
  - concepts/diabetes-technology-cgm-aid
  - _meta/topic-map
---

# Hospital Steroid Hyperglycemia LINE Questions

Use this query page when a LINE user asks about high glucose during hospital
steroid or glucocorticoid treatment, including prednisone, prednisolone,
dexamethasone, NPH insulin matching, or daily insulin adjustment principles.

## Route First

- Concept scaffold: [[../concepts/hospital-steroid-hyperglycemia]]
- ADA source overview: [[../guidelines/ada-standards-of-care-2026]]
- Raw verification anchor: [[../raw/guidelines/local-guideline-file-registry]]

## Common User Wording

- "住院打 steroid 血糖很高怎麼辦？"
- "prednisone 為什麼下午晚上血糖高？"
- "類固醇高血糖要用 NPH 嗎？"
- "dexamethasone 高血糖怎麼調？"

## Answer Shape

1. State this is inpatient/hospital-care guidance, not outpatient self-adjustment.
2. Explain that steroid type, timing, duration, meals, and point-of-care glucose pattern matter.
3. Use principle-level language from [[../concepts/hospital-steroid-hyperglycemia]].
4. Close with hospital diabetes/inpatient team management for specific orders.

## Guardrails

- Do not provide fixed insulin-dose formulas.
- Mention hypoglycemia risk when steroids are reduced, intake changes, or insulin timing mismatches.
- Do not route to generic outpatient diabetes medication tables.
