---
title: GDM Pharmacotherapy LINE Questions
type: query
created: 2026-05-23
updated: 2026-05-23
tags: [query, line-qa, gdm, pregnancy, metformin, insulin, pharmacotherapy]
sources:
  - claims/ada-2026-gdm-pharmacotherapy-claims.md
  - evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades.md
  - concepts/diabetes-pregnancy-gdm-cgm.md
evidence_level: local-practice
clinical_use: [workflow, line-qa]
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: output
aliases:
  - GDM pharmacotherapy question
  - metformin GDM evidence
  - gestational diabetes medication evidence
  - 妊娠糖尿病 metformin
  - 妊娠糖尿病 口服藥
  - 懷孕糖尿病用藥證據
entities:
  - GDM
  - gestational diabetes
  - insulin
  - metformin
  - glyburide
  - ADA 2026 Section 15
owner_agent: hermes
write_policy: hermes-maintained
summary: "Reusable query page for LINE questions about GDM pharmacotherapy, metformin, glyburide, insulin preference, and evidence-grade routing."
related:
  - claims/ada-2026-gdm-pharmacotherapy-claims
  - evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades
  - concepts/diabetes-pregnancy-gdm-cgm
  - evidence-ledger/gdm-pharmacotherapy-ledger
  - _meta/topic-map
---

# GDM Pharmacotherapy LINE Questions

Use this query page when a LINE user asks whether metformin, glyburide, insulin,
or other oral/noninsulin agents are appropriate in gestational diabetes.

## Route First

- Claim registry: [[../claims/ada-2026-gdm-pharmacotherapy-claims]]
- Evidence grades: [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]]
- Concept context: [[../concepts/diabetes-pregnancy-gdm-cgm]]
- Ledger: [[../evidence-ledger/gdm-pharmacotherapy-ledger]]

## Common User Wording

- "妊娠糖尿病可以吃 metformin 嗎？"
- "GDM metformin 的證據等級是什麼？"
- "懷孕糖尿病口服藥和胰島素怎麼選？"
- "glyburide 在 GDM 安全嗎？"

## Answer Shape

1. State the source scope: answer from ADA 2026 pregnancy/GDM wiki pages.
2. Lead with the claim registry rather than CKD/metformin pages.
3. Separate "insulin preferred" from "metformin/glyburide not first-line" and from "other oral/noninsulin agents lack long-term safety data."
4. Avoid patient-specific medication changes; close with clinician/obstetric diabetes team discussion.

## Guardrails

- Do not route metformin-in-GDM questions to CKD metformin thresholds unless the user also asks eGFR/CKD.
- Do not say oral agents are absolutely forbidden; preserve source wording and evidence grade.
- Verify exact recommendation numbers and grades against [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]] before quoting them.
