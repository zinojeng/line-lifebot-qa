---
title: MASLD MASH LINE Questions
type: query
created: 2026-05-23
updated: 2026-05-23
tags: [query, line-qa, masld, mash, fatty-liver, fibrosis, glp1, pioglitazone]
sources:
  - concepts/diabetes-masld-mash.md
  - claims/ada-2026-masld-mash-claims.md
  - evidence-ledger/masld-mash-ledger.md
evidence_level: local-practice
clinical_use: [workflow, line-qa]
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: output
aliases:
  - MASLD MASH LINE question
  - fatty liver diabetes question
  - diabetes MASH evidence grade
  - 糖尿病脂肪肝建議
  - 糖尿病 MASH 證據等級
  - 脂肪肝 GLP-1 證據等級
entities:
  - MASLD
  - MASH
  - FIB-4
  - GLP-1 receptor agonist
  - dual GIP and GLP-1 receptor agonist
  - pioglitazone
  - resmetirom
owner_agent: hermes
write_policy: hermes-maintained
summary: "Reusable query page for LINE questions about diabetes with MASLD/MASH, fatty liver, FIB-4, GLP-1/pioglitazone, resmetirom referral, and cirrhosis safety routing."
related:
  - concepts/diabetes-masld-mash
  - claims/ada-2026-masld-mash-claims
  - evidence-ledger/masld-mash-ledger
  - concepts/organ-centric-diabetes-care
  - _meta/topic-map
---

# MASLD MASH LINE Questions

Use this query page when a LINE user asks about diabetes with fatty liver,
MASLD, MASH, NAFLD/NASH wording, liver fibrosis screening, GLP-1 RA,
pioglitazone, semaglutide, resmetirom, or cirrhosis safety.

## Route First

- Concept scaffold: [[../concepts/diabetes-masld-mash]]
- Claim cards and recommendation grades: [[../claims/ada-2026-masld-mash-claims]]
- Verification ledger: [[../evidence-ledger/masld-mash-ledger]]
- Broader frame: [[../concepts/organ-centric-diabetes-care]]

## Common User Wording

- "糖尿病脂肪肝要做什麼檢查？"
- "糖尿病 MASH 的 GLP-1 證據等級是？"
- "脂肪肝 pioglitazone 有幫助嗎？"
- "resmetirom 糖尿病可以用嗎？"
- "FIB-4 高要看肝膽腸胃科嗎？"

## Answer Shape

1. Identify the question bucket: screening, fibrosis risk, glycemic drug choice, obesity therapy, resmetirom referral, cardiovascular risk, or cirrhosis safety.
2. Use [[../claims/ada-2026-masld-mash-claims]] for recommendation number and grade.
3. Keep GLP-1 RA, dual GIP/GLP-1 RA, pioglitazone, semaglutide, and resmetirom indication-specific.
4. Close with source-grounded safety language for fibrosis risk, cirrhosis, specialist referral, or clinician discussion.

## Guardrails

- Do not route "脂肪肝/MASH 建議等級" to CKD/cardiorenal evidence cards.
- Do not present resmetirom as a patient-facing self-start treatment; route through hepatology/gastroenterology expertise.
- Do not infer that all glucose-lowering drugs improve MASH histology; use the claim registry wording.
