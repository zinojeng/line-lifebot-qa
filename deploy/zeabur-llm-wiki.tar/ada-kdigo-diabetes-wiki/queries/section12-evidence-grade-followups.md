---
title: Section 12 Evidence Grade Follow-Up Queries
type: query
created: 2026-05-23
updated: 2026-05-23
tags: [query, line-qa, evidence-grade, section-12, retinopathy, neuropathy, foot-care, pad]
sources:
  - mocs/evidence-grade-router-moc.md
  - evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades.md
  - claims/ada-2026-retinopathy-foot-pad-claims.md
evidence_level: local-practice
clinical_use: [workflow, line-qa]
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: output
aliases:
  - Section 12 evidence grade follow-up
  - retinopathy treatment evidence grade query
  - neuropathy medication evidence grade query
  - foot PAD recommendation grade query
  - 嚴重眼病變治療證據等級
  - 神經病變藥物證據等級
entities:
  - ADA 2026 Section 12
  - retinopathy
  - neuropathy
  - foot care
  - PAD
owner_agent: hermes
write_policy: hermes-maintained
summary: "Reusable query page for short LINE follow-ups asking evidence grades after retinopathy, neuropathy, foot-care, or PAD context."
related:
  - mocs/evidence-grade-router-moc
  - evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades
  - claims/ada-2026-retinopathy-foot-pad-claims
  - concepts/diabetes-retinopathy-screening
  - concepts/diabetes-foot-care-pad
---

# Section 12 Evidence Grade Follow-Up Queries

Use this query page when the user asks a short follow-up such as "證據等級是？"
after a recent retinopathy, neuropathy, foot-care, or PAD question.

## Route First

- Context router: [[../mocs/evidence-grade-router-moc]]
- Evidence-card table: [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]]
- Source-verified claims: [[../claims/ada-2026-retinopathy-foot-pad-claims]]

## Common User Wording

- "嚴重眼病變治療的證據等級是？"
- "anti-VEGF 或雷射是什麼等級？"
- "糖尿病神經病變藥物的證據等級？"
- "糖尿病足/PAD 建議等級？"

## Answer Shape

1. Restore the clinical topic from recent context before answering.
2. If retinopathy context: answer from ADA 12.9-12.16, not CKD/cardiorenal cards.
3. If neuropathy medication context: lead with ADA 12.22 and then add prevention/symptom rows only if relevant.
4. If foot/PAD context: keep foot-care/PAD recommendation grades separate from ASCVD medication grades.

## Guardrails

- Do not default short "證據等級" follow-ups to CKD unless kidney/eGFR/UACR/KDIGO context is present.
- Do not collapse Section 12 Grade A/B/C/E rows into a single generic "strong" answer.
- Verify exact rows against [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]].
