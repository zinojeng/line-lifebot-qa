---
title: Bone GLP-1 Muscle LINE Questions
type: query
created: 2026-05-23
updated: 2026-05-23
tags: [query, line-qa, bone-health, osteoporosis, glp1, sarcopenia, muscle]
sources:
  - concepts/diabetes-bone-health-osteoporosis.md
  - claims/ada-2026-bone-health-osteoporosis-claims.md
  - concepts/glp1-weight-loss-muscle-sarcopenia.md
  - claims/glp1-weight-loss-muscle-sarcopenia-claims.md
evidence_level: local-practice
clinical_use: [workflow, line-qa]
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: output
aliases:
  - diabetes bone GLP1 muscle question
  - GLP-1 sarcopenia LINE question
  - diabetes osteoporosis LINE question
  - 糖尿病骨質疏鬆
  - GLP1 減重 肌少症
  - 握力下降 SMI
entities:
  - osteoporosis
  - fracture risk
  - GLP-1 receptor agonist
  - sarcopenia
  - SMI
  - handgrip strength
owner_agent: hermes
write_policy: hermes-maintained
summary: "Reusable query page for LINE questions connecting diabetes bone health, osteoporosis, GLP-1-related weight loss, SMI decline, handgrip weakness, and sarcopenia assessment."
related:
  - concepts/diabetes-bone-health-osteoporosis
  - claims/ada-2026-bone-health-osteoporosis-claims
  - concepts/glp1-weight-loss-muscle-sarcopenia
  - claims/glp1-weight-loss-muscle-sarcopenia-claims
  - evidence-ledger/bone-health-osteoporosis-ledger
  - evidence-ledger/glp1-muscle-sarcopenia-ledger
---

# Bone GLP-1 Muscle LINE Questions

Use this query page when the user asks about diabetes with osteoporosis,
fracture risk, bone density, GLP-1-related weight loss, lower SMI, handgrip
weakness, weak legs, or possible sarcopenia.

## Route First

- Bone health concept: [[../concepts/diabetes-bone-health-osteoporosis]]
- Bone health claims: [[../claims/ada-2026-bone-health-osteoporosis-claims]]
- GLP-1 muscle concept: [[../concepts/glp1-weight-loss-muscle-sarcopenia]]
- GLP-1 muscle claims: [[../claims/glp1-weight-loss-muscle-sarcopenia-claims]]

## Common User Wording

- "糖尿病骨質疏鬆治療和一般人不同嗎？"
- "GLP-1 減重後 SMI 下降是肌少症嗎？"
- "握力下降、腿沒力要不要停 GLP-1？"
- "糖尿病骨折風險要看 DXA/FRAX 嗎？"

## Answer Shape

1. Decide whether the question is primarily bone/fracture risk or GLP-1/muscle function.
2. For bone questions, answer from [[../concepts/diabetes-bone-health-osteoporosis]] and claim cards.
3. For GLP-1 muscle questions, avoid diagnosing sarcopenia from SMI alone; include strength and performance assessment.
4. Close with clinician assessment rather than medication self-adjustment.

## Guardrails

- Do not claim SMI decline alone proves sarcopenia.
- Do not tell the user to stop GLP-1 abruptly.
- Verify exact bone-health treatment triggers and recommendation grades against the claim/evidence pages before quoting them.
