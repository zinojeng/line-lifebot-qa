---
title: How To Use This Wiki For ADA-KDIGO Questions
type: query
created: 2026-05-19
updated: 2026-05-19
tags: [output, workflow, hermes, codex, openclaw, ada, kdigo]
sources:
  - ../SCHEMA.md
  - ../index.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-19
status: active
obsidian_type: output
summary: "Source-aware query page for How To Use This Wiki For ADA-KDIGO Questions; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 2 listed source(s) before changing recommendations."
related: 
  - "guidelines/ada-standards-of-care-2026"
  - "concepts/organ-centric-diabetes-care"
aliases: 
  - "how to use this wiki for ada kdigo questions"
entities: 
  - "Hermes Agent"
  - "Codex"
  - "OpenClaw"
  - "ADA 2026"
  - "KDIGO 2026"
owner_agent: hermes
write_policy: source-aware-review
---

# How To Use This Wiki For ADA-KDIGO Questions

## Workflow

1. Read [[../SCHEMA]].
2. Read [[../index]].
3. Open the most relevant guideline page.
4. Open linked concept and comparison pages.
5. If exact clinical thresholds or recommendation wording are needed, verify against the raw source map and official guideline.
6. If the answer has durable value, write it back to `queries/` or update the relevant concept page.
7. Update [[../log]].

## Example

For "make a 20-slide ADA 2026 Section 10 lecture for medical students":

- Start with [[../guidelines/ada-standards-of-care-2026]].
- Add [[../concepts/organ-centric-diabetes-care]].
- Check the official ADA 2026 Section 10 source before adding exact recommendations.
- Save the output under `teaching/` if reusable.
