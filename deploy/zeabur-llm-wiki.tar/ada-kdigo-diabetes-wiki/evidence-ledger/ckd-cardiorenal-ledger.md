---
title: CKD Cardiorenal Evidence Ledger
type: evidence-ledger
created: 2026-05-21
updated: 2026-05-21
tags: [evidence-ledger, ada, kdigo, ckd, cardiorenal, sglt2i, glp1, finerenone]
sources:
  - claims/ada-kdigo-2026-ckd-cardiorenal-claims.md
  - evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-21
status: active
obsidian_type: registry
aliases:
  - CKD cardiorenal evidence ledger
  - SGLT2i GLP-1 finerenone timeline
entities:
  - ADA 2026
  - KDIGO 2026
  - SGLT2 inhibitor
  - GLP-1 receptor agonist
  - finerenone
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware evidence-ledger page for CKD Cardiorenal Evidence Ledger; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 2 listed source(s) before changing recommendations."
related: 
  - "claims/ada-kdigo-2026-ckd-cardiorenal-claims"
  - "evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades"
  - "comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd"
---

# CKD Cardiorenal Evidence Ledger

Append-only ledger for changes to diabetes + CKD cardiorenal recommendations.
Use this to preserve why a claim changed instead of silently overwriting claims.

Related pages: [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]],
[[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]],
[[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]].

## Ledger Entries

| date | source | affected_claims | change_type | note |
|---|---|---|---|---|
| 2026-05-20 | ADA 2026 and KDIGO 2026 public-review draft synthesis | CKD cardiorenal claim registry | initial_compile | Initial claims extracted for SGLT2i, GLP-1-based therapy, finerenone/nsMRA, ACEi/ARB, metformin, HbA1c/CGM caveats, and lower-certainty buckets. |

## Pending Watch Items

- KDIGO 2026 final publication may change wording, recommendation numbers, or grade labels.
- ADA 2027 should trigger a comparison rather than overwriting current ADA 2026 claims.
