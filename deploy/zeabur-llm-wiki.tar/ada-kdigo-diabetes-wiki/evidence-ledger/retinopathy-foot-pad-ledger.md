---
title: Retinopathy Foot PAD Evidence Ledger
type: evidence-ledger
created: 2026-05-21
updated: 2026-05-22
tags: [evidence-ledger, ada, retinopathy, foot-care, pad, complications]
sources:
  - claims/ada-2026-retinopathy-foot-pad-claims.md
  - concepts/diabetes-retinopathy-screening.md
  - concepts/diabetes-foot-care-pad.md
  - raw/guidelines/ada-standards-of-care-2026-source-map.md
  - raw/guidelines/local-guideline-file-registry.md
  - inbox/research-requests/2026-05-20-self-audit-diabetes-retinopathy-screening-and-follow-up.md
  - inbox/research-requests/2026-05-20-self-audit-diabetes-foot-care-and-pad-risk.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-21
status: active
obsidian_type: registry
aliases:
  - retinopathy evidence ledger
  - foot PAD evidence ledger
entities:
  - ADA 2026
  - retinopathy
  - foot care
  - PAD
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware evidence-ledger page for Retinopathy Foot PAD Evidence Ledger; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 7 listed source(s) before changing recommendations."
related: 
  - "claims/ada-2026-retinopathy-foot-pad-claims"
  - "evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades"
  - "mocs/evidence-grade-router-moc"
  - "concepts/diabetes-retinopathy-screening"
  - "concepts/diabetes-foot-care-pad"
---

# Retinopathy Foot PAD Evidence Ledger

Append-only ledger for retinopathy and foot/PAD retrieval improvements.

Related pages: [[../claims/ada-2026-retinopathy-foot-pad-claims]],
[[../inbox/research-requests/2026-05-20-self-audit-diabetes-retinopathy-screening-and-follow-up]],
[[../inbox/research-requests/2026-05-20-self-audit-diabetes-foot-care-and-pad-risk]].

## Ledger Entries

| date | source | affected_claims | change_type | note |
|---|---|---|---|---|
| 2026-05-22 | LINE answer-improvement inbox: `嚴重眼病變治療` + `證據等級是？`; `糖尿病神經病變藥物的證據等級是？` | `retinopathy-urgent-ophthalmology-referral-ada-2026-12-9`, `retinopathy-antivegf-dme-ada-2026-12-12`, `neuropathy-initial-drug-classes-ada-2026-12-22`, `neuropathy-opioid-avoidance-ada-2026-12-22` | evidence-card + router | Added [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] and [[../mocs/evidence-grade-router-moc]] so generic evidence-grade follow-ups route by recent clinical context instead of defaulting to CKD. |
| 2026-05-20 | self-improvement audit | retinopathy and foot/PAD pending claims | research_request | Audit identified under-routed retinopathy and foot/PAD topics. |
| 2026-05-21 | pending claim registry | retinopathy and foot/PAD pending claims | registry_scaffold | Added placeholder claim registry so repeated LINE questions route to a known gap instead of producing false certainty. |
| 2026-05-21 | ADA 2026 Section 12 (`dc26s012.md`) | retinopathy and foot/PAD claim cards | concept_writeback | Created source-verified concept pages for retinopathy screening/follow-up and foot-care/PAD risk; updated claim registry and routing aliases. |
