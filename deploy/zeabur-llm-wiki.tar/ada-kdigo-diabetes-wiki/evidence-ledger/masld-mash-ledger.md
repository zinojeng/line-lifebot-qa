---
title: MASLD MASH Evidence Ledger
type: evidence-ledger
created: 2026-05-23
updated: 2026-05-23
tags: [ada, diabetes, masld, mash, liver, evidence-ledger, line-qa]
sources:
  - concepts/diabetes-masld-mash.md
  - claims/ada-2026-masld-mash-claims.md
  - raw/guidelines/local-guideline-file-registry.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: registry
aliases:
  - MASLD MASH evidence ledger
  - diabetes fatty liver ledger
entities:
  - ADA 2026 Section 4
  - MASLD
  - MASH
  - GLP-1 receptor agonist
  - pioglitazone
owner_agent: hermes
write_policy: hermes-maintained
summary: "Append-only ledger for ADA 2026 MASLD/MASH wiki routing, raw verification, and claim-card updates."
related:
  - concepts/diabetes-masld-mash
  - claims/ada-2026-masld-mash-claims
  - raw/guidelines/local-guideline-file-registry
  - queries/masld-mash-line-questions
---

# MASLD MASH Evidence Ledger

Related pages: [[../concepts/diabetes-masld-mash]], [[../claims/ada-2026-masld-mash-claims]], [[../raw/guidelines/local-guideline-file-registry]].

## 2026-05-23 | create | self-audit research request writeback

- Trigger: [[../inbox/research-requests/2026-05-22-self-audit-diabetes-masld-and-mash]] reported diabetes MASLD/MASH as under-routed.
- Raw source checked: ADA 2026 Section 4 (`dc26s004.md`) via [[../raw/guidelines/local-guideline-file-registry]]; verified local file SHA-256 `311f41e978b61219b3de880b1d9ce85fa5e4f3a804bb140bdea2d029a1216623`, especially recommendations 4.22a-4.32b and surrounding explanatory text.
- Grade split verification: local source shows 4.25 as B/C clauses, 4.26 as A/B clauses, and 4.27a as GLP-1 RA Grade A plus pioglitazone Grade B plus dual GIP/GLP-1 RA Grade B.
- Claude review spot-check: raw `dc26s004.md` lines 1404-1415 reconfirmed 4.25 B/C, 4.26 A/B, 4.27a A/B/B, 4.28 Grade A referral for thyroid hormone receptor-beta agonist treatment consideration, 4.30b Grade C, 4.31b Grade B/B, 4.32a Grade B/B, and 4.32b Grade B; SHA-256 matched the ledger value above.
- Wording check: raw 4.27a explicitly says GLP-1 RA "is preferred" for glycemic management in the high-risk MASH population; claim-card answer roles should not broaden this into a universal first-line diabetes-drug hierarchy.
- Durable pages created: [[../concepts/diabetes-masld-mash]] and [[../claims/ada-2026-masld-mash-claims]].
- Routing pages updated: [[../_meta/aliases]], [[../_meta/topic-map]], and [[../index]].
- Caution: external literature was deferred because ADA 2026 Section 4 was considered current and sufficient for this routing gap. Future refresh should focus on FDA labels and hepatology guidance for semaglutide/resmetirom if canonical therapy details expand.
