---
title: GDM Pharmacotherapy Evidence Ledger
type: evidence-ledger
created: 2026-05-22
updated: 2026-05-22
tags: [evidence-ledger, ada, pregnancy, gdm, metformin, glyburide, insulin, line-qa]
sources:
  - claims/ada-2026-gdm-pharmacotherapy-claims.md
  - evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades.md
  - concepts/diabetes-pregnancy-gdm-cgm.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-22
status: active
obsidian_type: registry
aliases:
  - GDM pharmacotherapy ledger
  - metformin GDM evidence ledger
  - 妊娠糖尿病 metformin ledger
entities:
  - ADA 2026
  - GDM
  - metformin
  - glyburide
  - insulin
owner_agent: hermes
write_policy: hermes-maintained
---

# GDM Pharmacotherapy Evidence Ledger

Append-only ledger for GDM/diabetes-in-pregnancy pharmacotherapy routing and
answer improvements.

Related pages: [[../claims/ada-2026-gdm-pharmacotherapy-claims]],
[[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]],
[[../concepts/diabetes-pregnancy-gdm-cgm]].

## Ledger Entries

| date | source | affected_claims | change_type | note |
|---|---|---|---|---|
| 2026-05-22 | LINE answer-improvement record for `Metformin in GDM evidence` | GDM pharmacotherapy claim registry | route_repair | The answer was too conservative because retrieval hit broad CKD/CGM pages instead of ADA Section 15 pregnancy pharmacotherapy. Added aliases, evidence card, claim registry, ledger, and smoke-test routing. |
