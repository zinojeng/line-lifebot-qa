---
title: GLP-1 Muscle Sarcopenia Evidence Ledger
type: evidence-ledger
created: 2026-05-21
updated: 2026-05-21
tags: [evidence-ledger, glp1, weight-loss, sarcopenia, muscle, smi]
sources:
  - claims/glp1-weight-loss-muscle-sarcopenia-claims.md
  - concepts/glp1-weight-loss-muscle-sarcopenia.md
evidence_level: guideline
clinical_use: [clinical-reference, patient-education, teaching, line-qa]
confidence: high
last_verified: 2026-05-21
status: active
obsidian_type: registry
aliases:
  - GLP-1 muscle evidence ledger
  - sarcopenia timeline
entities:
  - GLP-1 receptor agonist
  - sarcopenia
  - SMI
  - handgrip strength
owner_agent: hermes
write_policy: hermes-maintained
---

# GLP-1 Muscle Sarcopenia Evidence Ledger

Append-only ledger for GLP-1 weight loss, lean mass, SMI, and sarcopenia-related
retrieval improvements.

Related pages: [[../claims/glp1-weight-loss-muscle-sarcopenia-claims]],
[[../concepts/glp1-weight-loss-muscle-sarcopenia]].

## Ledger Entries

| date | source | affected_claims | change_type | note |
|---|---|---|---|---|
| 2026-05-20 | LINE question: GLP1 weight loss with SMI decrease, weaker handgrip, weak legs | GLP-1 sarcopenia concept | answer_improvement | Created concept page with AWGS/EWGSOP diagnostic framing and conservative LINE answer pattern. |
| 2026-05-21 | GLP-1 sarcopenia concept page | GLP-1 muscle claim registry | registry_scaffold | Split concept into claim cards: SMI alone is insufficient, functional decline warrants assessment, lean mass can fall during GLP-1 weight loss, and medication should not be stopped without clinician discussion. |
