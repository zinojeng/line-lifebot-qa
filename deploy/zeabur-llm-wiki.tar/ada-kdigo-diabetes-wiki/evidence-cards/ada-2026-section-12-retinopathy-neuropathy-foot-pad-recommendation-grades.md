---
title: ADA 2026 Section 12 Retinopathy Neuropathy Foot PAD Recommendation Grades
type: evidence-card
created: 2026-05-22
updated: 2026-05-22
tags: [ada, section-12, retinopathy, neuropathy, foot-care, pad, evidence-card, recommendation-grade]
sources:
  - raw/guidelines/local-guideline-file-registry.md
  - raw/guidelines/ada-standards-of-care-2026-source-map.md
  - claims/ada-2026-retinopathy-foot-pad-claims.md
  - concepts/diabetes-retinopathy-screening.md
  - concepts/diabetes-foot-care-pad.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-22
status: active
obsidian_type: relationship
aliases:
  - ADA 2026 Section 12 recommendation grades
  - retinopathy treatment evidence grade
  - diabetic neuropathy treatment grade
  - foot PAD recommendation grade
  - 嚴重眼病變治療 證據等級
  - 神經病變藥物 證據等級
  - 糖尿病足 建議等級
entities:
  - ADA 2026
  - Section 12
  - diabetic retinopathy
  - diabetic macular edema
  - proliferative diabetic retinopathy
  - diabetic neuropathy
  - diabetic foot care
  - PAD
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware evidence-card page for ADA 2026 Section 12 Retinopathy Neuropathy Foot PAD Recommendation Grades; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 5 listed source(s) before changing recommendations."
related: 
  - "mocs/evidence-grade-router-moc"
  - "claims/ada-2026-retinopathy-foot-pad-claims"
  - "concepts/diabetes-retinopathy-screening"
  - "concepts/diabetes-foot-care-pad"
  - queries/section12-evidence-grade-followups
---

# ADA 2026 Section 12 Retinopathy Neuropathy Foot PAD Recommendation Grades

Use this evidence card when a LINE user asks about recommendation numbers or evidence grades for ADA 2026 Section 12: retinopathy, neuropathy, foot care, and PAD.

Verified source: ADA 2026 Section 12 local Markdown (`dc26s012.md`) via [[../raw/guidelines/local-guideline-file-registry]]. Related routes: [[../mocs/evidence-grade-router-moc]], [[../claims/ada-2026-retinopathy-foot-pad-claims]], [[../concepts/diabetes-retinopathy-screening]], and [[../concepts/diabetes-foot-care-pad]].

## Retinopathy Screening And Follow-Up

| ADA 2026 recommendation | Grade | Population / context | Source-verified action | Retrieval terms |
|---|---|---|---|---|
| 12.3 | B | Adults with type 1 diabetes | Initial dilated and comprehensive eye examination by ophthalmologist or optometrist 5 years after diabetes onset. | T1D eye exam, initial retinopathy screening, grade B |
| 12.4 | B | People with type 2 diabetes | Initial dilated and comprehensive eye examination by ophthalmologist or optometrist at diabetes diagnosis. | T2D eye exam at diagnosis, grade B |
| 12.5 | B | People with diabetes after prior eye exam(s) | If one or more annual exams show no retinopathy and glycemic indicators are within goal, consider a 1-2 year interval; if any retinopathy is present, subsequent dilated retinal exams should be at least annual; progressing or sight-threatening disease requires more frequent ophthalmologist exams. | follow-up interval, annual eye exam, sight-threatening retinopathy |
| 12.6 | B | Retinopathy screening access | Retinal photography with remote reading or FDA-approved AI algorithms are appropriate screening strategies when pathways exist for timely referral for comprehensive eye examination if indicated. | AI retinal screening, retinal photography, referral pathway |
| 12.7 | B | Preexisting type 1 or type 2 diabetes planning pregnancy or pregnant | Counsel about retinopathy development/progression risk. | pregnancy retinopathy counseling |
| 12.8 | B | Preexisting type 1 or type 2 diabetes before and during pregnancy | Eye exam before pregnancy and in the first trimester; monitor every trimester and for 1 year postpartum as indicated by retinopathy degree. | pregnancy eye exam, trimester monitoring |

## Retinopathy Treatment And Visual Rehabilitation

| ADA 2026 recommendation | Grade | Population / context | Source-verified action | Retrieval terms |
|---|---|---|---|---|
| 12.9 | A | Any DME, moderate or worse NPDR, or any PDR | Promptly refer to an ophthalmologist knowledgeable and experienced in diabetic retinopathy management. | severe eye disease, DME, NPDR, PDR, referral, grade A |
| 12.10 | A | High-risk PDR and selected severe NPDR | Panretinal laser photocoagulation is indicated to reduce vision-loss risk. | panretinal laser, photocoagulation, PDR, severe NPDR |
| 12.11 | A | Some individuals with PDR | Intravitreal anti-VEGF is a reasonable alternative to traditional panretinal laser photocoagulation and also reduces vision-loss risk. | anti-VEGF, PDR, laser alternative |
| 12.12 | A | Most eyes with DME involving the foveal center and impairing visual acuity | Intravitreal anti-VEGF is first-line treatment. | DME, foveal center, impaired visual acuity, first-line anti-VEGF |
| 12.13 | A | Persistent DME after anti-VEGF or not candidates for anti-VEGF | Macular focal/grid photocoagulation and intravitreal corticosteroid injections are reasonable treatments. | persistent DME, focal/grid laser, corticosteroid |
| 12.14 | A | Retinopathy plus cardioprotection indication | Retinopathy is not a contraindication to aspirin for cardioprotection because aspirin does not increase retinal hemorrhage risk. | aspirin retinopathy, retinal hemorrhage |
| 12.15 | E | Diabetes-related vision loss | Counsel on vision rehabilitation availability and scope, and provide or refer for comprehensive visual impairment evaluation by an experienced practitioner. | vision rehabilitation, grade E |
| 12.16 | E | Diabetes-related vision loss | Provide educational materials and eye-care support resources in addition to self-management education. | vision loss education, eye-care support, grade E |

## Neuropathy Treatment

| ADA 2026 recommendation | Grade | Population / context | Source-verified action | Retrieval terms |
|---|---|---|---|---|
| 12.20 T1D clause | A | Type 1 diabetes | Optimize glucose management to prevent or delay neuropathy. | neuropathy prevention T1D, grade A |
| 12.20 T2D clause | C | Type 2 diabetes | Optimize glucose management to slow neuropathy progression. | neuropathy progression T2D, grade C, lower certainty |
| 12.20 risk-factor clause | B | People with diabetes and neuropathy risk | Optimize weight, blood pressure, and lipid management to reduce risk or slow progression of diabetic neuropathy. | weight BP lipid neuropathy, grade B |
| 12.21 DPN pain clause | B | Diabetic peripheral neuropathy pain | Assess and treat pain related to DPN. | painful DPN, assess and treat pain, grade B |
| 12.21 autonomic symptoms clause | E | Autonomic neuropathy symptoms | Assess and treat symptoms of autonomic neuropathy to improve quality of life. | autonomic neuropathy symptoms, grade E |
| 12.22 initial pharmacotherapy clause | A | Neuropathic pain in diabetes | Gabapentinoids, SNRIs, TCAs, and sodium channel blockers are recommended as initial pharmacologic treatments. | gabapentinoid, SNRI, TCA, sodium channel blocker, grade A |
| 12.22 combination clause | A | Neuropathic pain in diabetes needing additional relief | Combinations of these medication classes can provide additional relief. | combination therapy neuropathic pain, grade A |
| 12.22 opioid caution clause | B | Neuropathic pain in diabetes | Opioids, including tramadol and tapentadol, should not be used except in rare circumstances because of adverse-event potential. | opioids, tramadol, tapentadol, rare circumstances, grade B |

## Foot Care And PAD

| ADA 2026 recommendation | Grade | Population / context | Source-verified action | Retrieval terms |
|---|---|---|---|---|
| 12.23 | A | People with diabetes | Perform comprehensive foot evaluation at least annually to identify ulcer and amputation risk factors. | annual foot exam, grade A |
| 12.24 | B | Foot examination | Include skin inspection, foot deformity assessment, neurologic assessment using 10-g monofilament or Ipswich touch test plus another assessment, and vascular assessment including leg/foot pulses. | foot exam components, monofilament, pulses |
| 12.25 | A | Sensory loss or prior ulceration/amputation | Inspect feet at every visit. | high-risk foot every visit, grade A |
| 12.26 | B | Foot/PAD risk history | Obtain prior history of ulceration, amputation, Charcot foot, angioplasty or vascular surgery, smoking, retinopathy, renal disease, and current neuropathy or vascular symptoms. | foot risk history, claudication |
| 12.27 | B | PAD screening | Initial PAD screening should assess pulses, capillary refill, dependent rubor, elevation pallor, and venous filling time; concerning symptoms or decreased/absent pulses should prompt ABI with toe pressures and further vascular assessment. | PAD screening, ABI, toe pressure |
| 12.28 | B | Foot ulcers or high-risk feet | Use an interprofessional approach facilitated by a podiatrist with appropriate team members. | podiatrist, high-risk foot, interprofessional |
| 12.29 referral clause | B | People who smoke with prior lower-extremity complications, LOPS, structural abnormalities, or PAD | Refer to foot care specialists for preventive care and lifelong surveillance. | specialist referral, lifelong surveillance |
| 12.29 smoking-cessation clause | A | Same high-risk smoking population | Provide smoking-cessation information and refer for smoking-cessation counseling. | smoking cessation, foot PAD, grade A |

## Lower-Certainty Or Consensus Rows In Section 12

When users ask "哪些證據等級較低" within Section 12, call out the following without implying they are unimportant:

- Grade C: ADA 12.20 for optimizing glucose management to slow neuropathy progression in type 2 diabetes.
- Grade E: ADA 12.15 and 12.16 for vision rehabilitation support; ADA 12.21 autonomic symptom treatment.
- Grade B rows: several screening, follow-up, foot/PAD, opioid-caution, and pain-assessment recommendations. Phrase these as source-supported recommendations with lower certainty than Grade A, not as weak or optional unless ADA wording says "may" or "reasonable."

## Answering Notes

- For `嚴重眼病變治療 證據等級是？`, answer from 12.9-12.16 before discussing CKD or cardiometabolic drugs.
- For `糖尿病神經病變藥物的證據等級是？`, answer from 12.22 first, then add 12.20-12.21 if the user asks prevention or symptom treatment.
- For foot/PAD questions, keep ADA Section 12 foot/PAD rows separate from ADA Section 10 ASCVD medication rows unless the user asks antiplatelet/statin/BP treatment.
- Do not say there is no loaded guideline evidence for retinopathy or neuropathy when this card or [[../claims/ada-2026-retinopathy-foot-pad-claims]] is retrieved.

## Verification Notes

- Retinopathy treatment rows 12.9-12.16 were verified against the ADA 2026 Section 12 `Treatment` and `Visual Rehabilitation` recommendation blocks in local Markdown (`dc26s012.md`).
- Neuropathy treatment rows 12.20-12.22 were verified against the ADA 2026 Section 12 `NEUROPATHY` treatment recommendation block in local Markdown (`dc26s012.md`).
- Foot/PAD rows 12.23-12.29 were verified against the ADA 2026 Section 12 `FOOT CARE` recommendation block in local Markdown (`dc26s012.md`) and cross-checked with [[../concepts/diabetes-foot-care-pad]].
