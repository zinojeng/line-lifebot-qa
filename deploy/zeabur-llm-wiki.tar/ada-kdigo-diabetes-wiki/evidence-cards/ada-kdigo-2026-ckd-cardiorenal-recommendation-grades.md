---
title: ADA KDIGO 2026 CKD Cardiorenal Recommendation Grades
type: evidence-card
created: 2026-05-20
updated: 2026-05-20
tags: [ada, kdigo, diabetes, ckd, evidence-card, recommendation-grade, sglt2i, glp1, finerenone, metformin, acei-arb]
sources:
  - /Users/ander/Documents/medical/guidelines/ada/dc26s009.md
  - /Users/ander/Documents/medical/guidelines/ada/dc26s010.md
  - /Users/ander/Documents/medical/guidelines/ada/dc26s011.md
  - /Users/ander/Documents/medical/guidelines/kdigo/KDIGO-2026-Diabetes-and-CKD-Guideline-Update-Public-Review-Draft-March-2026.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-20
status: active
obsidian_type: relationship
aliases:
  - ADA 11.7a
  - ADA 11.7b
  - ADA 11.11a
  - ADA 11.11b
  - ADA 10.40a
  - KDIGO 4.3.1
  - KDIGO 4.3.6
  - KDIGO 4.4.1
  - KDIGO 4.5.1
  - KDIGO 4.6.1
  - strong recommendation diabetes CKD
  - lower certainty evidence diabetes CKD
  - 哪些是 strong recommendation
  - 哪些證據等級較低
  - 建議等級
  - 證據等級
  - 1A
  - 1B
  - Grade A
  - Grade B
  - Grade C
entities:
  - ADA 2026
  - KDIGO 2026
  - SGLT2 inhibitor
  - GLP-1 receptor agonist
  - GLP-1-based therapy
  - finerenone
  - nonsteroidal MRA
  - metformin
  - ACE inhibitor
  - ARB
  - eGFR
  - UACR
  - albuminuria
  - ASCVD
  - dialysis
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware evidence-card page for ADA KDIGO 2026 CKD Cardiorenal Recommendation Grades; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 4 listed source(s) before changing recommendations."
related: 
  - "drugs/sglt2i-egfr-under-20-not-on-dialysis"
  - "comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd"
  - "comparisons/ada-kdigo-2026-evidence-strength-map"
  - "drugs/glp1-based-therapy-on-dialysis"
  - "concepts/diabetes-ckd-risk-stratification"
  - evidence-ledger/ckd-cardiorenal-ledger
---

# ADA KDIGO 2026 CKD Cardiorenal Recommendation Grades

Use this evidence card when LINE users ask which ADA/KDIGO recommendations are
strong, which are lower-certainty, or what exact recommendation numbers support
SGLT2i, GLP-1RA, finerenone, metformin, ACEi/ARB, eGFR, UACR, dialysis, or
cardiorenal protection in type 2 diabetes with CKD.

Scope: ADA 2026 plus KDIGO 2026 public-review draft only. KDIGO 2026 remains a
draft until final publication.

## Quick Answer For The Example Case

For a 58-year-old person with T2DM, eGFR 42, UACR 380 mg/g, established coronary
artery disease, HbA1c 7.8%, metformin, and basal insulin:

- Strong/high-certainty core: SGLT2 inhibitor for T2DM + CKD if eGFR is at least
  20; ADA 11.7a is Grade A and KDIGO 4.3.1 is 1A.
- Strong/high-certainty core: ACEi or ARB for diabetes, hypertension, and
  albuminuria; ADA 11.6a includes Grade A for UACR at least 300 mg/g and/or
  eGFR below 60, while KDIGO 4.2.1 is 1B.
- Strong/high-certainty add-on when criteria fit: nonsteroidal MRA/finerenone
  for T2DM + CKD + albuminuria on RAS blockade with adequate eGFR and potassium;
  ADA 11.8 is Grade A and KDIGO 4.4.1 is 1A.
- Strong/high-certainty option: GLP-1RA/GLP-1-based therapy with proven CV or
  kidney benefit for high-risk T2DM + CKD; ADA 11.7b is Grade A and KDIGO 4.5.1
  is 1A.
- Lower-certainty or more conditional items: continuing SGLT2i below eGFR 20 in
  ADA 11.11a is Grade B for CKD progression and Grade C for CV benefits; GLP-1
  use on dialysis in ADA 11.11b is Grade C; ADA 10.40d combined SGLT2i + GLP-1RA
  is Grade B; KDIGO practice points usually do not carry GRADE strength.

## ADA 2026 11.7a - SGLT2i For T2DM With CKD

- Source file: `dc26s011.md`, ADA CKD section.
- Recommendation number: ADA 2026 11.7a.
- Grade: A.
- Applies to: type 2 diabetes plus CKD.
- Clinical action: use an SGLT2 inhibitor with demonstrated benefit; initiate
  when eGFR is at least 20 mL/min/1.73 m2 and continue until kidney failure.
- Retrieval terms: SGLT2i, eGFR 20, CKD progression, cardiovascular events,
  strong recommendation, Grade A.
- Related pages: [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]],
  [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]].

## KDIGO 2026 4.3.1 - SGLT2i For T2DM With CKD

- Source file: `KDIGO-2026-Diabetes-and-CKD-Guideline-Update-Public-Review-Draft-March-2026.md`.
- Recommendation number: KDIGO 2026 Recommendation 4.3.1.
- Grade: 1A.
- Applies to: adults with T2DM, CKD, and eGFR at least 20 mL/min/1.73 m2.
- Clinical action: treat with an SGLT2 inhibitor.
- Interpretation: this is a strong recommendation with high-certainty evidence
  in KDIGO GRADE language.
- Related pages: [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]],
  [[../comparisons/ada-kdigo-2026-evidence-strength-map]].

## KDIGO 2026 Practice Points 4.3.1 To 4.3.6 - SGLT2i Practical Use

- Source file: KDIGO 2026 draft.
- Recommendation type: practice points, not numbered GRADE recommendations.
- Key practical points:
  - Use SGLT2i primarily for cardio-kidney protection even when glycemic effect
    is modest.
  - Prefer agents with cardiorenal outcome data.
  - Withhold during prolonged fasting, major surgery, or critical illness when
    ketosis or hypovolemia risk is increased; restart when stable and eating.
  - Consider diuretic dose reduction and volume/BP reassessment in people at
    hypovolemia risk.
  - The early eGFR dip after starting SGLT2i is usually reversible and is not by
    itself a stop reason.
  - Practice Point 4.3.6 says continuing below eGFR 20 is reasonable unless not
    tolerated or kidney replacement therapy is started.
- Retrieval terms: sick day, surgery, ketosis, euglycemic DKA, volume depletion,
  eGFR dip, KRT.

## ADA 2026 11.11a - Continue SGLT2i Below eGFR 20 Before Dialysis

- Source file: `dc26s011.md`.
- Recommendation number: ADA 2026 11.11a.
- Grade: B for reducing CKD progression; C for cardiovascular benefits.
- Applies to: eGFR below 20 mL/min/1.73 m2 and not on dialysis.
- Clinical action: SGLT2i can be safely continued before dialysis if already
  used and tolerated.
- Interpretation: useful for "do I stop when eGFR drops under 20?" but lower
  certainty than ADA 11.7a / KDIGO 4.3.1 initiation guidance.

## ADA 2026 11.7b - GLP-1RA For T2DM With CKD

- Source file: `dc26s011.md`.
- Recommendation number: ADA 2026 11.7b.
- Grade: A.
- Applies to: T2DM plus CKD.
- Clinical action: use a GLP-1 agonist with demonstrated benefit to reduce kidney
  progression and cardiovascular risk.
- Retrieval terms: GLP-1RA, CKD, kidney progression, cardiovascular risk,
  Grade A.
- Related pages: [[../drugs/glp1-based-therapy-on-dialysis]],
  [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]].

## KDIGO 2026 4.5.1 - GLP-1-Based Therapy

- Source file: KDIGO 2026 draft.
- Recommendation number: KDIGO 2026 Recommendation 4.5.1.
- Grade: 1A.
- Applies to: T2DM with CKD at high risk of major CV or kidney events, or not at
  individualized glycemic target.
- Clinical action: use a GLP-1-based therapy with proven CV or kidney benefits.
- Interpretation: strong KDIGO recommendation; practice points emphasize ASCVD
  or UACR at least 100 mg/g despite foundational therapies, and glycemic targets
  using HbA1c or CGM.

## ADA 2026 11.11b - GLP-1-Based Therapy On Dialysis

- Source file: `dc26s011.md`.
- Recommendation number: ADA 2026 11.11b.
- Grade: C.
- Applies to: people on dialysis.
- Clinical action: GLP-1-based therapy not dependent on kidney clearance can be
  initiated or continued to reduce CV risk and mortality.
- Interpretation: this is lower-certainty than the general CKD GLP-1RA
  recommendation. Use careful wording and do not imply all GLP-1 agents are
  interchangeable in dialysis.

## ADA 2026 11.8 And KDIGO 2026 4.4.1 - Finerenone / Nonsteroidal MRA

- ADA source file: `dc26s011.md`.
- ADA recommendation number: ADA 2026 11.8.
- ADA grade: A.
- ADA action: use a nonsteroidal MRA shown effective in trials for CKD plus
  albuminuria if eGFR is at least 25, with potassium monitoring after starting.
- KDIGO source file: KDIGO 2026 draft.
- KDIGO recommendation number: Recommendation 4.4.1.
- KDIGO grade: 1A.
- KDIGO action: add nsMRA with proven kidney or CV benefit for T2DM, eGFR at
  least 25, normal potassium, albuminuria UACR at least 30 mg/g, and maximum
  tolerated RAS inhibitor.
- Interpretation: strong when albuminuria persists and potassium/eGFR criteria
  fit. In the example case, UACR 380 mg/g makes this highly relevant after ACEi
  or ARB optimization.

## ADA 2026 11.9 - Simultaneous SGLT2i Plus Finerenone

- Source file: `dc26s011.md`.
- Recommendation number: ADA 2026 11.9.
- Grade: B.
- Applies to: adults with T2DM, UACR at least 100 mg/g, eGFR 30-90, and on a
  renin-angiotensin system inhibitor.
- Clinical action: simultaneous initiation of SGLT2i plus finerenone can be
  considered for safety and albuminuria benefit.
- Interpretation: lower than Grade A; phrase as "can be considered" rather than
  as mandatory.

## ADA 2026 11.6a And KDIGO 2026 4.2.1 - ACEi Or ARB

- ADA source file: `dc26s011.md`.
- ADA recommendation number: ADA 2026 11.6a.
- ADA grade: B for moderately increased albuminuria; A when UACR is at least
  300 mg/g and/or eGFR is below 60.
- ADA action: use ACEi or ARB for nonpregnant diabetes plus hypertension with
  albuminuria; titrate to maximally tolerated dose where indicated.
- KDIGO source file: KDIGO 2026 draft.
- KDIGO recommendation number: Recommendation 4.2.1.
- KDIGO grade: 1B.
- KDIGO action: initiate ACEi or ARB in diabetes, hypertension, and albuminuria;
  titrate to highest approved tolerated dose.
- Monitoring notes: KDIGO practice points cover creatinine/eGFR and potassium
  monitoring after start or dose increase, and generally continue unless GFR
  falls more than 30% shortly after initiation or titration.

## ADA 2026 9.10 And 10.40 - ASCVD / CKD Glucose-Lowering Choice

- ADA source files: `dc26s009.md` and `dc26s010.md`.
- ADA 9.10 grade: A.
- ADA 9.10 action: in T2DM plus CKD with eGFR 20-60 or albuminuria, use SGLT2i
  or GLP-1RA with demonstrated benefit for glycemic management, CKD progression,
  and CV event reduction, independent of A1C.
- ADA 10.40a grade: A.
- ADA 10.40b grade: A for SGLT2i with CV benefit in T2DM plus ASCVD/risk
  factors/CKD.
- ADA 10.40c grade: A for GLP-1RA with CV benefit in T2DM plus ASCVD/risk
  factors/CKD.
- ADA 10.40d grade: B for combined SGLT2i plus GLP-1RA to additively reduce
  adverse cardiovascular and kidney events.
- Interpretation: individual drug-class indications are strong; combination as
  additive strategy is lower-certainty/conditional.

## KDIGO 2026 2.1.1 And Practice Points - HbA1c / CGM In CKD

- KDIGO source file: KDIGO 2026 draft.
- Recommendation number: KDIGO Recommendation 2.1.1.
- Grade: 1C.
- Action: use HbA1c to monitor glycemic control in diabetes with CKD.
- Practice points: measure HbA1c twice yearly when stable, up to four times
  yearly if not at target or after treatment changes; HbA1c reliability declines
  in CKD G4-G5 and dialysis; CGM-derived GMI can help when HbA1c does not match
  directly measured glycemia.
- Interpretation: HbA1c monitoring is recommended, but certainty is lower and
  advanced CKD/dialysis requires caution and often CGM context.

## KDIGO 2026 4.6.1 - Metformin In CKD

- KDIGO source file: KDIGO 2026 draft.
- Recommendation number: KDIGO Recommendation 4.6.1.
- Grade: 1B.
- Applies to: T2DM with CKD and eGFR at least 30 when individualized glycemic
  targets are not achieved despite SGLT2i and GLP-1-based therapies, or when
  those therapies cannot be used.
- Practice points: monitor eGFR more often when eGFR is below 60, adjust dose
  below 45 or in selected 45-59 situations, stop below 30 or when dialysis is
  initiated, and monitor long-term B12 risk.
- Interpretation: metformin remains useful for glycemia but is not the primary
  cardiorenal-protection answer in high-risk CKD with ASCVD.

## ADA 2026 10.45 - Metformin With Stable Heart Failure

- ADA source file: `dc26s010.md`.
- Recommendation number: ADA 2026 10.45.
- Grade: B.
- Applies to: T2DM with stable heart failure.
- Clinical action: metformin may be continued if eGFR remains above 30, but avoid
  in unstable or hospitalized heart failure.
- Interpretation: in the example case with eGFR 42, metformin continuation is
  generally compatible if stable and tolerated, but it is not the priority
  cardiorenal add-on.

## Lower-Certainty / Conditional Bucket For LINE Answers

When a user asks "哪些證據等級較低" after a CKD/ASCVD case, name the lower or
more conditional items clearly:

- ADA 11.11a: continuing SGLT2i below eGFR 20 before dialysis is Grade B for CKD
  progression and Grade C for CV benefit.
- ADA 11.11b: GLP-1-based therapy on dialysis is Grade C.
- ADA 11.9: simultaneous SGLT2i plus finerenone can be considered, Grade B.
- ADA 10.40d: combined SGLT2i plus GLP-1RA for additive CV/kidney event
  reduction is Grade B.
- KDIGO 2.1.1: HbA1c monitoring in diabetes with CKD is 1C, and accuracy is less
  reliable in advanced CKD/dialysis.
- KDIGO practice points are practical expert guidance, but should not be called
  "strong recommendations" unless paired with a numbered GRADE recommendation.

## Related Pages

- [[../comparisons/ada-kdigo-2026-evidence-strength-map]]
- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]
- [[../concepts/diabetes-ckd-risk-stratification]]
- [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]]
- [[../drugs/glp1-based-therapy-on-dialysis]]
