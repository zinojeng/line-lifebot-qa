---
title: ADA 2026 GDM Pharmacotherapy Recommendation Grades
type: evidence-card
created: 2026-05-22
updated: 2026-05-22
tags: [ada, pregnancy, gdm, pharmacotherapy, metformin, glyburide, insulin, evidence-card, recommendation-grade, line-qa]
sources:
  - concepts/diabetes-pregnancy-gdm-cgm.md
  - raw/guidelines/local-guideline-file-registry.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-22
status: active
obsidian_type: relationship
aliases:
  - Metformin in GDM evidence
  - GDM pharmacotherapy evidence card
  - gestational diabetes medication grades
  - 妊娠糖尿病 metformin 證據
entities:
  - ADA 2026
  - GDM
  - gestational diabetes
  - insulin
  - metformin
  - glyburide
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware evidence-card page for ADA 2026 GDM Pharmacotherapy Recommendation Grades; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 2 listed source(s) before changing recommendations."
related: 
  - "concepts/diabetes-pregnancy-gdm-cgm"
  - "claims/ada-2026-gdm-pharmacotherapy-claims"
  - "evidence-ledger/gdm-pharmacotherapy-ledger"
  - queries/gdm-pharmacotherapy-line-questions
---

# ADA 2026 GDM Pharmacotherapy Recommendation Grades

Use this card when LINE users ask about metformin, glyburide, insulin, oral
agents, or evidence strength for GDM/diabetes in pregnancy pharmacotherapy.
Related pages: [[../concepts/diabetes-pregnancy-gdm-cgm]],
[[../claims/ada-2026-gdm-pharmacotherapy-claims]],
[[../evidence-ledger/gdm-pharmacotherapy-ledger]].

## Source-Verified Recommendation Rows

In this card, Grade E is treated as lower-certainty expert consensus/clinical
experience compared with Grade A/B recommendations. Avoid expanding beyond the
source recommendation wording without checking the ADA grading system.

| ADA 2026 recommendation | Grade | Population | Source-verified clinical action | LINE answer role |
|---|---|---|---|---|
| 15.15 | A | GDM | Lifestyle behavior change is essential and may be enough for many; insulin should be added when needed to reach glycemic goals. | Start with lifestyle, then insulin if targets are not met. |
| 15.17 GDM clause | A | GDM | Insulin is the preferred agent for management of GDM. | State insulin is ADA 2026 first-preferred pharmacologic therapy. |
| 15.17 type 2 diabetes clause | B | Type 2 diabetes in pregnancy | Insulin is the preferred agent for management of type 2 diabetes in pregnancy. | Separate from GDM if the user asks broadly about diabetes in pregnancy. |
| 15.21 placenta-crossing clause | A | Diabetes in pregnancy | Metformin and glyburide, individually or in combination, should not be used as first-line agents because both cross the placenta. | Explain why metformin/glyburide are not first-line, without saying they are absolutely forbidden. |
| 15.21 glycemic-sufficiency clause | B | Diabetes in pregnancy | Metformin and glyburide may not be sufficient to achieve glycemic goals. | Add that glucose targets may still require insulin or clinician adjustment. |
| 15.21 other-agent clause | E | Diabetes in pregnancy | Other oral and noninsulin injectable glucose-lowering medications lack long-term safety data and are not recommended. | Use as a safety boundary for unsupported noninsulin/nonoral extrapolation. |

## Suggested LINE Answer Skeleton

When the question is `Metformin in GDM evidence` or similar:

1. ADA 2026 places lifestyle behavior change first for GDM and adds insulin if
   glycemic goals are not met.
2. ADA 2026 says insulin is the preferred pharmacologic agent for GDM.
3. Metformin and glyburide are not first-line because both cross the placenta.
4. They also may not be sufficient to achieve pregnancy glycemic goals.
5. This does not mean metformin is always absolutely prohibited; it means it is
   not the ADA 2026 first-line choice and should be individualized with the
   obstetric/endocrine care team.

## Verification Notes

- Verified against ADA 2026 Section 15 local Markdown `dc26s015.md`, lines
  346-355.
- This card does not include non-ADA sources. If the user asks for local
  hospital policy or non-ADA guideline comparisons, create a research request.
