---
title: ADA 2026 Lipid ASCVD Recommendation Grades
type: evidence-card
created: 2026-05-22
updated: 2026-05-22
tags: [ada, diabetes, evidence-card, recommendation-grade, ascvd, lipid, statin]
sources:
  - raw/guidelines/local-guideline-file-registry.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-22
status: active
obsidian_type: relationship
aliases:
  - ADA 2026 lipid ASCVD recommendation grades
  - ADA 2026 LDL target diabetes ASCVD
  - diabetes ASCVD lipid targets
  - LDL cholesterol goal diabetes ASCVD
  - statin recommendation grade diabetes
  - ADA 10.17
  - ADA 10.18
  - ADA 10.19
  - ADA 10.20
  - ADA 10.21
  - ADA 10.22
  - ADA 10.23
  - ADA 10.24
  - ADA 10.25
  - ADA 10.26
  - ADA 10.27
  - ADA 10.28a
  - ADA 10.28b
  - 糖尿病 ASCVD LDL 目標
  - 糖尿病 statin 建議等級
entities:
  - ADA 2026
  - ASCVD
  - LDL cholesterol
  - statin
  - ezetimibe
  - PCSK9 inhibitor
  - bempedoic acid
  - inclisiran
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware evidence-card page for ADA 2026 Lipid ASCVD Recommendation Grades; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 1 listed source(s) before changing recommendations."
related: 
  - "guidelines/ada-standards-of-care-2026"
  - "_meta/aliases"
---

# ADA 2026 Lipid ASCVD Recommendation Grades

Use this evidence card when a user asks for ADA 2026 diabetes lipid targets, LDL goals, statin intensity, or recommendation grades in primary prevention with ASCVD risk factors or secondary prevention with established ASCVD.

Verified source: ADA Standards of Care in Diabetes 2026 Section 10 (`dc26s010.md`) via [[../raw/guidelines/local-guideline-file-registry]]. Related routing pages: [[../guidelines/ada-standards-of-care-2026]] and [[../_meta/aliases]].

## Source-Verified ADA 2026 Recommendation Cards

| ADA 2026 recommendation | Grade | Population / context | Source-verified action or threshold | Retrieval terms |
|---|---|---|---|---|
| 10.17 | A | People starting or changing statins or other lipid-lowering therapy | Obtain a lipid profile at initiation, 4-12 weeks after initiation or dose change, and annually thereafter. | lipid profile monitoring, statin follow-up |
| 10.18 | A | Diabetes age 40-75 years without ASCVD | Use moderate-intensity statin therapy plus lifestyle therapy. | primary prevention, moderate-intensity statin |
| 10.19 | C | Diabetes age 20-39 years with additional ASCVD risk factors | It may be reasonable to initiate statin therapy plus lifestyle therapy. | young adults diabetes statin, ASCVD risk factors |
| 10.20 | A | Diabetes age 40-75 years at higher cardiovascular risk, including one or more additional ASCVD risk factors | High-intensity statin therapy is recommended to reduce LDL cholesterol by >=50% from baseline and obtain LDL cholesterol goal <70 mg/dL (<1.8 mmol/L). | LDL <70, high-intensity statin, primary prevention high risk |
| 10.21 | B | Diabetes age 40-75 years at higher cardiovascular risk, especially multiple additional ASCVD risk factors and LDL cholesterol >=70 mg/dL on maximum tolerated statin | It may be reasonable to add ezetimibe or a PCSK9 inhibitor to maximum tolerated statin therapy. | ezetimibe, PCSK9, LDL >=70 |
| 10.22 | B | Diabetes age >75 years already on statin therapy | It is reasonable to continue statin treatment. | older adults, continue statin |
| 10.23 | C | Diabetes age >75 years not already on statin | It may be reasonable to initiate moderate-intensity statin after discussion of benefits and risks. | older adults, initiate statin |
| 10.24 | A | Diabetes with statin intolerance | Bempedoic acid is recommended to reduce cardiovascular event rates as an alternative cholesterol-lowering plan. | statin intolerance, bempedoic acid |
| 10.25 stop/avoid clause | B | In most circumstances before conception, or sexually active individuals of childbearing potential not using reliable contraception | Stop lipid-lowering agents prior to conception and avoid them without reliable contraception. | pregnancy, contraception, lipid-lowering |
| 10.25 selected-exception clause | E | Selected circumstances such as familial hypercholesterolemia, familial hypertriglyceridemia, prior ASCVD event, or history of pancreatitis | Lipid-lowering therapy may be continued when benefits outweigh risks. | pregnancy exception, familial hypercholesterolemia, prior ASCVD |
| 10.26 | A | Diabetes of all ages with ASCVD | Add high-intensity statin therapy to lifestyle therapy. | secondary prevention, diabetes ASCVD statin |
| 10.27 | B | Diabetes with ASCVD | High-intensity statin therapy is recommended to obtain LDL cholesterol reduction >=50% from baseline and LDL cholesterol goal <55 mg/dL (<1.4 mmol/L); add ezetimibe or PCSK9 inhibitor with proven benefit if goal is not achieved on maximum tolerated statin therapy. | LDL <55, secondary prevention, ezetimibe, PCSK9 |
| 10.28a | E | Individuals who do not tolerate intended statin intensity | Use the maximum tolerated statin dose. | statin intolerance, maximum tolerated statin |
| 10.28b PCSK9 monoclonal antibody clause | A | Diabetes with ASCVD and statin intolerance | Consider PCSK9 monoclonal antibody therapy as alternative cholesterol-lowering therapy. | PCSK9 monoclonal antibody, statin intolerance |
| 10.28b bempedoic acid clause | A | Diabetes with ASCVD and statin intolerance | Consider bempedoic acid therapy as alternative cholesterol-lowering therapy. | bempedoic acid, statin intolerance |
| 10.28b inclisiran siRNA clause | E | Diabetes with ASCVD and statin intolerance | Consider PCSK9 inhibitor therapy with inclisiran siRNA as alternative cholesterol-lowering therapy. | inclisiran, statin intolerance |

## Retrieval Summary

- Primary prevention age 40-75 without ASCVD: route to ADA 10.18 and 10.20 depending on ASCVD risk-factor burden.
- Established ASCVD: route to ADA 10.26 and 10.27; the verified LDL cholesterol goal is <55 mg/dL (<1.4 mmol/L) with >=50% reduction from baseline. The local ADA 2026 `dc26s010.md` extraction labels recommendation 10.27 as Grade B; recheck the official ADA PDF before external quotation if a user reports a conflicting Grade A citation.
- Higher cardiovascular risk without ASCVD: route to ADA 10.20; the verified LDL cholesterol goal is <70 mg/dL (<1.8 mmol/L) with >=50% reduction from baseline.
- Statin intolerance: route to ADA 10.24, 10.28a, and 10.28b; distinguish bempedoic acid, PCSK9 monoclonal antibodies, and inclisiran evidence grades.

## Smoke-Test Terms

- `ADA 2026 diabetes ASCVD LDL target statin recommendation grade`
- `糖尿病 ASCVD LDL 55 statin`
- `diabetes LDL <70 high intensity statin ADA 10.20`
- `statin intolerance diabetes bempedoic acid PCSK9 inclisiran grade`

## Verification Notes

Raw verification was performed against ADA 2026 Section 10 (`dc26s010.md`) recommendation blocks 10.17-10.28b; separately graded clauses in 10.25 and 10.28b are split into distinct rows to avoid mixed-grade ambiguity. Recommendation 10.27 was specifically rechecked in the local ADA 2026 Markdown and is recorded there as Grade B; if using this row outside this wiki/LINE workflow, verify against the official ADA PDF. KDIGO 2026 draft was checked for CKD lipid context and provides practice points rather than the exact ADA lipid recommendation grades summarized here. Do not generalize these ADA 2026 thresholds to non-ADA guideline systems without rechecking the relevant source.
