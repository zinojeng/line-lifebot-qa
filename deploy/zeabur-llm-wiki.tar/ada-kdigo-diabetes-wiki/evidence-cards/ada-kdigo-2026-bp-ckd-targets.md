---
title: ADA KDIGO 2026 Diabetes CKD Blood Pressure Targets
type: evidence-card
created: 2026-05-22
updated: 2026-05-22
tags: [ada, kdigo, diabetes, ckd, evidence-card, recommendation-grade, blood-pressure, hypertension, acei-arb]
sources:
  - raw/guidelines/local-guideline-file-registry.md
evidence_level: draft-guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-22
status: active
obsidian_type: relationship
aliases:
  - ADA KDIGO 2026 BP CKD targets
  - diabetes CKD blood pressure target
  - diabetic kidney disease BP target
  - ADA 2026 CKD blood pressure goal
  - KDIGO diabetes CKD BP target
  - ADA 11.5
  - ADA 11.6a
  - ADA 10.4
  - ADA 10.6
  - ADA 10.10
  - KDIGO 4.2.1
  - 糖尿病 CKD 血壓目標
  - 糖尿病腎病變 血壓 130/80
entities:
  - ADA 2026
  - KDIGO 2026
  - CKD
  - blood pressure
  - hypertension
  - ACE inhibitor
  - ARB
  - albuminuria
  - UACR
  - eGFR
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware evidence-card page for ADA KDIGO 2026 Diabetes CKD Blood Pressure Targets; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 1 listed source(s) before changing recommendations."
related: 
  - "concepts/diabetes-ckd-risk-stratification"
  - "evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades"
  - "guidelines/kdigo-diabetes-management-in-ckd-2026"
  - "_meta/aliases"
---

# ADA KDIGO 2026 Diabetes CKD Blood Pressure Targets

Use this evidence card when a user asks for ADA/KDIGO blood-pressure targets in diabetes with CKD, hypertension drug thresholds, ACEi/ARB indications, or recommendation grades. KDIGO 2026 is a public-review draft in this wiki; state that draft status when citing KDIGO-specific recommendations.

Verified sources: ADA 2026 Section 10 (`dc26s010.md`), ADA 2026 Section 11 (`dc26s011.md`), and KDIGO 2026 Diabetes and CKD public-review draft via [[../raw/guidelines/local-guideline-file-registry]]. Related pages: [[../concepts/diabetes-ckd-risk-stratification]], [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]], [[../guidelines/kdigo-diabetes-management-in-ckd-2026]], and [[../_meta/aliases]].

## Source-Verified ADA / KDIGO Cards

| Source | Grade / status | Population / context | Source-verified action or threshold | Retrieval terms |
|---|---|---|---|---|
| ADA 2026 10.1 | A | Diabetes routine visits or elevated BP without diagnosed hypertension | Measure BP at every routine clinical visit, or at least every 6 months; confirm elevated BP using multiple readings including a separate day. Hypertension is defined as systolic BP >=130 mmHg or diastolic BP >=80 mmHg based on average of >=2 measurements on >=2 occasions. | hypertension diagnosis, BP measurement |
| ADA 2026 10.2 | A | Diabetes with hypertension | Counsel home BP monitoring after appropriate education. | home BP monitoring |
| ADA 2026 10.3 | B | Diabetes with hypertension | Individualize BP goals through shared decision-making that addresses cardiovascular risk, potential adverse medication effects, and individual preferences. | BP goal individualization, shared decision-making |
| ADA 2026 10.4 | A | Diabetes with hypertension | If safely attained, the on-treatment BP goal is <130/80 mmHg; systolic BP goal <120 mmHg should be encouraged in individuals with high cardiovascular or kidney risk. | BP goal, <130/80, SBP <120 high kidney risk |
| ADA 2026 10.6 | A | Confirmed office-based BP >=130/80 mmHg | Initiate pharmacologic therapy and titrate to individualized BP goal. | start BP meds, 130/80 |
| ADA 2026 10.7 | A | Confirmed office-based BP >=150/90 mmHg | Promptly initiate and titrate two drugs or a single-pill combination demonstrated to reduce cardiovascular events in diabetes. | two drugs, 150/90 |
| ADA 2026 10.8 | A | Diabetes with hypertension; albuminuria or coronary artery disease context | Use drug classes demonstrated to reduce cardiovascular events; ACE inhibitors or ARBs are recommended first-line for hypertension in diabetes with albuminuria or coronary artery disease. | ACEi, ARB, albuminuria, CAD |
| ADA 2026 10.10 moderately increased albuminuria clause | B | Nonpregnant diabetes with hypertension and UACR 30-299 mg/g creatinine | ACE inhibitor or ARB is recommended to maximally tolerated dose. | UACR 30-299, ACEi ARB grade B |
| ADA 2026 10.10 severely increased albuminuria/eGFR clause | A | Nonpregnant diabetes with hypertension and UACR >=300 mg/g creatinine and/or eGFR <60 mL/min/1.73 m2 | ACE inhibitor or ARB is strongly recommended to maximally tolerated dose to prevent CKD progression and reduce cardiovascular events. | UACR >=300, eGFR <60, ACEi ARB grade A |
| ADA 2026 11.5 | A | Diabetes with CKD | If safely attained, on-treatment BP goal for people with CKD is <130/80 mmHg; systolic BP goal <120 mmHg and/or reduction in BP variability should be encouraged. | CKD BP goal, BP variability, <130/80, SBP <120 |
| ADA 2026 11.6a moderately increased albuminuria clause | B | Nonpregnant diabetes with hypertension and UACR 30-299 mg/g creatinine | ACE inhibitor or ARB is recommended to maximally tolerated dose. | ADA 11.6a, UACR 30-299, grade B |
| ADA 2026 11.6a severely increased albuminuria/eGFR clause | A | Nonpregnant diabetes with hypertension and UACR >=300 mg/g creatinine and/or eGFR <60 mL/min/1.73 m2 | ACE inhibitor or ARB is strongly recommended to maximally tolerated dose to prevent CKD progression and reduce cardiovascular events. | ADA 11.6a, UACR >=300, eGFR <60, grade A |
| KDIGO 2026 Recommendation 4.2.1 | 1B; public-review draft | Diabetes, hypertension, and albuminuria | Initiate ACEi or ARB and titrate to the highest approved tolerated dose. | KDIGO 4.2.1, ACEi ARB 1B |
| KDIGO 2026 Practice Point 4.2.1 | Practice point; public-review draft | Diabetes, hypertension, and no albuminuria | It may be reasonable to treat with RAS inhibitors (ACEi or ARB). | no albuminuria, RASi |
| KDIGO 2026 Practice Point 4.2.2 | Practice point; public-review draft | Diabetes, albuminuria, and normal BP | ACEi or ARB may be considered. | albuminuria normal BP |
| KDIGO 2026 CKD/CVD risk discussion | Draft narrative | Diabetes and/or CKD | Notes that diabetes and/or CKD are considered higher risk and recommended for a BP target of <130/80 mmHg regardless of 10-year risk score. | KDIGO BP target <130/80 |

## ADA Section 10 And 11 Cross-Reference Note

ADA 2026 Section 11 recommendation 11.6a restates the ACEi/ARB albuminuria and eGFR grade split from ADA Section 10 recommendation 10.10 in the CKD chapter context. This card keeps both citations because users may ask by either cardiovascular-risk-section number (10.10) or CKD-section number (11.6a).

## Retrieval Summary

- For a quick diabetes + CKD BP target answer, route to ADA 11.5: <130/80 mmHg if safely attained, with SBP <120 mmHg encouraged in high cardiovascular or kidney risk when appropriate.
- For when to start BP medication in diabetes, route to ADA 10.6 (>=130/80 mmHg) and ADA 10.7 (>=150/90 mmHg two-drug or single-pill combination strategy).
- For ACEi/ARB in diabetes + CKD, route to ADA 10.10 / 11.6a and KDIGO 4.2.1; preserve the different grade systems: ADA B/A by albuminuria/eGFR severity; KDIGO 1B for diabetes + hypertension + albuminuria.
- For KDIGO content, state draft status and separate graded recommendations from practice points.

## Smoke-Test Terms

- `ADA 2026 KDIGO diabetes CKD blood pressure target recommendation`
- `糖尿病 CKD 血壓目標 130/80 120`
- `ADA 11.5 BP goal CKD diabetes`
- `KDIGO 4.2.1 ACEi ARB diabetes hypertension albuminuria 1B`
- `UACR 30 300 ACE inhibitor ARB grade diabetes`

## Verification Notes

Raw verification was performed against ADA 2026 Section 10 (`dc26s010.md`) recommendations 10.1-10.12, including the source line break where 10.3 is Grade B and 10.4 is Grade A. ADA 2026 Section 11 (`dc26s011.md`) recommendations 11.5-11.6a were checked; separately graded clauses in 10.10 and 11.6a are split into distinct rows. KDIGO 2026 public-review draft Recommendation 4.2.1 plus related practice points were also checked. This card intentionally does not merge KDIGO BP-in-CKD guidance outside the diabetes-specific draft; recheck the dedicated KDIGO BP guideline before answering non-diabetes CKD BP questions.
