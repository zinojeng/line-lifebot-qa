---
title: KDIGO Diabetes Management in CKD 2026
type: guideline
created: 2026-05-19
updated: 2026-05-20
tags: [source, kdigo, diabetes, ckd, diabetic-kidney-disease, draft-guideline, 2026]
sources:
  - ../raw/guidelines/kdigo-diabetes-ckd-2026-source-map.md
  - https://kdigo.org/guidelines/diabetes-ckd/
evidence_level: draft-guideline
clinical_use: clinical-reference
confidence: medium
last_verified: 2026-05-19
status: draft
obsidian_type: source
aliases:
  - KDIGO 2026
  - KDIGO Diabetes CKD 2026
  - KDIGO Diabetes Management in CKD
  - KDIGO 2026 public review draft
  - KDIGO diabetes kidney guideline
  - KDIGO 糖尿病 CKD 2026
  - KDIGO 腎臟糖尿病指引
  - KDIGO A1C reliability CKD
  - KDIGO metformin eGFR
  - KDIGO finerenone albuminuria
  - KDIGO CGM CKD
entities:
  - KDIGO
  - diabetes
  - CKD
  - diabetic kidney disease
  - eGFR
  - UACR
  - albuminuria
  - glycemic monitoring
  - A1C reliability
  - hypoglycemia
  - CGM
  - SGLT2 inhibitor
  - GLP-1 receptor agonist
  - metformin
  - finerenone
  - dialysis
  - kidney failure
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware guideline page for KDIGO Diabetes Management in CKD 2026; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 2 listed source(s) before changing recommendations."
related: 
  - "concepts/diabetes-ckd-risk-stratification"
  - "comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd"
  - "drugs/sglt2i-egfr-under-20-not-on-dialysis"
  - "drugs/glp1-based-therapy-on-dialysis"
---

# KDIGO Diabetes Management in CKD 2026

## Summary

KDIGO describes the 2026 Diabetes Management in CKD guideline as a public-review draft. It should be treated as draft guidance until KDIGO publishes the final version.

The KDIGO page says the update reflects clinical and scientific developments since the KDIGO 2022 Diabetes Guideline and focuses on definitions, prevention, risk assessment, glycemic monitoring, and comprehensive pharmacotherapy.

## Local Source

The local KDIGO 2026 draft Markdown file and two ADA/KDIGO synthesis files are registered in [[../raw/guidelines/local-guideline-file-registry]] and stored at `/Users/ander/Documents/medical/guidelines/kdigo`.

## Use In This Wiki

- Use this page to track the KDIGO 2026 update.
- Use KDIGO 2022 and the ADA-KDIGO 2022 consensus report as the published baseline until the final 2026 guideline is available.
- For current teaching or clinical reference, explicitly label KDIGO 2026 content as draft if using it.

## Key Draft Focus Areas

- Definitions, prevention, and risk assessment.
- Glycemic monitoring.
- Comprehensive pharmacotherapy.

## Links

- [[../raw/guidelines/kdigo-diabetes-ckd-2026-source-map]]
- [[ada-standards-of-care-2026]]
- [[../concepts/diabetes-ckd-risk-stratification]]
- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]
- [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]]
- [[../drugs/glp1-based-therapy-on-dialysis]]

## Uncertain Or Pending

- Final recommendation wording, strength, and evidence grading are pending final publication.
- Do not use this page alone for clinical decision support until final KDIGO publication is imported and reconciled.
