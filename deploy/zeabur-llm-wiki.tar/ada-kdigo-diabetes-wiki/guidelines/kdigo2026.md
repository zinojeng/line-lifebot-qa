---
title: KDIGO 2026
type: guideline
created: 2026-05-19
updated: 2026-05-19
tags: [source, kdigo, diabetes, ckd, draft-guideline, 2026, alias]
sources:
  - kdigo-diabetes-management-in-ckd-2026.md
evidence_level: draft-guideline
clinical_use: clinical-reference
confidence: medium
last_verified: 2026-05-19
status: draft
obsidian_type: source
summary: "Source-aware guideline page for KDIGO 2026; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 1 listed source(s) before changing recommendations."
related: 
  - "comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd"
aliases: 
  - "KDIGO 2026 alias page"
  - "KDIGO diabetes CKD 2026 short page"
entities: 
  - "KDIGO 2026"
  - "KDIGO"
  - "diabetes"
  - "CKD"
  - "Diabetes Management in CKD"
owner_agent: hermes
write_policy: source-aware-review
---

# KDIGO 2026

Short alias page for [[kdigo-diabetes-management-in-ckd-2026]].

KDIGO 2026 Diabetes Management in CKD is tracked as a draft/public-review source until the final guideline is published. Use [[../raw/guidelines/kdigo-diabetes-ckd-2026-source-map]] and [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] for source and crosswalk context.
