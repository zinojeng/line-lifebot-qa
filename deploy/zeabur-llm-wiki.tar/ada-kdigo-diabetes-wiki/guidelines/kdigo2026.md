---
title: KDIGO 2026
type: guideline
created: 2026-05-19
updated: 2026-05-19
tags: [source, kdigo, diabetes, ckd, draft-guideline, 2026, alias]
sources:
  - kdigo-diabetes-management-in-ckd-2026.md
evidence_level: draft-guideline
clinical_use: clinical-reference
confidence: medium
last_verified: 2026-05-19
status: draft
obsidian_type: source
---

# KDIGO 2026

Short alias page for [[kdigo-diabetes-management-in-ckd-2026]].

KDIGO 2026 Diabetes Management in CKD is tracked as a draft/public-review source until the final guideline is published. Use [[../raw/guidelines/kdigo-diabetes-ckd-2026-source-map]] and [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] for source and crosswalk context.
