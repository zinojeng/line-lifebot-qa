---
title: ADA Standards of Care in Diabetes 2026
type: guideline
created: 2026-05-19
updated: 2026-05-20
tags: [source, ada, diabetes, standards-of-care, guideline, 2026]
sources:
  - ../raw/guidelines/ada-standards-of-care-2026-source-map.md
  - https://professional.diabetes.org/standards-of-care
evidence_level: guideline
clinical_use: clinical-reference
confidence: high
last_verified: 2026-05-19
status: active
obsidian_type: source
aliases:
  - ADA 2026
  - ADA Standards 2026
  - Standards of Care in Diabetes 2026
  - American Diabetes Association 2026 Standards
  - ADA guideline 2026
  - ADA S7 diabetes technology
  - ADA S9 pharmacologic treatment
  - ADA S10 cardiovascular risk
  - ADA S11 chronic kidney disease
  - ADA 2026 糖尿病照護標準
  - ADA 2026 指引
  - ADA older adults diabetes
  - ADA pregnancy diabetes
  - ADA hospital steroid hyperglycemia
  - ADA hypoglycemia
  - ADA metformin CKD
  - ADA finerenone CKD
entities:
  - ADA
  - diabetes
  - Standards of Care
  - A1C
  - CGM
  - AID
  - obesity
  - pharmacologic therapy
  - SGLT2 inhibitor
  - GLP-1 receptor agonist
  - metformin
  - finerenone
  - hypoglycemia
  - steroid hyperglycemia
  - glucocorticoid
  - ASCVD
  - heart failure
  - CKD
  - eGFR
  - UACR
  - older adults
  - pregnancy
  - hospital care
owner_agent: hermes
write_policy: hermes-maintained
---

# ADA Standards of Care in Diabetes 2026

## Summary

The ADA Standards of Care in Diabetes 2026 is the ADA's current annually updated clinical practice guideline set for diabetes care. It covers population health, diagnosis, prevention, medical evaluation, behavior and well-being, glycemic goals, technology, obesity, pharmacologic therapy, cardiovascular risk, CKD risk, microvascular complications, older adults, pediatrics, pregnancy, inpatient care, and advocacy.

Use this page as the ADA 2026 navigation hub. Use [[../raw/guidelines/ada-standards-of-care-2026-source-map]] for official source links and section names.

## Local Source

The local ADA 2026 Markdown corpus is registered in [[../raw/guidelines/local-guideline-file-registry]] and stored at `/Users/ander/Documents/medical/guidelines/ada`.

The local ADA 2025 vs 2026 comparison corpus is registered in [[../raw/comparisons/ada-2025-vs-2026-comparison-registry]] and stored at `/Users/ander/openclaw-research/ada20252026`.

## High-Value Sections For Hermes Diabetes Work

- Section 6: glycemic goals, hypoglycemia, and hyperglycemic crises.
- Section 7: diabetes technology, including CGM and device-based care.
- Section 8: obesity and weight management.
- Section 9: pharmacologic approaches to glycemic treatment.
- Section 10: cardiovascular disease and risk management.
- Section 11: chronic kidney disease and risk management.
- Section 13: older adults.
- Section 16: diabetes care in the hospital.

## How To Use

- For diabetes with CKD questions, read this page with [[kdigo-diabetes-management-in-ckd-2026]] and [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]].
- For "what changed from ADA 2025?" questions, start with [[../comparisons/ada-2025-vs-2026-overview]].
- For ADA 2026 CKD drug updates, start with [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] and [[../drugs/glp1-based-therapy-on-dialysis]].
- For teaching, start with [[../teaching/ada-kdigo-2026-medical-student-brief]].
- For technology-focused education, connect to [[../concepts/diabetes-technology-cgm-aid]].

## Uncertain Or Pending

- Full section-level recommendation cards have not yet been imported.
- Exact recommendation numbers, thresholds, and drug-specific indications should be checked against the official ADA 2026 section pages before clinical use.
