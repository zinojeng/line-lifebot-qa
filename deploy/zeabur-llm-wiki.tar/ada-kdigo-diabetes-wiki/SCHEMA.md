# ADA-KDIGO Diabetes Wiki Schema

## Domain

This wiki maintains source-grounded knowledge for diabetes, endocrinology, chronic kidney disease, cardiorenal-metabolic care, diabetes technology, medical teaching, and patient education.

## Operating Principle

Memory stores how the user works. This wiki stores verifiable knowledge. Retrieval from raw sources is used to check evidence when the wiki is incomplete or contested.

## Directory Roles

- `raw/`: Immutable original or source-map materials. Do not overwrite or paraphrase into raw files after import.
- `guidelines/`: Guideline summary and navigation pages.
- `concepts/`: Reusable clinical concepts.
- `entities/`: Organizations, tools, committees, and named programs.
- `trials/`: Clinical trials and evidence summaries.
- `drugs/`: Drug class and drug-specific pages.
- `comparisons/`: Cross-guideline and cross-therapy comparison records.
- `evidence-cards/`: Fine-grained recommendation number, grade, threshold, and source-provenance cards for retrieval.
- `claims/`: Small claim registry pages with stable `claim_id`, source, grade, population, action, certainty bucket, and answer role.
- `evidence-ledger/`: Append-only timelines that record when claims changed, why they changed, and which source triggered the update.
- `teaching/`: Medical student, resident, and lecture-ready teaching material.
- `patient-education/`: Patient-facing education material in Traditional Chinese unless otherwise specified.
- `queries/`: High-value answers that should be preserved and reused.
- `mocs/`: Obsidian Map of Content pages for graph navigation.
- `evals/`: Synthetic QA and answer-regression registries. These are maintenance artifacts, not clinical source pages.
- `docs/`: Workflow notes for maintaining and using the wiki.
- `_meta/`: Retrieval policy, topic maps, aliases, and routing rules for Hermes-only workflows.
- `inbox/`: Staging area for research requests and query candidates before canonical writeback.
- `reports/`: Routine audit, stale-page, duplicate, and wiki-health reports.
- `HERMES.md`: Project-level Hermes behavior rules for this wiki.

## Required Frontmatter

Every maintained wiki page must begin with YAML frontmatter:

```yaml
---
title:
type: concept | guideline | trial | drug | comparison | evidence-card | claim | evidence-ledger | teaching | patient-education | query | source-map | meta | workflow | research-request
created:
updated:
tags:
sources:
evidence_level: guideline | draft-guideline | rct | meta-analysis | cohort | review | expert-opinion | local-practice | local-synthesis | source-map
clinical_use: teaching | clinical-reference | patient-education | slide-material | workflow
confidence: high | medium | low | uncertain
last_verified:
status: active | draft | needs-source | open | resolved | retired
obsidian_type: moc | source | concept | relationship | output | registry
aliases:
entities:
owner_agent:
write_policy:
---
```

## Naming Rules

- File names use English lowercase with hyphens.
- Use durable titles such as `ada-standards-of-care-2026.md`, not vague names such as `new-guideline.md`.
- Put source maps in `raw/guidelines/`.
- Put synthesized clinical pages outside `raw/`.
- Prefer updating an existing related page over creating a duplicate.

## Linking Rules

- Before creating a page, read `index.md`.
- Each maintained page should include at least 2 `[[wikilinks]]` unless it is a minimal raw source map.
- Use relative Markdown links for files when exporting outside Obsidian is important.
- Cross-guideline concepts should link both source guideline pages and relevant concept pages.
- Obsidian MOC pages should link to source maps, maintained concept pages, comparison pages, and high-value queries.
- `_meta/topic-map.md` should link topic neighborhoods to guideline, concept, drug, comparison, teaching, and raw fallback pages.
- Prefer local graph depth 1 for checking direct evidence links, and depth 2 for teaching or complex clinical query planning.

## Obsidian Type Tags

Use one primary Obsidian role tag per maintained page when practical:

- `#moc` - map of content or navigation page.
- `#source` - raw source map, registry, or source-grounded imported note.
- `#concept` - reusable medical concept.
- `#relationship` - comparison, crosswalk, synthesis, or interpretation page.
- `#output` - teaching, patient education, slide, or query result.

Use additional domain tags such as `#ada`, `#kdigo`, `#ckd`, `#cgm`, `#sglt2i`, or `#glp1` as needed. Keep role tags stable so Obsidian Graph View can group pages cleanly.

## Medical Evidence Rules

- Do not state a medical claim as settled unless a source supports it.
- Mark KDIGO 2026 material as `draft-guideline` until KDIGO publishes the final guideline.
- Mark inferred teaching implications as inference, not direct guideline statements.
- Use `last_verified` for time-sensitive guidance.
- Keep thresholds, recommendation numbers, medication indications, and contraindications tied to a cited source page or raw source.
- Prefer claim registry pages for recurrent recommendation-grade answers; each claim should have a stable `claim_id` and direct source provenance.
- Prefer evidence ledger entries over silent overwrites when a new source changes an old claim.
- Do not store identifiable patient data.

## Retrieval Rules

- For complex clinical queries, read `index.md` and `_meta/topic-map.md` before full-text search.
- Use `_meta/aliases.md` for common LINE wording, abbreviation variants, and canonical page routing.
- Use `_meta/typed-relationships.md` to decide whether a failure is a missing page, a missing alias, a missing route, or a claim-consistency issue.
- Apply `_meta/retrieval-policy.md` when choosing candidate pages.
- Prefer exact title, alias, entity, tag, topic-map, and wikilink evidence before embedding-style similarity.
- If wiki pages do not cover the correct guideline year, population, intervention, threshold, and source provenance, search raw guideline sources before answering.
- If the gap remains unresolved, create a Markdown request under `inbox/research-requests/` instead of inventing missing clinical facts.

## Forbidden

- Do not directly modify original raw materials.
- Do not create unsourced medical fact pages.
- Do not create empty stub pages under 5 meaningful lines unless they are source maps.
- Do not duplicate synonymous concept pages.
- Do not save transient chat content unless it has durable teaching or retrieval value.
- Do not mix output style preferences into clinical knowledge pages; place reusable formats in `teaching/` or a separate output-patterns wiki.

## Update Loop

1. Read `HERMES.md`, `SCHEMA.md`, `index.md`, `_meta/topic-map.md`, `_meta/aliases.md`, `_meta/retrieval-policy.md`, and the latest entries in `log.md`.
2. Search for existing pages before creating new ones.
3. Preserve original source metadata in `raw/`.
4. Add or update maintained wiki pages.
5. Add wikilinks and source references.
6. Update `index.md`, `_meta/topic-map.md`, or `_meta/aliases.md` when discoverability changes.
7. Update `log.md`.
8. List new, modified, and uncertain items in the final work report.
