---
title: Diabetes Technology CGM and AID
type: concept
created: 2026-05-19
updated: 2026-05-20
tags: [concept, diabetes-technology, cgm, aid, glycemic-monitoring, teaching]
sources:
  - ../guidelines/ada-standards-of-care-2026.md
  - ../guidelines/kdigo-diabetes-management-in-ckd-2026.md
evidence_level: guideline
clinical_use: teaching
confidence: medium
last_verified: 2026-05-19
status: active
obsidian_type: concept
aliases:
  - CGM and AID
  - continuous glucose monitoring
  - automated insulin delivery
  - diabetes technology
  - time in range
  - TIR
  - GMI
  - BGM
  - SMBG
  - 連續血糖監測
  - 連續血糖
  - 自動胰島素輸注
  - 糖尿病新科技
  - 血糖機
entities:
  - CGM
  - rtCGM
  - isCGM
  - AID
  - automated insulin delivery
  - insulin pump
  - BGM
  - SMBG
  - TIR
  - time in range
  - time below range
  - time above range
  - GMI
  - hypoglycemia
  - ADA Section 7
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware concept page for Diabetes Technology CGM and AID; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 2 listed source(s) before changing recommendations."
related: 
  - "guidelines/ada-standards-of-care-2026"
  - "guidelines/kdigo-diabetes-management-in-ckd-2026"
  - "claims/ada-2026-cgm-diabetes-technology-claims"
  - "evidence-ledger/cgm-diabetes-technology-ledger"
  - "concepts/organ-centric-diabetes-care"
  - queries/hospital-steroid-hyperglycemia-line-questions
---

# Diabetes Technology CGM and AID

## Summary

This page tracks continuous glucose monitoring and automated insulin delivery as practical tools for diabetes care, teaching, and patient education.

ADA 2026 includes a dedicated diabetes technology section. KDIGO 2026 draft focus areas include glycemic monitoring in diabetes and CKD. Exact recommendations should be extracted into recommendation cards before clinical use.

## Wiki Links

- [[../guidelines/ada-standards-of-care-2026]]
- [[../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[organ-centric-diabetes-care]]
- [[../claims/ada-2026-cgm-diabetes-technology-claims]]
- [[../evidence-ledger/cgm-diabetes-technology-ledger]]

## Pending Source Extraction

- CGM indications by diabetes type and treatment pattern.
- Time-in-range, time-below-range, and hypoglycemia metrics.
- AID use cases and safety considerations.
- CKD-specific glycemic monitoring caveats.
