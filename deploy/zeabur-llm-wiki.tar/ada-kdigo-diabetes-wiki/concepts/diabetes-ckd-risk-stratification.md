---
title: Diabetes CKD Risk Stratification
type: concept
created: 2026-05-19
updated: 2026-05-20
tags: [concept, diabetes, ckd, kidney, risk-stratification, albuminuria, egfr]
sources:
  - ../guidelines/ada-standards-of-care-2026.md
  - ../guidelines/kdigo-diabetes-management-in-ckd-2026.md
evidence_level: guideline
clinical_use: clinical-reference
confidence: medium
last_verified: 2026-05-19
status: active
obsidian_type: concept
aliases:
  - CKD risk stratification in diabetes
  - diabetic kidney disease risk
  - DKD risk stratification
  - diabetes kidney risk
  - eGFR and albuminuria risk
  - UACR risk category
  - 糖尿病腎病變風險分層
  - 腎功能與尿蛋白風險
  - A1C reliability in CKD
  - CKD hypoglycemia risk
  - finerenone albuminuria
  - metformin eGFR limit
entities:
  - CKD
  - diabetic kidney disease
  - DKD
  - eGFR
  - UACR
  - albuminuria
  - proteinuria
  - kidney failure
  - dialysis
  - A1C reliability
  - glycemic monitoring
  - hypoglycemia
  - metformin
  - finerenone
  - nonsteroidal MRA
  - T2D
  - T1D
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware concept page for Diabetes CKD Risk Stratification; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 2 listed source(s) before changing recommendations."
related: 
  - "guidelines/ada-standards-of-care-2026"
  - "guidelines/kdigo-diabetes-management-in-ckd-2026"
  - "comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd"
  - evidence-ledger/ckd-cardiorenal-ledger
---

# Diabetes CKD Risk Stratification

## Summary

Diabetes CKD risk stratification should connect kidney function, albuminuria, cardiovascular risk, glycemic monitoring, medication selection, and follow-up intensity.

This page is a placeholder for a future full risk-stratification card after importing KDIGO 2022, KDIGO 2026 final guidance, ADA 2026 Section 11, and the ADA-KDIGO consensus report.

## Wiki Links

- [[../guidelines/ada-standards-of-care-2026]]
- [[../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[organ-centric-diabetes-care]]
- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]

## Pending Source Extraction

- eGFR and albuminuria categories.
- Screening frequency.
- Medication selection by kidney function and albuminuria.
- Referral thresholds.
- Monitoring requirements after treatment changes.
