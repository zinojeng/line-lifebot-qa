---
title: Diabetes Bone Health and Osteoporosis
type: concept
created: 2026-05-20
updated: 2026-05-20
tags: [concept, diabetes, osteoporosis, bone-health, fracture-risk, ada-2026]
sources:
  - ../guidelines/ada-standards-of-care-2026.md
  - ../../../../openclaw-research/ada20252026/2026md/dc26s004.md
  - ../../../../openclaw-research/ada20252026/reports/agent1_foundation_prevention.md
  - ../../../../openclaw-research/ada20252026/reports/ada2025vs2026_comparison_report.md
evidence_level: guideline
clinical_use: clinical-reference
confidence: high
last_verified: 2026-05-20
status: active
obsidian_type: concept
aliases:
  - diabetes and osteoporosis
  - diabetes bone health
  - osteoporosis in diabetes
  - fracture risk in diabetes
  - bone mineral density in diabetes
  - DXA in diabetes
  - BMD in diabetes
  - T-score diabetes
  - FRAX diabetes
  - 糖尿病與骨質疏鬆
  - 糖尿病骨鬆
  - 糖尿病骨折風險
  - 糖尿病骨密度
  - 骨質疏鬆治療是否不同
  - 骨質疏鬆和糖尿病
entities:
  - ADA 2026 Section 4
  - osteoporosis
  - fracture risk
  - DXA
  - BMD
  - T-score
  - FRAX
  - calcium
  - vitamin D
  - thiazolidinediones
  - sulfonylureas
  - hypoglycemia
  - bisphosphonates
  - denosumab
  - teriparatide
  - abaloparatide
  - romosozumab
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware concept page for Diabetes Bone Health and Osteoporosis; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 4 listed source(s) before changing recommendations."
related: 
  - "guidelines/ada-standards-of-care-2026"
  - "comparisons/ada-2025-vs-2026-overview"
  - "_meta/topic-map"
  - "claims/ada-2026-bone-health-osteoporosis-claims"
  - "evidence-ledger/bone-health-osteoporosis-ledger"
  - "evidence-ledger/glp1-muscle-sarcopenia-ledger"
  - "concepts/glp1-weight-loss-muscle-sarcopenia"
  - queries/bone-glp1-muscle-line-questions
---

# Diabetes Bone Health and Osteoporosis

## Short Answer For LINE

糖尿病患者的骨質疏鬆治療「大方向與一般人相同」，但評估與用藥選擇要更注意骨折風險。

不同之處主要有三點：

1. 糖尿病本身會增加骨折風險，尤其是第 1 型糖尿病、病程久、已有神經病變/視網膜病變/腎病變、跌倒或低血糖風險高者。
2. 骨密度可能低估糖尿病患者的實際骨折風險；第 2 型糖尿病患者即使 BMD 看起來正常，骨品質仍可能較差，FRAX 也可能低估風險。
3. 選降血糖藥時要一起考慮骨骼安全：骨折風險高者要避免或慎用與骨折/跌倒風險較相關的藥物，例如 TZD、sulfonylurea；也要避免過度嚴格控糖造成低血糖跌倒。

## ADA 2026 Core Points

ADA 2026 Section 4 新增完整的 bone health 建議群，重點包括：

- Older adults with diabetes should have fracture risk assessed as part of routine diabetes care.
- DXA/BMD monitoring is recommended in older adults with diabetes age 65 years or older, and in younger people with diabetes who have multiple risk factors; typical reassessment interval is every 2 to 3 years.
- Glucose-lowering treatment should consider skeletal effects. Avoid medications associated with higher fracture risk, especially TZD and sulfonylureas, in people at elevated fracture risk.
- Glycemic targets should be individualized in people with high fracture risk; prioritize lower-hypoglycemia-risk therapies to reduce falls.
- Calcium intake around 1,000 to 1,200 mg/day and adequate vitamin D should be ensured for people at fracture risk.
- Osteoporosis drug therapy should be considered in older adults with diabetes and increased fracture risk, including T-score <= -2.5, fragility fracture history, or elevated FRAX.
- For T-score between -2.0 and -2.5, treatment may be considered when additional fracture risk factors are present.

## What Is Different From The General Population?

The medication classes for osteoporosis are generally the same as in the general population: antiresorptive agents such as bisphosphonates or denosumab, and osteoanabolic agents such as teriparatide, abaloparatide, or romosozumab in selected very-high-risk cases.

The difference is not that diabetes requires an entirely separate osteoporosis drug algorithm. The difference is that diabetes changes risk interpretation and treatment context:

- BMD and FRAX may underestimate fracture risk in type 2 diabetes.
- A T-score between -2.0 and -2.5 may deserve more attention if the person has additional risk factors.
- Fragility fracture should trigger osteoporosis diagnosis and secondary-fracture prevention even if BMD is not severely low.
- Diabetes complications, hypoglycemia, neuropathy, retinopathy, sarcopenia, gait impairment, and falls can make fracture prevention more urgent.
- Diabetes medication choice matters: TZD and sulfonylurea are less attractive in fracture-prone patients; low-hypoglycemia-risk regimens are preferred.

## Practical Answer Template

For a LINE user asking "糖尿病與骨質疏鬆治療是否與一般人不同？":

```text
有一點不同。

骨質疏鬆藥物本身大多和一般人相同，例如雙磷酸鹽、denosumab，或高風險時考慮促骨生成藥物。但糖尿病患者評估骨折風險時要更小心，因為糖尿病會讓骨折風險上升，而且骨密度和 FRAX 有時會低估風險。

ADA 2026 特別把骨骼健康放進糖尿病常規照護：65 歲以上糖尿病患者、或較年輕但有多個風險因子者，應考慮 DXA 骨密度追蹤；若 T-score <= -2.5、曾有脆弱性骨折，或 FRAX 達高風險，就要考慮骨鬆藥物。若 T-score 在 -2.0 到 -2.5，加上跌倒、病程久、低血糖、神經病變等風險，也可考慮治療。

另外，降血糖藥也要一起調整：骨折風險高者應避免或慎用 TZD、sulfonylurea，並避免太嚴格控糖導致低血糖跌倒。
```

## Related Pages

- [[../guidelines/ada-standards-of-care-2026]]
- [[organ-centric-diabetes-care]]
- [[../comparisons/ada-2025-vs-2026-overview]]
- [[../_meta/topic-map]]
