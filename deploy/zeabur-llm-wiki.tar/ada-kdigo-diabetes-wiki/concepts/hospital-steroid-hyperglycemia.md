---
title: Hospital Steroid Hyperglycemia
type: concept
created: 2026-05-22
updated: 2026-05-22
tags: [ada, hospital-care, steroid, glucocorticoid, hyperglycemia, concept]
sources:
  - raw/guidelines/ada-standards-of-care-2026-source-map.md
  - raw/guidelines/local-guideline-file-registry.md
  - /Users/ander/Documents/medical/guidelines/ada/dc26s016.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-22
status: active
obsidian_type: concept
aliases:
  - steroid hyperglycemia
  - glucocorticoid hyperglycemia
  - inpatient steroid hyperglycemia
  - corticosteroid-induced hyperglycemia
  - 住院 steroid 高血糖
  - 類固醇高血糖
entities:
  - ADA 2026
  - hospital care
  - glucocorticoids
  - prednisone
  - prednisolone
  - dexamethasone
  - NPH insulin
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware concept page for Hospital Steroid Hyperglycemia; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 3 listed source(s) before changing recommendations."
related: 
  - "guidelines/ada-standards-of-care-2026"
  - "concepts/diabetes-technology-cgm-aid"
  - "concepts/diabetes-pregnancy-gdm-cgm"
  - "evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades"
  - "_meta/topic-map"
  - queries/hospital-steroid-hyperglycemia-line-questions
---

# Hospital Steroid Hyperglycemia

This page summarizes ADA 2026 Section 16 hospital-care guidance for glucocorticoid-associated hyperglycemia. Use it with [[../guidelines/ada-standards-of-care-2026]] and [[../raw/guidelines/local-guideline-file-registry]] for source verification.

Most content on this page is ADA Section 16 narrative guidance rather than numbered/graded recommendations. It is high-confidence for routing and source-grounded principles, but not for fixed insulin-dose formulas.

## Source-Verified ADA 2026 Points

| Source area | Grade | Source-verified point |
|---|---|---|
| 16.4a | A | In most critically ill hospitalized individuals, insulin should be initiated or intensified for persistent hyperglycemia starting at >=180 mg/dL, confirmed twice within 24 hours. |
| 16.4b | B | In most noncritically ill hospitalized individuals, insulin and/or other glucose-lowering therapies should be initiated or intensified for persistent hyperglycemia starting at >=180 mg/dL, confirmed twice within 24 hours. |
| 16.5a usual-goal clause | A | Once therapy is initiated for most critically ill people with hyperglycemia, the glycemic goal is 140-180 mg/dL. |
| 16.5a selected-stricter-goal clause | B | More stringent individualized goals may be appropriate for selected critically ill people if achievable without significant hypoglycemia. |
| 16.5b | B | For noncritically ill people, a glycemic goal of 100-180 mg/dL is recommended if achievable without significant hypoglycemia. |
| Section 16 glucocorticoid therapy | not a numbered recommendation | Glucocorticoid use in hospitalized people can induce hyperglycemia; the type and duration of glucocorticoid should guide insulin planning. |
| Prednisone/prednisolone pattern | not a numbered recommendation | Morning intermediate-acting glucocorticoids can produce afternoon-to-evening hyperglycemia, while fasting glucose may be normal or only mildly elevated. |
| Insulin matching strategy | not a numbered recommendation | For once- or twice-daily intermediate-acting steroids, NPH insulin given with prednisone/prednisolone is a frequently used approach because NPH action can match the steroid glycemic pattern. |
| Long-acting or repeated steroids | not a numbered recommendation | Long-acting glucocorticoids such as dexamethasone, or multidose/continuous steroid exposure, may require long-acting basal insulin and higher prandial/correction doses when eating. |
| Safety caveat | not a numbered recommendation | Daily insulin adjustments should account for glycemia, steroid type/dose/duration changes, nutrition status, and point-of-care glucose monitoring to reduce both hypoglycemia and hyperglycemia. |

## Cautions for LINE Answers

- Do not present steroid hyperglycemia management as a fixed insulin formula; ADA describes matching insulin strategy to steroid pharmacology, nutrition, and daily glucose patterns.
- Mention hypoglycemia risk when steroid doses are suddenly reduced, oral intake falls, feeding is interrupted, or insulin timing is mismatched.
- For specific inpatient orders, answer at the principle level and recommend management by the hospital diabetes/inpatient team.

## Related Routes and Smoke Tests

- Related pages: [[../guidelines/ada-standards-of-care-2026]], [[diabetes-ckd-risk-stratification]], [[diabetes-technology-cgm-aid]], [[diabetes-pregnancy-gdm-cgm]], [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]], [[../raw/guidelines/local-guideline-file-registry]].
- Suggested smoke-test terms: `hospital steroid hyperglycemia`, `glucocorticoid hyperglycemia`, `prednisone NPH insulin`, `dexamethasone hyperglycemia`, `住院 steroid 高血糖`, `類固醇高血糖`.

## Verification Notes

- Verified against ADA 2026 Section 16 local Markdown (`dc26s016.md`) listed in [[../raw/guidelines/local-guideline-file-registry]], especially lines 51-56, 80, 201, and 245-259.
- This page summarizes hospital glycemic-management routing and does not replace institutional insulin protocols.
