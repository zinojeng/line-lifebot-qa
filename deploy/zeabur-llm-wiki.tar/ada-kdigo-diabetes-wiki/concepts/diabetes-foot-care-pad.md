---
title: Diabetes Foot Care and PAD Risk
type: concept
created: 2026-05-21
updated: 2026-05-21
tags: [ada, foot-care, pad, complications, screening, concept]
sources:
  - raw/guidelines/ada-standards-of-care-2026-source-map.md
  - raw/guidelines/local-guideline-file-registry.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching]
confidence: high
last_verified: 2026-05-21
status: active
obsidian_type: concept
aliases:
  - diabetic foot care
  - diabetes foot exam
  - PAD screening in diabetes
  - peripheral artery disease foot risk
  - 糖尿病足
  - 糖尿病周邊動脈疾病
entities:
  - ADA 2026
  - diabetic foot ulcer
  - PAD
  - LOPS
  - foot care specialist
  - podiatrist
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware concept page for Diabetes Foot Care and PAD Risk; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 2 listed source(s) before changing recommendations."
related: 
  - "claims/ada-2026-retinopathy-foot-pad-claims"
  - "guidelines/ada-standards-of-care-2026"
  - "evidence-ledger/retinopathy-foot-pad-ledger"
  - queries/section12-evidence-grade-followups
---

# Diabetes Foot Care and PAD Risk

This page summarizes ADA 2026 Section 12 foot-care and peripheral artery disease (PAD) risk guidance. Use it with [[../claims/ada-2026-retinopathy-foot-pad-claims]] for claim routing and [[../guidelines/ada-standards-of-care-2026]] for broader ADA 2026 context.

## Source-Verified ADA 2026 Recommendations

| ADA 2026 recommendation | Grade | Source-verified statement |
|---|---|---|
| 12.23 | A | Perform a comprehensive foot evaluation at least annually to identify risk factors for ulcers and amputations. |
| 12.24 | B | The exam should include skin inspection, foot deformity assessment, neurologic assessment using 10-g monofilament or Ipswich touch test plus at least one additional assessment, and vascular assessment including leg and foot pulses. |
| 12.25 | A | Individuals with sensory loss or prior ulceration or amputation should have feet inspected at every visit. |
| 12.26 | B | Obtain history of ulceration, amputation, Charcot foot, angioplasty or vascular surgery, cigarette smoking, retinopathy, renal disease, and current neuropathy or vascular symptoms. |
| 12.27 | B | Initial PAD screening should assess lower-extremity pulses, capillary refill time, rubor on dependency, pallor on elevation, and venous filling time; leg fatigue, claudication, rest pain relieved with dependency, or decreased/absent pedal pulses should prompt ankle-brachial index with toe pressures and further vascular assessment as appropriate. |
| 12.28 | B | An interprofessional approach facilitated by a podiatrist with appropriate team members is recommended for foot ulcers and high-risk feet, including dialysis, Charcot foot, prior ulcers/amputation, and PAD. |
| 12.29 referral statement | B | Individuals who smoke and have prior lower-extremity complications, LOPS, structural abnormalities, or PAD should be referred to foot care specialists for ongoing preventive care and lifelong surveillance. |
| 12.29 smoking-cessation statement | A | These individuals should also receive information on the importance of smoking cessation and be referred for smoking-cessation counseling. |

## PAD and Foot-Risk Stratification Notes

ADA 2026 lists PAD, LOPS, deformity, prior ulcer/amputation, smoking, retinopathy, nephropathy, dialysis/posttransplant status, and access-to-care factors among at-risk foot factors. The IWGDF risk categories in ADA Table 12.1 route no LOPS/no PAD to annual exams; LOPS or PAD to every 6–12 months; LOPS plus PAD or deformity/PAD combinations to every 3–6 months; and LOPS or PAD plus prior ulcer, amputation, or kidney failure to every 1–3 months. The table states these frequency suggestions are based on expert opinion and person-centered requirements.

For PAD evaluation, ADA 2026 notes that ankle-brachial indices can be inaccurate in diabetes because of noncompressible vessels; toe systolic blood pressure tends to be more accurate, and toe systolic blood pressure <30 mmHg is suggestive of PAD and impaired ulcer healing.

## Related Routes and Smoke Tests

- Related pages: [[../claims/ada-2026-retinopathy-foot-pad-claims]], [[diabetes-retinopathy-screening]], [[../evidence-ledger/retinopathy-foot-pad-ledger]], [[../raw/guidelines/ada-standards-of-care-2026-source-map]].
- Suggested smoke-test terms: `diabetes foot exam`, `PAD screening diabetes`, `peripheral artery disease foot risk`, `糖尿病足`, `糖尿病足部檢查`, `ADA 2026 12.23`, `ADA 2026 12.27`, `LOPS PAD`.

## Verification Notes

- Verified against ADA 2026 Section 12 local Markdown (`dc26s012.md`) listed in [[../raw/guidelines/local-guideline-file-registry]], lines 254–270, 288–312, 317–366, and 379–417.
- This page summarizes screening/risk routing and does not replace vascular, podiatry, wound-care, or infection-management guidance for active limb-threatening problems.
