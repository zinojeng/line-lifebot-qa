---
title: GLP-1 Weight Loss Muscle Loss And Sarcopenia
type: concept
created: 2026-05-20
updated: 2026-05-20
tags: [glp1, obesity, weight-loss, sarcopenia, muscle, smi, handgrip, patient-education, line-qa]
sources:
  - https://www.sciencedirect.com/science/article/abs/pii/S1525861019308722
  - https://academic.oup.com/ageing/article/48/1/16/5126243
  - https://www.accessdata.fda.gov/drugsatfda_docs/nda/2021/215256Orig1s000MedR.pdf
  - /Users/ander/Documents/medical/guidelines/ada/dc26s008.md
  - /Users/ander/Documents/medical/guidelines/ada/dc26s009.md
  - /Users/ander/Documents/medical/guidelines/ada/dc26s013.md
evidence_level: guideline
clinical_use: [clinical-reference, patient-education, teaching, line-qa]
confidence: high
last_verified: 2026-05-20
status: active
obsidian_type: concept
aliases:
  - GLP-1 muscle loss
  - GLP1 muscle loss
  - GLP-1 sarcopenia
  - semaglutide lean mass
  - tirzepatide lean mass
  - SMI low after GLP-1
  - handgrip weakness after GLP-1
  - leg weakness after GLP-1
  - 肌少症
  - 肌肉質量指數
  - SMI 降低
  - 握力下降
  - 腿沒力
  - GLP1 減重 肌肉
  - GLP-1 減重 肌少症
entities:
  - GLP-1 receptor agonist
  - GLP-1-based therapy
  - semaglutide
  - tirzepatide
  - sarcopenia
  - skeletal muscle mass index
  - handgrip strength
  - chair stand test
  - gait speed
  - SARC-F
  - AWGS 2019
  - EWGSOP2
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware concept page for GLP-1 Weight Loss Muscle Loss And Sarcopenia; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 6 listed source(s) before changing recommendations."
related: 
  - "drugs/glp1-based-therapy-on-dialysis"
  - "guidelines/ada-standards-of-care-2026"
  - "claims/glp1-weight-loss-muscle-sarcopenia-claims"
  - "evidence-ledger/glp1-muscle-sarcopenia-ledger"
  - "concepts/diabetes-bone-health-osteoporosis"
  - queries/bone-glp1-muscle-line-questions
---

# GLP-1 Weight Loss Muscle Loss And Sarcopenia

Use this page when LINE users ask about GLP-1/GLP-1RA/GLP1 weight loss,
decreased SMI, lean mass loss, weaker handgrip, weak legs, frailty, or
sarcopenia. This page is for education and triage, not diagnosis.

## Core Clinical Answer

SMI lowering after GLP-1-related weight loss does not by itself diagnose
sarcopenia. Sarcopenia is suspected when muscle strength or physical performance
declines, and is confirmed when low muscle quantity/quality is also documented.

For a user who reports lower SMI plus weaker handgrip and weaker legs, the safer
answer is:

- This could represent muscle loss, deconditioning, inadequate nutrition during
  weight loss, medication-related reduced intake, neuropathy, anemia, thyroid
  disease, vitamin D deficiency, or true sarcopenia.
- Because both muscle mass and function symptoms are present, the user should
  ask the clinician to assess sarcopenia rather than judging from SMI alone.
- Do not stop GLP-1 therapy abruptly without discussing with the prescribing
  clinician; the plan may need nutrition, resistance exercise, dose adjustment,
  slower weight-loss pace, or evaluation for other causes.

## Diagnostic Frame

AWGS 2019 is often more relevant for Asian populations. It defines sarcopenia as
age-related loss of skeletal muscle mass plus low muscle strength and/or low
physical performance. Useful AWGS 2019 reference cutoffs:

- Low handgrip strength: less than 28 kg in men, less than 18 kg in women.
- Low physical performance: 6-meter walk speed less than 1.0 m/s, SPPB score 9
  or lower, or 5-time chair stand test 12 seconds or longer.
- Low height-adjusted muscle mass: by DXA, less than 7.0 kg/m2 in men and less
  than 5.4 kg/m2 in women; by BIA, less than 7.0 kg/m2 in men and less than
  5.7 kg/m2 in women.
- AWGS also uses calf circumference, SARC-F, or SARC-CalF for case-finding.

EWGSOP2 puts low muscle strength first:

- Probable sarcopenia: low muscle strength.
- Confirmed sarcopenia: low muscle strength plus low muscle quantity or quality.
- Severe sarcopenia: confirmed sarcopenia plus low physical performance.

This means a LINE answer should not say "you have sarcopenia" from SMI alone.
It should say "you have symptoms that justify sarcopenia assessment."

## GLP-1 And Lean Mass

Large GLP-1-based weight-loss trials and regulatory reviews show that weight
loss can reduce both fat mass and lean body mass. In the semaglutide 2.4 mg STEP
1 DXA substudy summarized in FDA review material, fat mass decreased more than
lean mass, while absolute lean body mass also decreased. Therefore:

- Lean mass loss can occur during effective weight loss.
- Lean mass loss is not automatically pathologic sarcopenia if strength and
  function are preserved.
- If lean mass loss is accompanied by weaker handgrip, poor chair rise, slow
  gait, falls, or inability to exercise, it becomes clinically important.

## What To Ask The Clinician To Check

For a patient-facing answer, suggest concrete evaluation rather than a diagnosis:

- Confirm how SMI was measured: BIA, DXA, CT, or another method; compare with the
  same method over time if possible.
- Measure handgrip strength with a dynamometer.
- Check lower-limb function: 5-time chair stand, gait speed, timed up-and-go, or
  SPPB.
- Screen symptoms with SARC-F or SARC-CalF.
- Review weight-loss speed, appetite, nausea/vomiting, total calorie intake, and
  protein intake.
- Review resistance training and daily activity.
- Consider other contributors: hypoglycemia, diabetic neuropathy, anemia,
  vitamin D deficiency, thyroid disease, kidney disease, inflammatory disease,
  neurologic disease, depression, pain, and medications.

## Practical Risk-Reduction Advice

Keep wording conservative and individualized:

- Discuss with the prescribing clinician if weakness appeared after GLP-1 dose
  escalation, rapid weight loss, or poor oral intake.
- Ask whether the weight-loss target and pace should be adjusted.
- Ask for dietitian guidance, especially adequate protein and energy intake
  during weight loss.
- Add progressive resistance training if medically safe, ideally supervised at
  first when weakness is present.
- Track function, not only weight: grip strength, chair-rise time, walking
  speed, falls, and ability to climb stairs or stand from a chair.

## Red Flags

Advise urgent medical evaluation if weakness is sudden or asymmetric, associated
with chest pain, shortness of breath, fainting, severe dehydration, persistent
vomiting, confusion, repeated falls, severe hypoglycemia, new neurologic signs,
or inability to stand/walk safely.

## LINE Answer Pattern

Use this pattern for Traditional Chinese LINE replies:

```text
SMI 降低不等於一定是肌少症，但你同時提到握力下降、腿沒力，這已經值得做肌少症評估。

肌少症通常不是只看肌肉量，而是看三件事：
1. 肌力：例如握力、坐站測試
2. 肌肉量：例如 DXA 或 BIA 算出的 SMI
3. 身體功能：例如走路速度、5 次坐站、跌倒風險

GLP-1 減重時，脂肪會下降，但也可能伴隨一部分瘦體重下降。重點是：如果只是 SMI 下降但功能維持，未必是肌少症；如果合併握力下降、下肢無力、走路變慢或容易跌倒，就應該請醫師評估。

建議回診時請醫療團隊確認：
- SMI 是用 BIA 還是 DXA 測量
- 握力是否低於標準
- 5 次坐站、走路速度或 SARC-F
- 蛋白質攝取、熱量攝取、阻力訓練是否足夠
- 是否有貧血、甲狀腺、維生素 D、腎功能、神經病變或低血糖等其他原因

不要自行停 GLP-1；可以和醫師討論是否需要調整減重速度、劑量、營養與阻力訓練計畫。
```

## Related Pages

- [[organ-centric-diabetes-care]]
- [[diabetes-bone-health-osteoporosis]]
- [[../drugs/glp1-based-therapy-on-dialysis]]
- [[../guidelines/ada-standards-of-care-2026]]
