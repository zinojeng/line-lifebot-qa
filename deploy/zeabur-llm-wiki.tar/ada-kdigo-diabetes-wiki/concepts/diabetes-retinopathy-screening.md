---
title: Diabetes Retinopathy Screening and Follow-Up
type: concept
created: 2026-05-21
updated: 2026-05-21
tags: [ada, retinopathy, complications, screening, concept]
sources:
  - raw/guidelines/ada-standards-of-care-2026-source-map.md
  - raw/guidelines/local-guideline-file-registry.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching]
confidence: high
last_verified: 2026-05-21
status: active
obsidian_type: concept
aliases:
  - diabetic retinopathy screening
  - retinopathy screening follow-up
  - diabetes eye exam interval
  - 視網膜病變篩檢
  - 糖尿病眼底檢查
entities:
  - ADA 2026
  - diabetic retinopathy
  - ophthalmologist
  - optometrist
  - retinal photography
  - FDA-approved AI screening
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware concept page for Diabetes Retinopathy Screening and Follow-Up; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 2 listed source(s) before changing recommendations."
related: 
  - "claims/ada-2026-retinopathy-foot-pad-claims"
  - "guidelines/ada-standards-of-care-2026"
  - "evidence-ledger/retinopathy-foot-pad-ledger"
  - queries/section12-evidence-grade-followups
---

# Diabetes Retinopathy Screening and Follow-Up

This page summarizes ADA 2026 Section 12 retinopathy screening and follow-up recommendations. Use it with [[../claims/ada-2026-retinopathy-foot-pad-claims]] for claim routing and [[../guidelines/ada-standards-of-care-2026]] for broader ADA 2026 context.

## Source-Verified ADA 2026 Recommendations

| ADA 2026 recommendation | Grade | Source-verified statement |
|---|---|---|
| 12.3 | B | Adults with type 1 diabetes should have an initial dilated and comprehensive eye examination by an ophthalmologist or optometrist 5 years after diabetes onset. |
| 12.4 | B | People with type 2 diabetes should have an initial dilated and comprehensive eye examination by an ophthalmologist or optometrist at diagnosis. |
| 12.5 | B | If there is no retinopathy from one or more annual eye exams and glycemic indicators are within goal range, screening every 1–2 years may be considered. If any diabetic retinopathy is present, subsequent dilated retinal exams should be at least annual; progressing or sight-threatening retinopathy requires more frequent ophthalmologist exams. |
| 12.6 | B | Retinal photography with remote reading or FDA-approved artificial intelligence algorithms are appropriate screening strategies when they include pathways for timely referral for comprehensive eye examination when indicated. |
| 12.7 | B | Individuals of childbearing potential with preexisting type 1 or type 2 diabetes who are planning pregnancy or pregnant should be counseled about retinopathy development/progression risk. |
| 12.8 | B | Individuals with preexisting type 1 or type 2 diabetes should receive an eye exam before pregnancy and in the first trimester, and may need monitoring every trimester and for 1 year postpartum depending on retinopathy degree. |

## Follow-Up Logic

- Normal prior annual exam(s) plus glycemic indicators in goal range can support considering a 1–2 year interval, but the interval should be individualized by risk factors and eye-care professional judgment.
- Any diabetic retinopathy generally routes to at least annual dilated retinal examination; progression, advanced disease, or diabetic macular edema routes to more frequent ophthalmology follow-up.
- Retinal photography or AI screening improves access but is not a substitute for indicated dilated comprehensive eye exams; unacceptable image quality or detected abnormalities require in-person follow-up.

## Related Routes and Smoke Tests

- Related pages: [[../claims/ada-2026-retinopathy-foot-pad-claims]], [[diabetes-foot-care-pad]], [[../evidence-ledger/retinopathy-foot-pad-ledger]], [[../raw/guidelines/ada-standards-of-care-2026-source-map]].
- Suggested smoke-test terms: `retinopathy screening`, `diabetes eye exam interval`, `視網膜病變篩檢`, `糖尿病眼底檢查`, `ADA 2026 12.3`, `ADA 2026 12.5`, `AI retinal screening`.

## Verification Notes

- Verified against ADA 2026 Section 12 local Markdown (`dc26s012.md`) listed in [[../raw/guidelines/local-guideline-file-registry]], lines 44–67.
- This page does not summarize retinopathy treatment recommendations beyond screening/follow-up.
