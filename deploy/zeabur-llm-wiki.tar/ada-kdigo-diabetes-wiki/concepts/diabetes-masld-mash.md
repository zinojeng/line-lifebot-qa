---
title: Diabetes MASLD and MASH
type: concept
created: 2026-05-23
updated: 2026-05-23
tags: [ada, diabetes, masld, mash, liver, glp1, pioglitazone, line-qa]
sources:
  - raw/guidelines/local-guideline-file-registry.md
  - raw/guidelines/ada-standards-of-care-2026-source-map.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: concept
aliases:
  - diabetes MASLD
  - diabetes MASH
  - MASLD in diabetes
  - MASH in diabetes
  - metabolic dysfunction-associated steatotic liver disease diabetes
  - metabolic dysfunction-associated steatohepatitis diabetes
  - fatty liver diabetes
  - NAFLD diabetes
  - NASH diabetes
  - 糖尿病脂肪肝
  - 糖尿病 MASLD
  - 糖尿病 MASH
  - 糖尿病脂肪性肝炎
  - 糖尿病肝纖維化
entities:
  - ADA 2026 Section 4
  - MASLD
  - MASH
  - FIB-4
  - liver stiffness measurement
  - ELF test
  - GLP-1 receptor agonist
  - dual GIP and GLP-1 receptor agonist
  - pioglitazone
  - semaglutide
  - resmetirom
  - SGLT2 inhibitor
owner_agent: hermes
write_policy: hermes-maintained
summary: "ADA 2026 source-verified routing page for diabetes with MASLD/MASH: screening, fibrosis risk stratification, lifestyle, GLP-1/pioglitazone glycemic choices, resmetirom referral, statin/cardiovascular risk, and cirrhosis cautions."
related:
  - guidelines/ada-standards-of-care-2026
  - concepts/organ-centric-diabetes-care
  - claims/ada-2026-masld-mash-claims
  - evidence-ledger/masld-mash-ledger
  - raw/guidelines/local-guideline-file-registry
  - queries/masld-mash-line-questions
---

# Diabetes MASLD and MASH

Use this page when LINE or wiki users ask about diabetes with MASLD/MASH, fatty liver, steatotic liver disease, liver fibrosis screening, GLP-1 RA, dual GIP/GLP-1 RA, pioglitazone, semaglutide, or resmetirom in the liver-disease context.

Related pages: [[../guidelines/ada-standards-of-care-2026]], [[organ-centric-diabetes-care]], [[../claims/ada-2026-masld-mash-claims]], [[../evidence-ledger/masld-mash-ledger]], [[../raw/guidelines/local-guideline-file-registry]].

## Source-Verified Core

ADA 2026 Section 4 states that MASLD has replaced NAFLD terminology and identifies steatotic liver disease in the presence of at least one cardiometabolic risk factor associated with insulin resistance, such as prediabetes, diabetes, atherogenic dyslipidemia, or hypertension, while excluding significant alcohol intake or other secondary causes of steatosis. The same source defines MASH histologically as at least 5% hepatic steatosis with inflammation and hepatocyte injury, with or without fibrosis, and notes diabetes as a major risk factor for MASH and worse liver outcomes. ^[raw/guidelines/local-guideline-file-registry.md#dc26s004.md]

ADA 2026 recommends screening adults with type 2 diabetes or prediabetes—especially with obesity, other cardiometabolic risk factors, or established cardiovascular disease—for risk of cirrhosis related to MASH using FIB-4, even when liver enzymes are normal. FIB-4 at least 1.3 triggers additional risk stratification with liver stiffness measurement by transient elastography, or ELF if unavailable; higher-risk patients should be referred to gastroenterology/hepatology. ^[raw/guidelines/local-guideline-file-registry.md#dc26s004.md]

For management, ADA 2026 recommends lifestyle changes for adults with type 2 diabetes or prediabetes with MASLD, ideally in a structured nutrition and physical activity program. In adults with type 2 diabetes, MASLD, and overweight/obesity, GLP-1 RA with demonstrated MASH benefit and dual GIP/GLP-1 RA are considered adjunctive obesity therapies. For glycemic management in biopsy-proven MASH or high fibrosis risk by noninvasive tests, GLP-1 RA is preferred; pioglitazone or dual GIP/GLP-1 RA can be considered. Combination pioglitazone plus GLP-1 RA can be considered for hyperglycemia in the same high-risk MASH population. ^[raw/guidelines/local-guideline-file-registry.md#dc26s004.md]

ADA 2026 distinguishes glycemic/obesity therapy from liver-specific pharmacotherapy: semaglutide is described as FDA-approved for MASH with moderate to advanced liver fibrosis; resmetirom treatment consideration should route through a gastroenterologist or hepatologist for MASLD with F2-F3 fibrosis by histology or validated imaging/blood-based test. Metabolic surgery can be considered for MASH in appropriate adults with type 2 diabetes and obesity and for cardiovascular outcomes, while cirrhosis is a special safety context: insulin is the preferred glucose-lowering agent in decompensated cirrhosis, metabolic surgery should be used with caution in compensated cirrhosis, and metabolic surgery is not recommended in decompensated cirrhosis. ^[raw/guidelines/local-guideline-file-registry.md#dc26s004.md]

## Retrieval Notes

- First-line compiled claim registry: [[../claims/ada-2026-masld-mash-claims]].
- Raw verification anchor: ADA 2026 Section 4 (`dc26s004.md`) via [[../raw/guidelines/local-guideline-file-registry]].
- For medication-safety overlap, also consider [[diabetes-bone-health-osteoporosis]] for TZD fracture-risk cautions and [[organ-centric-diabetes-care]] for teaching context.

## Common LINE Answer Shape

1. Identify whether the question is about screening/risk stratification, glycemic drug choice, obesity pharmacotherapy, liver-specific MASH therapy, or cirrhosis safety.
2. Use the claim registry for recommendation number and grade.
3. Keep drug statements indication-specific: GLP-1 RA/pioglitazone choices in ADA 2026 are tied to type 2 diabetes with biopsy-proven MASH or high fibrosis risk; resmetirom and liver-specialist treatment decisions are hepatology-routed.
4. Avoid patient-specific medication changes; recommend clinician or gastroenterology/hepatology discussion when fibrosis risk, cirrhosis, or liver-specific therapy is involved.
