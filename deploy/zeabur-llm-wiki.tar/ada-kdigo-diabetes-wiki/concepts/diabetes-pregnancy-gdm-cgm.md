---
title: Diabetes Pregnancy GDM and CGM
type: concept
created: 2026-05-22
updated: 2026-05-22
tags: [ada, pregnancy, gestational-diabetes, gdm, cgm, aid, concept]
sources:
  - raw/guidelines/ada-standards-of-care-2026-source-map.md
  - raw/guidelines/local-guideline-file-registry.md
  - /Users/ander/Documents/medical/guidelines/ada/dc26s015.md
  - /Users/ander/Documents/medical/guidelines/ada/dc26s007.md
evidence_level: guideline
clinical_use: [clinical-reference, teaching, line-qa]
confidence: high
last_verified: 2026-05-22
status: active
obsidian_type: concept
aliases:
  - pregnancy diabetes CGM
  - gestational diabetes CGM
  - GDM CGM
  - diabetes in pregnancy glucose targets
  - 妊娠糖尿病 CGM
  - 孕期糖尿病
  - 懷孕 連續血糖
entities:
  - ADA 2026
  - pregnancy
  - gestational diabetes
  - GDM
  - CGM
  - AID
  - insulin
  - metformin
  - glyburide
  - oral glucose-lowering medication
  - type 1 diabetes
  - type 2 diabetes
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware concept page for Diabetes Pregnancy GDM and CGM; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 4 listed source(s) before changing recommendations."
related: 
  - "guidelines/ada-standards-of-care-2026"
  - "claims/ada-2026-gdm-pharmacotherapy-claims"
  - "evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades"
  - queries/gdm-pharmacotherapy-line-questions
---

# Diabetes Pregnancy GDM and CGM

This page summarizes ADA 2026 Section 15 pregnancy glucose monitoring and CGM guidance. Use it with [[diabetes-technology-cgm-aid]], [[../guidelines/ada-standards-of-care-2026]], and [[../raw/guidelines/local-guideline-file-registry]].
For LINE questions about `Metformin in GDM evidence`, use [[../claims/ada-2026-gdm-pharmacotherapy-claims]]
and [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]] before giving a broad pregnancy answer.

## Source-Verified ADA 2026 Recommendations

Rows labeled as recommendation sub-clauses preserve the source's clause-level grade letters where ADA places different grade marks within the same numbered recommendation.

| ADA 2026 recommendation | Grade | Source-verified statement |
|---|---|---|
| 15.8 | B | In diabetes in pregnancy, fasting, preprandial, and postprandial blood glucose monitoring are recommended. Goals are fasting plasma glucose <95 mg/dL, and either 1-hour postprandial <140 mg/dL or 2-hour postprandial <120 mg/dL. |
| 15.9 | B | A1C is slightly lower during pregnancy; an A1C goal <6% is ideal if achievable without significant hypoglycemia, but may be relaxed to <7% to prevent hypoglycemia. |
| 15.10 glycemic-metric clause | A | In type 1 diabetes and pregnancy, CGM can help achieve glycemic goals such as time in range and time above range. |
| 15.10 A1C-goal clause | B | In type 1 diabetes and pregnancy, CGM can help achieve the A1C goal. |
| 15.10 other-diabetes-types clause | E | CGM may be beneficial for other types of diabetes in pregnancy. |
| 15.11 CGM recommendation clause | A | CGM is recommended for pregnant individuals with type 1 diabetes. |
| 15.11 neonatal-outcome clause | A | In pregnancy complicated by type 1 diabetes, CGM used in conjunction with aims to achieve traditional pre- and postprandial glycemic goals can reduce large-for-gestational-age infants and neonatal hypoglycemia. |
| 15.12 | E | CGM metrics may be used together with blood glucose monitoring to achieve pre- and postprandial glycemic goals. |
| 15.13 | C | Estimated A1C and glucose management indicator calculations should not be used in pregnancy as estimates of A1C. |
| 15.15 | A | Lifestyle behavior change is essential in GDM and may suffice for many; insulin should be added if needed to reach glycemic goals. |
| 15.16 | A | Telehealth plus in-person visits for pregnant people with GDM can improve outcomes compared with in-person care alone. |
| 15.17 type 1 diabetes clause | A | Insulin should be used to manage type 1 diabetes in pregnancy. |
| 15.17 GDM clause | A | Insulin is the preferred agent for the management of GDM. |
| 15.17 type 2 diabetes clause | B | Insulin is the preferred agent for the management of type 2 diabetes in pregnancy. |
| 15.19 | A | AID systems with pregnancy-specific glucose targets are recommended for pregnant individuals with type 1 diabetes. |
| 15.20 | B | AID systems without pregnancy-specific targets or algorithms may be considered for select pregnant individuals with type 1 diabetes under expert-team guidance. |
| 15.21 placenta-crossing clause | A | Metformin and glyburide, individually or in combination, should not be used as first-line agents for management of diabetes in pregnancy because both cross the placenta to the fetus. |
| 15.21 glycemic-sufficiency clause | B | Metformin and glyburide may not be sufficient to achieve glycemic goals in diabetes in pregnancy. |
| 15.21 other-agent clause | E | Other oral and noninsulin injectable glucose-lowering medications lack long-term safety data and are not recommended. |

## CGM Interpretation Notes

ADA 2026 states that data are strongest for CGM in type 1 diabetes and pregnancy. For type 2 diabetes in pregnancy or GDM, data are insufficient to support CGM for all people, and use should be individualized by treatment plan, circumstances, preferences, and needs. In the ADA Section 15 CGM discussion, pregnancy CGM targets include sensor glucose range 63-140 mg/dL with TIR goal >70%, TBR <63 mg/dL <4%, TBR <54 mg/dL <1%, and TAR >140 mg/dL <25%; ADA notes these time-in-range goals are specific for pregnant individuals with type 1 diabetes.

## Cautions for LINE Answers

- Do not say CGM universally improves outcomes for all GDM; ADA describes limited and mixed evidence for type 2 diabetes in pregnancy and GDM.
- Do not use GMI or estimated A1C as pregnancy A1C estimates.
- Keep BGM and postprandial monitoring in the answer even when CGM is discussed.
- For medication choices in pregnancy, avoid noninsulin injectable or oral medication claims beyond the ADA source-verified statements above.
- For `metformin in GDM` questions, do not answer "the wiki has no evidence" when this page or the linked GDM pharmacotherapy claim card is retrieved.
- Phrase metformin/glyburide as "not first-line in ADA 2026 because both cross the placenta and may not be sufficient for glycemic goals"; do not phrase it as an absolute ban.

## Related Routes and Smoke Tests

- Related pages: [[diabetes-technology-cgm-aid]], [[../claims/ada-2026-gdm-pharmacotherapy-claims]], [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]], [[../guidelines/ada-standards-of-care-2026]], [[../raw/guidelines/local-guideline-file-registry]], [[hospital-steroid-hyperglycemia]].
- Suggested smoke-test terms: `pregnancy gestational diabetes CGM`, `GDM CGM`, `diabetes pregnancy glucose targets`, `妊娠糖尿病 CGM`, `懷孕 連續血糖`, `pregnancy GMI`, `Metformin in GDM evidence`, `妊娠糖尿病 metformin`, `GDM pharmacotherapy`.

## Verification Notes

- Verified against ADA 2026 Section 15 local Markdown (`dc26s015.md`) listed in [[../raw/guidelines/local-guideline-file-registry]], especially lines 216-222, 230-287, 318-342, and 346-355.
- Recommendation 15.8 source wording uses strict `<` thresholds for fasting glucose <95 mg/dL, 1-hour postprandial <140 mg/dL, and 2-hour postprandial <120 mg/dL.
- Recommendation 15.11 contains two source-graded A clauses: one recommending CGM for pregnant individuals with type 1 diabetes, and one tying neonatal/LGA benefit to CGM used together with traditional pre- and postprandial glycemic goals.
- Pregnancy CGM target ranges are from the ADA Section 15 CGM discussion in `dc26s015.md`, lines 337-342.
- ADA 2026 Section 7 also notes that AID systems in pregnancy require careful assessment and expert guidance; Section 15 is the primary pregnancy source.
