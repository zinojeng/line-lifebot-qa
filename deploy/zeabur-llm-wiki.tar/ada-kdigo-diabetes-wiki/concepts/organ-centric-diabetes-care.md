---
title: Organ-Centric Diabetes Care
type: concept
created: 2026-05-19
updated: 2026-05-20
tags: [concept, diabetes, cardiorenal-metabolic, organ-protection, teaching]
sources:
  - ../guidelines/ada-standards-of-care-2026.md
  - ../guidelines/kdigo-diabetes-management-in-ckd-2026.md
evidence_level: guideline
clinical_use: teaching
confidence: medium
last_verified: 2026-05-19
status: active
obsidian_type: concept
aliases:
  - organ-protective diabetes care
  - cardiorenal metabolic care
  - cardiorenal-metabolic diabetes care
  - risk-based diabetes care
  - beyond A1C diabetes care
  - whole-person diabetes care
  - 器官保護糖尿病照護
  - 心腎代謝照護
  - 不只看血糖
entities:
  - A1C
  - CKD
  - ASCVD
  - heart failure
  - obesity
  - MASLD
  - MASH
  - hypoglycemia
  - SGLT2 inhibitor
  - GLP-1 receptor agonist
  - CGM
owner_agent: hermes
write_policy: hermes-maintained
---

# Organ-Centric Diabetes Care

## Working Definition

Organ-centric diabetes care is a teaching frame that treats glucose control as one part of a broader strategy to protect the heart, kidney, liver, body weight, and functional health.

This is a synthesis frame for teaching and workflow design. It should link back to source-specific recommendations before being used as clinical guidance.

## Why It Matters

- ADA 2026 organizes diabetes care across glycemia, technology, obesity, cardiovascular risk, CKD risk, and comorbidities.
- KDIGO's diabetes and CKD work emphasizes diabetes care in the setting of kidney risk, glycemic monitoring, and comprehensive pharmacotherapy.

## Links

- [[../guidelines/ada-standards-of-care-2026]]
- [[../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[diabetes-ckd-risk-stratification]]

## Teaching Use

For medical students, contrast "A1C-only diabetes care" with "risk-based diabetes care": start with glycemia, then ask what the heart, kidney, weight, liver, hypoglycemia risk, and technology needs require.
