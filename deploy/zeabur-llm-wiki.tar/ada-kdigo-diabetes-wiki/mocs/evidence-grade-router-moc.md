---
title: Evidence Grade Router MOC
type: moc
created: 2026-05-22
updated: 2026-05-24
tags: [moc, evidence-grade, recommendation-grade, routing, line-qa, ada, kdigo]
sources:
  - _meta/aliases.md
  - _meta/topic-map.md
  - evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades.md
  - evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades.md
evidence_level: local-practice
clinical_use: [workflow, line-qa]
confidence: high
last_verified: 2026-05-24
status: active
obsidian_type: moc
aliases:
  - evidence grade router
  - recommendation grade router
  - 證據等級 router
  - 建議等級 router
entities:
  - ADA 2026
  - KDIGO 2026
  - recommendation grade
  - LINE QA
owner_agent: hermes
write_policy: hermes-maintained
summary: Context-aware Map of Content for routing short LINE evidence-grade follow-ups to the correct ADA/KDIGO evidence card instead of defaulting to CKD.
related:
  - evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades
  - evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades
  - claims/ada-kdigo-2026-ckd-cardiorenal-claims
  - claims/ada-2026-masld-mash-claims
  - queries/gdm-pharmacotherapy-line-questions
  - queries/masld-mash-line-questions
  - queries/section12-evidence-grade-followups
---

# Evidence Grade Router MOC

Use this MOC when a LINE user asks a short follow-up such as `證據等級是？`, `建議等級是？`, `哪些是 strong recommendation？`, or `哪些證據等級較低？`.

The core rule is context first: do not route a generic evidence-grade follow-up to CKD unless the recent question or current wording is actually about CKD, eGFR, UACR, SGLT2i, GLP-1RA, finerenone, ACEi/ARB, or KDIGO.

## Router 2.0 Rule

Evidence-grade routing is now claim-specific, not claim-generic. Asking for `證據等級` should not boost every claim registry. First classify the current plus recent LINE context, then boost only the matching chapter's evidence card or claim registry:

- Section 12 route: retinopathy, severe eye disease, DME/PDR/NPDR, anti-VEGF, neuropathy medication, foot care, or PAD.
- MASLD/MASH route: MASLD, MASH, fatty liver, FIB-4, liver fibrosis, pioglitazone, GLP-1 RA/tirzepatide in liver context, resmetirom, or cirrhosis.
- CKD/cardiorenal route: CKD, eGFR, UACR, albuminuria, KDIGO, finerenone, ACEi/ARB, or kidney-focused SGLT2i/GLP-1RA.

If a Section 12 or MASLD/MASH evidence-grade question lacks explicit kidney context, CKD/cardiorenal claim pages should be penalized rather than used as the default answer source.

## Routing Table

| Recent or current topic | Read first | Then read | Notes |
|---|---|---|---|
| CKD, eGFR, UACR, albuminuria, SGLT2i, GLP-1RA, finerenone, ACEi/ARB, KDIGO | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] | Keep ADA grades separate from KDIGO GRADE labels. |
| Blood pressure target in diabetes CKD | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] | [[../concepts/diabetes-ckd-risk-stratification]] | Include ADA 10.3/10.4 and ACEi/ARB grade splits when relevant. |
| Lipid, LDL, statin, ASCVD | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] | [[../guidelines/ada-standards-of-care-2026]] | Use Section 10 lipid/ASCVD grades rather than CKD medication grades; keep 10.26 statin-intensity guidance separate from 10.27 LDL goal guidance. |
| GDM, pregnancy diabetes, metformin, glyburide, insulin in pregnancy | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] | [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]] | Answer "not first-line" instead of "absolutely contraindicated" for metformin/glyburide. |
| Retinopathy, severe eye disease, DME, PDR, NPDR, anti-VEGF, laser, vitrectomy | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] | [[../claims/ada-2026-retinopathy-foot-pad-claims]] | Section 12 treatment recommendations 12.9-12.16 are the key rows. |
| Neuropathy, DPN, neuropathic pain, gabapentinoid, SNRI, TCA, sodium channel blocker, opioid | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] | [[../claims/ada-2026-retinopathy-foot-pad-claims]] | Section 12 treatment recommendations 12.20-12.22 are the key rows. |
| Foot care, diabetic foot, PAD screening, LOPS, ABI, toe pressure, podiatry | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] | [[../concepts/diabetes-foot-care-pad]] | Section 12 foot/PAD recommendations 12.23-12.29 are the key rows. |
| CGM, AID, technology | [[../claims/ada-2026-cgm-diabetes-technology-claims]] | [[../concepts/diabetes-technology-cgm-aid]] | Exact Section 7 grade extraction is still pending; state this limitation if asked for exact grade. |
| Bone health, osteoporosis, fracture, DXA, FRAX, T-score | [[../claims/ada-2026-bone-health-osteoporosis-claims]] | [[../concepts/diabetes-bone-health-osteoporosis]] | Exact Section 4 grade extraction is still pending; do not pretend every bone recommendation has a verified grade card. |
| MASLD, MASH, fatty liver, FIB-4, liver fibrosis, GLP-1, pioglitazone, resmetirom, metabolic surgery | [[../claims/ada-2026-masld-mash-claims]] | [[../concepts/diabetes-masld-mash]] | ADA Section 4 MASLD/MASH claim cards split separately graded clauses; use 4.30b/4.32b rows for cirrhosis safety and do not route these follow-ups to CKD solely because the user says 建議等級. |

## LINE Follow-Up Rule

For short evidence-grade follow-ups, combine the new user message with the recent LINE context before searching. For example:

- `嚴重眼病變治療` followed by `證據等級是？` should search retinopathy/DME/PDR treatment grades, not CKD.
- `神經病變有哪些治療選擇` followed by `藥物的證據等級是？` should search neuropathic pain pharmacotherapy grades, not CKD medication grades.
- `58歲 T2DM eGFR 42 UACR 380 CAD...` followed by `哪些證據等級較低？` should search CKD/cardiorenal grades.

## Related Pages

- [[../_meta/aliases]]
- [[../_meta/topic-map]]
- [[../_meta/typed-relationships]]
- [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]]
- [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]]
- [[../claims/ada-2026-masld-mash-claims]]
