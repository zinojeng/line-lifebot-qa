---
title: Diabetes Guidelines MOC
type: teaching
created: 2026-05-19
updated: 2026-05-19
tags: [moc, diabetes, ada, kdigo, guideline, ckd]
sources:
  - ../index.md
  - ../SCHEMA.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-19
status: active
obsidian_type: moc
summary: Main Map of Content for ADA 2026 and KDIGO 2026 diabetes guideline retrieval, source maps, clinical concept hubs, claim registries, and evidence cards.
aliases:
  - diabetes guideline map
  - ADA KDIGO guideline MOC
entities:
  - ADA 2026
  - KDIGO 2026
  - diabetes guidelines
related:
  - guidelines/ada-standards-of-care-2026
  - guidelines/kdigo-diabetes-management-in-ckd-2026
  - mocs/evidence-grade-router-moc
  - mocs/ada-2025-vs-2026-moc
  - evidence-ledger/ckd-cardiorenal-ledger
  - evidence-ledger/cgm-diabetes-technology-ledger
  - evidence-ledger/bone-health-osteoporosis-ledger
  - evidence-ledger/glp1-muscle-sarcopenia-ledger
  - concepts/hospital-steroid-hyperglycemia
  - queries/hospital-steroid-hyperglycemia-line-questions
owner_agent: hermes
write_policy: hermes-maintained
---

# Diabetes Guidelines MOC

## Core Guideline Hubs

- [[../guidelines/ada-standards-of-care-2026]]
- [[../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[../guidelines/ada2026]]
- [[../guidelines/kdigo2026]]

## Source Registries

- [[../raw/guidelines/local-guideline-file-registry]]
- [[../raw/guidelines/ada-standards-of-care-2026-source-map]]
- [[../raw/guidelines/kdigo-diabetes-ckd-2026-source-map]]
- [[../raw/comparisons/ada-2025-vs-2026-comparison-registry]]

## Clinical Concept Hubs

- [[../concepts/organ-centric-diabetes-care]]
- [[../concepts/diabetes-ckd-risk-stratification]]
- [[../concepts/diabetes-technology-cgm-aid]]
- [[../concepts/diabetes-bone-health-osteoporosis]]
- [[../concepts/glp1-weight-loss-muscle-sarcopenia]]
- [[../concepts/hospital-steroid-hyperglycemia]]
- [[../concepts/diabetes-masld-mash]]

## Evidence Ledgers

- [[../evidence-ledger/ckd-cardiorenal-ledger]]
- [[../evidence-ledger/cgm-diabetes-technology-ledger]]
- [[../evidence-ledger/bone-health-osteoporosis-ledger]]
- [[../evidence-ledger/glp1-muscle-sarcopenia-ledger]]
- [[../evidence-ledger/gdm-pharmacotherapy-ledger]]
- [[../evidence-ledger/retinopathy-foot-pad-ledger]]
- [[../evidence-ledger/masld-mash-ledger]]

## ADA/KDIGO CKD Drug Cards

- [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]]
- [[../drugs/glp1-based-therapy-on-dialysis]]

## Comparison Hubs

- [[../mocs/ada-2025-vs-2026-moc]]
- [[../comparisons/ada-2025-vs-2026-overview]]
- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]
- [[../comparisons/ada-2025-vs-2026-methodology-concerns]]
- [[../comparisons/ada-2025-vs-2026-taiwan-impact]]

## Output Hubs

- [[../teaching/ada-kdigo-2026-medical-student-brief]]
- [[../queries/how-to-use-this-wiki-for-ada-kdigo-questions]]
- [[../docs/obsidian-graph-workflow]]
- [[../docs/mcp-obsidian-setup]]
