---
title: Diabetes Guidelines MOC
type: teaching
created: 2026-05-19
updated: 2026-05-19
tags: [moc, diabetes, ada, kdigo, guideline, ckd]
sources:
  - ../index.md
  - ../SCHEMA.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-19
status: active
obsidian_type: moc
---

# Diabetes Guidelines MOC

## Core Guideline Hubs

- [[../guidelines/ada-standards-of-care-2026]]
- [[../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[../guidelines/ada2026]]
- [[../guidelines/kdigo2026]]

## Source Registries

- [[../raw/guidelines/local-guideline-file-registry]]
- [[../raw/guidelines/ada-standards-of-care-2026-source-map]]
- [[../raw/guidelines/kdigo-diabetes-ckd-2026-source-map]]
- [[../raw/comparisons/ada-2025-vs-2026-comparison-registry]]

## Clinical Concept Hubs

- [[../concepts/organ-centric-diabetes-care]]
- [[../concepts/diabetes-ckd-risk-stratification]]
- [[../concepts/diabetes-technology-cgm-aid]]

## ADA/KDIGO CKD Drug Cards

- [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]]
- [[../drugs/glp1-based-therapy-on-dialysis]]

## Comparison Hubs

- [[../comparisons/ada-2025-vs-2026-overview]]
- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]
- [[../comparisons/ada-2025-vs-2026-methodology-concerns]]
- [[../comparisons/ada-2025-vs-2026-taiwan-impact]]

## Output Hubs

- [[../teaching/ada-kdigo-2026-medical-student-brief]]
- [[../queries/how-to-use-this-wiki-for-ada-kdigo-questions]]
- [[../docs/obsidian-graph-workflow]]
- [[../docs/mcp-obsidian-setup]]
