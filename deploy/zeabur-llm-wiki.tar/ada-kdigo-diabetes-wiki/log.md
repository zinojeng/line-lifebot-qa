# ADA-KDIGO Diabetes Wiki Log

## 2026-05-22

- Converted the LINE `Metformin in GDM evidence` answer-improvement into durable wiki routing: expanded [[concepts/diabetes-pregnancy-gdm-cgm]] aliases, added [[evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]], [[claims/ada-2026-gdm-pharmacotherapy-claims]], and [[evidence-ledger/gdm-pharmacotherapy-ledger]], and wired aliases/topic-map/typed relationships/synthetic QA so future GDM pharmacotherapy questions route to ADA 2026 Section 15 instead of broad CKD/CGM pages.
- Processed selected daily self-improvement requests for hospital steroid hyperglycemia and pregnancy/GDM + CGM.
- Verified ADA 2026 Section 16 steroid-hyperglycemia source facts against `dc26s016.md` via [[raw/guidelines/local-guideline-file-registry]].
- Verified ADA 2026 Section 15 pregnancy/CGM source facts against `dc26s015.md` and Section 7 AID pregnancy caveats against `dc26s007.md`.
- Created [[concepts/hospital-steroid-hyperglycemia]] and [[concepts/diabetes-pregnancy-gdm-cgm]].
- Updated [[_meta/aliases]], [[_meta/topic-map]], [[index]], and the two resolved research requests.
- Daily audit also opened two next-queue research requests: [[inbox/research-requests/2026-05-22-self-audit-diabetes-ascvd-lipid-targets]] and [[inbox/research-requests/2026-05-22-self-audit-diabetes-masld-and-mash]].

## 2026-05-21

- Processed selected self-improvement requests for retinopathy screening/follow-up and foot care/PAD risk.
- Verified ADA 2026 Section 12 source facts against `dc26s012.md` via [[raw/guidelines/local-guideline-file-registry]].
- Created [[concepts/diabetes-retinopathy-screening]] and [[concepts/diabetes-foot-care-pad]].
- Updated [[claims/ada-2026-retinopathy-foot-pad-claims]], [[evidence-ledger/retinopathy-foot-pad-ledger]], [[_meta/aliases]], [[_meta/topic-map]], [[index]], and resolved the two corresponding research-request files.

- Confirmed the wiki has a local Git baseline (`941f119`) so the Mac mini Claude CLI review gate can use `git diff` directly.
- Updated [[HERMES]], [[docs/llm-wiki-self-improvement-loop]], and [[docs/hermes-agent-wiki-workflow]] for the generic Claude review wrapper modes: `worktree`, `staged`, `branch <base>`, and `head`.
- Verified the local wrapper help exposes the documented modes; `worktree` reviewed this wiki diff through the Mac mini Claude CLI, and `branch main` runs as an empty branch-level diff while on `main`.
- Added a Claude Code review gate to [[HERMES]] and [[docs/llm-wiki-self-improvement-loop]]: after each implementation step, run Claude review, apply only high-confidence grounded findings, re-run local checks, and report review status before completion.
- Updated the review gate to use the local wrapper `/Users/ander/Documents/Projects/OpenAI/.agents/skills/claude-review/scripts/claude-review.sh`, which reviews the current `git diff` from inside a Git worktree.
- Superseded the older single implicit wrapper command with the explicit mode contract above.

## 2026-05-20

- Added machine-readable wiki registry plan and expanded current implementation targets for `INDEX.json`, page registry, claim registry, evidence ledgers, SQLite FTS5 search, and `wiki_ops.py`.
- Added claim registries for CGM/AID, bone health/osteoporosis, GLP-1 muscle/sarcopenia, and retinopathy/foot/PAD pending extraction.
- Added append-only evidence ledgers for CKD cardiorenal, CGM/AID, bone health, GLP-1 muscle/sarcopenia, and retinopathy/foot/PAD.
- Updated index, topic map, aliases, schema, and self-improvement workflow to expose claim registries, evidence ledgers, machine-readable indexes, and QMD-like FTS search.
- Added claim registry layer: `claims/ada-kdigo-2026-ckd-cardiorenal-claims.md`.
- Added typed relationship map: `_meta/typed-relationships.md`.
- Added synthetic QA registry: `evals/synthetic-qa-registry.md`.
- Updated schema, index, topic map, aliases, retrieval policy, and self-improvement workflow to route recommendation-grade follow-up questions through claims before broad evidence-card pages.
- Added `scripts/hermes_daily_wiki_self_improvement.py` as the daily Hermes queue generator: it runs wiki self-audit, regenerates health report, and injects only 1-2 open research requests for that day's maintenance pass.
- Updated [[docs/llm-wiki-self-improvement-loop]] and [[docs/hermes-only-research-os]] with the daily self-improvement cron pattern and the 1-2 request safety limit.
- Added [[docs/llm-wiki-self-improvement-loop]] and generated [[reports/wiki-self-improvement-audit]] as a proactive lint layer for duplicate candidates, under-routed topics, consistency review, research-request creation, and synthetic QA seeds.
- Added local CLI tools `scripts/wiki_search.py` and `scripts/wiki_self_improvement_audit.py` so Hermes/Codex can search and audit the wiki before LINE users ask failing questions.
- Added [[concepts/glp1-weight-loss-muscle-sarcopenia]] after LINE QA exposed an incomplete answer for GLP-1 weight loss with SMI decline, weaker handgrip, weak legs, and concern for sarcopenia.
- Updated [[index]], [[_meta/topic-map]], and [[_meta/aliases]] so LINE questions about GLP1 減重肌肉、SMI 降低、握力下降、腿沒力、lean mass loss, and 肌少症 route to the new concept page.
- Added [[evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] as the fine-grained ADA/KDIGO evidence-card layer for exact recommendation numbers, grades, thresholds, and lower-certainty buckets in diabetes + CKD cardiorenal medication questions.
- Updated [[SCHEMA]], [[index]], [[_meta/topic-map]], [[_meta/aliases]], and [[comparisons/ada-kdigo-2026-evidence-strength-map]] so Hermes/LINE routes "strong recommendation", "哪些證據等級較低", ADA 11.7a/11.11a, and KDIGO 4.3.1/4.5.1 questions directly to the evidence-card page.
- Added [[comparisons/ada-kdigo-2026-evidence-strength-map]] to route LINE follow-up questions about strong recommendations, evidence grade, and lower-certainty ADA/KDIGO CKD evidence without inventing exact grade labels.
- Updated [[index]], [[_meta/topic-map]], and [[comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] to link the evidence-strength map.
- Updated answer-improvement loop policy to allow Gemini reviewer by default, with OpenAI reviewer as an optional provider.
- Added production note that Zeabur persistent storage should mount `/app/data` so synced wiki files and generated inbox records survive redeploys.
- Added post-answer self-improvement loop support: [[inbox/answer-improvements/README]] for OpenAI mini review records and [[reports/answer-improvement-analysis]] for repeated safe action patterns.
- Updated [[_meta/topic-map]], [[reports/README]], and [[index]] so Hermes can route answer-improvement records into aliases, MOC links, smoke tests, or research requests without directly changing clinical claims.
- Added [[concepts/diabetes-bone-health-osteoporosis]] after LINE QA exposed a false-negative answer for "糖尿病與骨質疏鬆治療是否與一般人不同？".
- Updated [[_meta/aliases]] and [[_meta/topic-map]] with osteoporosis, bone health, fracture risk, DXA, BMD, T-score, FRAX, 骨鬆, 骨密度, and 骨折風險 routes.
- Updated [[index]] so Hermes/LINE retrieval can answer from ADA 2026 Section 4 before falling back to raw/RAG.
- Added retrieval failure learning loop: [[inbox/retrieval-failures/README]], retrieval-failure writeback support in LINE QA, and `scripts/compile_retrieval_failures.py` for grouped reports.
- Updated [[HERMES]] and [[docs/hermes-only-research-os]] with failure-analysis rules: missing aliases/routes, missing facets, retrieval noise, verification gaps, and source gaps become safe improvement tasks.
- Added [[HERMES]] as the project-level Hermes operating instructions for this wiki.
- Added [[_meta/aliases]] as the central alias registry and [[_meta/lint-report]] as the lint/health report entry point.
- Added [[docs/hermes-only-research-os]] describing Hermes roles, custom skills, and the wiki-centered operating loop.
- Installed local Hermes skills: `wiki-query-medical`, `wiki-ingest-medical`, `wiki-lint-medical`, and `wiki-distill-medical`.
- Added daily and monthly Hermes prompts plus `scripts/hermes-ada-kdigo-operating-loop.sh`.
- Created Hermes cron jobs for daily brief (`9b47b879c772`), weekly lint (`253e1f489161`), and monthly refresh (`2cdaf6bd7471`).
- Regenerated [[reports/weekly-wiki-health]] after adding Hermes-only operating files; current report shows 0 broken links and 0 stale clinical pages.
- Added retrieval metadata (`aliases`, `entities`, `owner_agent`, `write_policy`) to core pages for CKD/eGFR, SGLT2i, GLP-1RA/dialysis, CGM/AID, ADA 2026, KDIGO 2026, ADA-KDIGO crosswalk, and medical-student teaching.
- Expanded [[_meta/topic-map]] with common LINE query terms such as SGLT2i, GLP-1RA, eGFR under 20, dialysis, CGM, 連續血糖, 排糖藥, and 糖尿病新科技.
- Added second-batch retrieval terms for metformin, finerenone, albuminuria/UACR, A1C reliability, hypoglycemia, older adults, pregnancy, and hospital steroid hyperglycemia.
- Generated [[reports/weekly-wiki-health]] with current wiki health summary: 0 broken links, 0 stale clinical pages, and remaining thin/weak-link candidates for future expansion.
- Added Hermes-only routing meta layer: [[_meta/topic-map]] and [[_meta/retrieval-policy]].
- Added inbox staging folders for [[inbox/research-requests/README]] and [[inbox/query-candidates/README]] so unanswered or reusable questions can be reviewed before canonical wiki writeback.
- Added [[reports/README]] for routine Hermes health, stale-page, duplicate, and low-confidence reports.
- Updated [[SCHEMA]] with `_meta/`, `inbox/`, and `reports/` directory roles plus optional retrieval frontmatter fields (`aliases`, `entities`, `owner_agent`, `write_policy`).
- Updated [[index]] to expose the new Hermes-alone router, retrieval policy, inbox, and report pages.

## 2026-05-19

- Stored Obsidian Local REST API token in macOS Keychain, added `/Users/ander/.codex/bin/mcp-obsidian-wrapper`, and registered `[mcp_servers.obsidian]` in `/Users/ander/.codex/config.toml`.
- Current Obsidian vault still points to the Google Drive vault, so a symlink named `ADA-KDIGO-Diabetes-Wiki` was added there to expose this wiki to the running REST API. Verified REST read of `ADA-KDIGO-Diabetes-Wiki/index.md`.
- Added MCP Obsidian setup notes and a Codex config template for `MarkusPfundstein/mcp-obsidian`. Initial check showed Local REST API was not responding, but it later became available after Obsidian Local REST API was enabled.
- Added Obsidian-oriented workflow support: `mocs/`, `docs/obsidian-graph-workflow.md`, MOC pages, and role-tag guidance inspired by Graph View grouping/local graph practices.
- Registered local ADA 2025 vs 2026 comparison corpus from `/Users/ander/openclaw-research/ada20252026`.
- Added [[raw/comparisons/ada-2025-vs-2026-comparison-registry]], [[comparisons/ada-2025-vs-2026-overview]], [[comparisons/ada-2025-vs-2026-methodology-concerns]], and [[comparisons/ada-2025-vs-2026-taiwan-impact]].
- Marked v1.3 comparison reports as preferred derived sources when present, while preserving older/base files as historical or supporting derived sources.
- Registered local Markdown guideline files from `/Users/ander/Documents/medical/guidelines/ada` and `/Users/ander/Documents/medical/guidelines/kdigo`.
- Added [[raw/guidelines/local-guideline-file-registry]] with ADA 2026 chapter file map and KDIGO 2026 local draft files.
- Added derived drug/recommendation pages for [[drugs/sglt2i-egfr-under-20-not-on-dialysis]] and [[drugs/glp1-based-therapy-on-dialysis]] based on local ADA/KDIGO synthesis files.
- Created initial LLM Wiki directory structure under `/Users/ander/Documents/hermes-agent/wiki/ada-kdigo-diabetes-wiki`.
- Added `SCHEMA.md`, `index.md`, and this `log.md`.
- Added source maps for ADA Standards of Care in Diabetes 2026 and KDIGO Diabetes Management in CKD 2026 public-review draft.
- Added first maintained guideline pages for ADA 2026 and KDIGO 2026.
- Added short alias files `guidelines/ada2026.md` and `guidelines/kdigo2026.md`.
- Added starter concept pages and an ADA-KDIGO comparison page.
- Evidence status note: ADA 2026 is published in Diabetes Care. KDIGO 2026 Diabetes Management in CKD is currently treated as a public-review draft, not a final guideline.

- Verified Obsidian MCP after Codex restart: `mcp__obsidian__` tools loaded, vault root lists `ADA-KDIGO-Diabetes-Wiki/`, and MCP read/write access was confirmed on 2026-05-19.

- Added [[docs/medical-query-knowledge-layer-strategy]] based on the user's Nexus / Agentic RAG / LLM Wiki note, defining artifact types, query flow, raw retrieval fallback, and starter evaluation questions for medical use.

- Expanded [[docs/medical-query-knowledge-layer-strategy]] with the explicit `LLM Wiki first, RAG second` retrieval hierarchy, sufficiency checks, router categories, answer format, and closed-loop update rule.
- Added [[docs/llm-wiki-retrieval-agent-prompt]] as a reusable prompt template for Hermes/OpenClaw/Codex/Obsidian MCP medical retrieval workflows.

- Added [[docs/hermes-agent-wiki-workflow]] with Hermes one-shot, interactive, ingest, artifact expansion, and weekly health-check patterns for this ADA-KDIGO Diabetes Wiki.
- Added Hermes routine maintainer prompts and script for duplicate detection, thin-page checks, metadata gaps, weak wikilinks, and safe update workflow.
- Added [[docs/hermes-routine-maintenance]] and indexed it as the entry point for routine Hermes audits.
