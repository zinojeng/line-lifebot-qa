---
title: ADA-KDIGO Diabetes Wiki Log
summary: Chronological maintenance log for wiki ingestion, source-aware updates, graph routing, aliases, evidence cards, claim registries, and review follow-ups.
type: meta
created: 2026-05-19
updated: 2026-05-24
tags: [log, llm-wiki, maintenance, changelog]
sources:
  - index.md
  - SCHEMA.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-24
status: active
obsidian_type: registry
aliases:
  - wiki log
  - change log
entities:
  - ADA-KDIGO Diabetes Wiki
  - Hermes Agent
related:
  - index
  - SCHEMA
  - reports/weekly-wiki-health
  - reports/wiki-self-improvement-audit
owner_agent: hermes
write_policy: hermes-maintained
---

# ADA-KDIGO Diabetes Wiki Log

## 2026-05-24

- Added Evidence Grade Router 2.0 policy: evidence-grade questions now boost only the routed chapter's claim registry instead of boosting all claim pages.
- Updated [[mocs/evidence-grade-router-moc]], [[_meta/retrieval-policy]], and [[_meta/typed-relationships]] to document Section 12, MASLD/MASH, CKD/cardiorenal, and mixed-context routing.
- Added local LINE QA FTS regression coverage for retinopathy treatment grades, neuropathy medication grades, MASLD/MASH grades, and CKD lower-certainty evidence routing.

## 2026-05-23

- Completed source-aware Markdown normalization for maintained ADA/KDIGO Diabetes LLM Wiki pages without changing raw sources or clinical recommendation text.
- Rebuilt `_meta/INDEX.json`, `_meta/page-registry.json`, `_meta/claim-registry.json`, FTS search index, synthetic QA cases, source freshness watch, weekly health report, and graph audit.
- Added frontmatter and graph routes to core files, MOCs, reports, guideline aliases, evidence cards, evidence ledgers, and inbox records.
- Updated [[evals/synthetic-qa-registry]] to document that synthetic QA excludes root operating files such as [[HERMES]], [[SCHEMA]], [[index]], and [[log]], keeping regression focus on clinical routing, MOC behavior, and prior LINE failures.
- Verified graph health after rebuild: orphan pages 0, weak-link pages 0, broken wikilinks 0, broken related entries 0, missing MOC routes 0, missing alias routes 0, and duplicate title candidates 0.
- Remaining intentional audit items: raw source-map files are not auto-normalized, and [[guidelines/kdigo2026]] remains a short draft-guideline alias page that needs no automatic clinical expansion.
- Added [[reports/manual-frontmatter-review]] to document that SCHEMA/index/core files were manually approved for full frontmatter, while raw source maps and short draft-guideline alias pages remain intentionally skipped.
- Added [[_meta/deferred-topics]] and updated the self-improvement auditor so intentionally deferred seeds, including older-adults/frailty routed through [[guidelines/ada-standards-of-care-2026]], do not recreate duplicate research requests.
- Normalized frontmatter `related:` links to canonical root-relative wiki paths without `.md` suffix while keeping `sources:` filenames intact for provenance.
- Corrected CGM placeholder pages to use schema-valid `confidence: uncertain` while preserving `status: needs-source`.
- Claude review follow-up: removed template placeholder wikilinks that caused false-positive broken links, declared the `compares_with` relationship type, and removed the regenerated older-adults/frailty request because it was already deferred and routed to ADA 2026.
- Claude review follow-up: aligned the neuropathy synthetic QA expected term with the source wording `gabapentinoid` instead of the narrower `gabapentin`.
- Added [[docs/llm-wiki-markdown-note-standard]] as the per-file structure standard for maintained Markdown pages before they become LLM Wiki knowledge units.
- Added [[docs/hermes-md-normalization-schedule]] to let Hermes normalize all `.md` files in small reviewed batches instead of mass-editing the wiki.
- Added copyable templates for concept pages, source maps, workflow/project pages, and medical evidence cards under `docs/templates/`.
- Added a generic Markdown normalization program in the LINE QA operations repo: `scripts/normalize_wiki_markdown.py`, exposed through `scripts/wiki_ops.py md-audit` and `scripts/wiki_ops.py md-normalize`.
- Updated [[SCHEMA]], [[HERMES]], [[index]], [[_meta/topic-map]], and [[_meta/aliases]] so Hermes can find and run the Markdown audit/normalization workflow.
- Claude review follow-up: excluded MOC pages from automatic Markdown normalization, clarified normalization-audit page-count scope, added explicit Section 12 synthetic QA cases, and normalized new evidence-card `obsidian_type` values to the schema-supported `relationship`.
- Ran the first safe Markdown normalization batch after graph-rebuild request: normalized 6 low-risk workflow/meta pages and reduced low-risk auto-fix candidates from 51 to 45.
- Added `scripts/analyze_wiki_graph.py` in the LINE QA operations repo and generated [[reports/wiki-graph-rebuild-audit]] for orphan pages, weak links, missing aliases, missing MOC routes, duplicate concepts, and missing typed relationship edges.
- Updated [[_meta/topic-map]], [[_meta/aliases]], [[_meta/typed-relationships]], and [[index]] so graph rebuild and relationship-audit outputs are discoverable by Hermes and Obsidian.
- Claude review follow-up: updated the registry builder to ignore fenced-code placeholder wikilinks in templates, and documented that wiki normalization commands require the sibling LINE QA operations repo path.

- Processed selected self-improvement request [[inbox/research-requests/2026-05-22-self-audit-diabetes-masld-and-mash]].
- Created [[concepts/diabetes-masld-mash]], [[claims/ada-2026-masld-mash-claims]], and [[evidence-ledger/masld-mash-ledger]] after raw ADA 2026 Section 4 verification in `dc26s004.md` recommendations 4.22a-4.32b.
- Updated [[index]], [[_meta/topic-map]], and [[_meta/aliases]] so MASLD/MASH, fatty liver/NAFLD/NASH, FIB-4/ELF/LSM, GLP-1, pioglitazone, semaglutide, resmetirom, and Traditional Chinese LINE phrasings route to source-verified pages.
- Applied Claude review follow-up for MASLD/MASH: removed absolute raw path from frontmatter sources, renamed split 4.25 claim IDs, added ADA 4.32a/4.32b metabolic-surgery claim rows, and added [[mocs/evidence-grade-router-moc]] routing for MASLD/MASH evidence-grade follow-ups.
- Applied second Claude review follow-up for MASLD/MASH: split ADA 4.31b statin compensated/decompensated cirrhosis rows, renamed 4.32a surgery claim IDs, and replaced absolute path provenance markers with the portable raw guideline registry anchor.
- Added link-strength workflow: generated [[reports/link-strength-report]], promoted common LINE phrasings into `queries/`, expanded [[_meta/typed-relationships]], strengthened inbound `related:` edges for weak query/ledger/MOC pages, and spot-checked MASLD/MASH split-grade rows against raw `dc26s004.md` lines 1404-1415.

## 2026-05-22

- Added [[mocs/evidence-grade-router-moc]] to route short LINE evidence-grade follow-ups by recent clinical context instead of defaulting to CKD.
- Added [[evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] with source-verified ADA 2026 Section 12 recommendation numbers and grades for retinopathy treatment, neuropathy treatment, foot care, and PAD.
- Expanded [[claims/ada-2026-retinopathy-foot-pad-claims]] with retinopathy treatment and neuropathy treatment claim cards.
- Updated [[_meta/aliases]], [[_meta/topic-map]], and [[_meta/typed-relationships]] for retinopathy/neuropathy evidence-grade routing.
- Processed selected self-improvement research requests for diabetes ASCVD lipid targets and diabetes CKD blood-pressure targets.
- Created [[evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] after raw ADA 2026 Section 10 verification.
- Created [[evidence-cards/ada-kdigo-2026-bp-ckd-targets]] after raw ADA 2026 Sections 10/11 and KDIGO 2026 public-review draft verification.
- Updated [[_meta/aliases]], [[_meta/topic-map]], [[index]], and marked the two selected research requests resolved.
- Applied review follow-up: split separately graded recommendation clauses into distinct rows and replaced slug-style research-request aliases with natural-language aliases.
- Applied second review follow-up: corrected ADA 10.3/10.4 BP grade parsing from raw Section 10, documented local ADA 10.27 Grade B recheck, expanded lipid ADA aliases, and removed an out-of-scope older-adults request generated during audit rerun.
- The removed out-of-scope request was `inbox/research-requests/2026-05-22-self-audit-older-adults-diabetes-frailty-and-hypoglycemia.md`; older-adults/frailty remains routed at topic-map level to [[guidelines/ada-standards-of-care-2026]] pending a future dedicated extraction.
- Applied final review follow-up: expanded BP ADA 10.x aliases in [[_meta/aliases]] and cleared resolved research-request aliases to avoid collisions with canonical evidence-card aliases.
- Tightened evidence-card notes: cited ADA 10.27 raw line verification, documented ADA 10.10/11.6a duplication, and clarified resolved-request raw source files.

- Converted the LINE `Metformin in GDM evidence` answer-improvement into durable wiki routing: expanded [[concepts/diabetes-pregnancy-gdm-cgm]] aliases, added [[evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]], [[claims/ada-2026-gdm-pharmacotherapy-claims]], and [[evidence-ledger/gdm-pharmacotherapy-ledger]], and wired aliases/topic-map/typed relationships/synthetic QA so future GDM pharmacotherapy questions route to ADA 2026 Section 15 instead of broad CKD/CGM pages.
- Processed selected daily self-improvement requests for hospital steroid hyperglycemia and pregnancy/GDM + CGM.
- Verified ADA 2026 Section 16 steroid-hyperglycemia source facts against `dc26s016.md` via [[raw/guidelines/local-guideline-file-registry]].
- Verified ADA 2026 Section 15 pregnancy/CGM source facts against `dc26s015.md` and Section 7 AID pregnancy caveats against `dc26s007.md`.
- Created [[concepts/hospital-steroid-hyperglycemia]] and [[concepts/diabetes-pregnancy-gdm-cgm]].
- Updated [[_meta/aliases]], [[_meta/topic-map]], [[index]], and the two resolved research requests.
- Daily audit also opened two next-queue research requests: [[inbox/research-requests/2026-05-22-self-audit-diabetes-ascvd-lipid-targets]] and [[inbox/research-requests/2026-05-22-self-audit-diabetes-masld-and-mash]].

## 2026-05-21

- Processed selected self-improvement requests for retinopathy screening/follow-up and foot care/PAD risk.
- Verified ADA 2026 Section 12 source facts against `dc26s012.md` via [[raw/guidelines/local-guideline-file-registry]].
- Created [[concepts/diabetes-retinopathy-screening]] and [[concepts/diabetes-foot-care-pad]].
- Updated [[claims/ada-2026-retinopathy-foot-pad-claims]], [[evidence-ledger/retinopathy-foot-pad-ledger]], [[_meta/aliases]], [[_meta/topic-map]], [[index]], and resolved the two corresponding research-request files.

- Confirmed the wiki has a local Git baseline (`941f119`) so the Mac mini Claude CLI review gate can use `git diff` directly.
- Updated [[HERMES]], [[docs/llm-wiki-self-improvement-loop]], and [[docs/hermes-agent-wiki-workflow]] for the generic Claude review wrapper modes: `worktree`, `staged`, `branch <base>`, and `head`.
- Verified the local wrapper help exposes the documented modes; `worktree` reviewed this wiki diff through the Mac mini Claude CLI, and `branch main` runs as an empty branch-level diff while on `main`.
- Added a Claude Code review gate to [[HERMES]] and [[docs/llm-wiki-self-improvement-loop]]: after each implementation step, run Claude review, apply only high-confidence grounded findings, re-run local checks, and report review status before completion.
- Updated the review gate to use the local wrapper `/Users/ander/Documents/Projects/OpenAI/.agents/skills/claude-review/scripts/claude-review.sh`, which reviews the current `git diff` from inside a Git worktree.
- Superseded the older single implicit wrapper command with the explicit mode contract above.

## 2026-05-20

- Added machine-readable wiki registry plan and expanded current implementation targets for `INDEX.json`, page registry, claim registry, evidence ledgers, SQLite FTS5 search, and `wiki_ops.py`.
- Added claim registries for CGM/AID, bone health/osteoporosis, GLP-1 muscle/sarcopenia, and retinopathy/foot/PAD pending extraction.
- Added append-only evidence ledgers for CKD cardiorenal, CGM/AID, bone health, GLP-1 muscle/sarcopenia, and retinopathy/foot/PAD.
- Updated index, topic map, aliases, schema, and self-improvement workflow to expose claim registries, evidence ledgers, machine-readable indexes, and QMD-like FTS search.
- Added claim registry layer: `claims/ada-kdigo-2026-ckd-cardiorenal-claims.md`.
- Added typed relationship map: `_meta/typed-relationships.md`.
- Added synthetic QA registry: `evals/synthetic-qa-registry.md`.
- Updated schema, index, topic map, aliases, retrieval policy, and self-improvement workflow to route recommendation-grade follow-up questions through claims before broad evidence-card pages.
- Added `scripts/hermes_daily_wiki_self_improvement.py` as the daily Hermes queue generator: it runs wiki self-audit, regenerates health report, and injects only 1-2 open research requests for that day's maintenance pass.
- Updated [[docs/llm-wiki-self-improvement-loop]] and [[docs/hermes-only-research-os]] with the daily self-improvement cron pattern and the 1-2 request safety limit.
- Added [[docs/llm-wiki-self-improvement-loop]] and generated [[reports/wiki-self-improvement-audit]] as a proactive lint layer for duplicate candidates, under-routed topics, consistency review, research-request creation, and synthetic QA seeds.
- Added local CLI tools `scripts/wiki_search.py` and `scripts/wiki_self_improvement_audit.py` so Hermes/Codex can search and audit the wiki before LINE users ask failing questions.
- Added [[concepts/glp1-weight-loss-muscle-sarcopenia]] after LINE QA exposed an incomplete answer for GLP-1 weight loss with SMI decline, weaker handgrip, weak legs, and concern for sarcopenia.
- Updated [[index]], [[_meta/topic-map]], and [[_meta/aliases]] so LINE questions about GLP1 減重肌肉、SMI 降低、握力下降、腿沒力、lean mass loss, and 肌少症 route to the new concept page.
- Added [[evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] as the fine-grained ADA/KDIGO evidence-card layer for exact recommendation numbers, grades, thresholds, and lower-certainty buckets in diabetes + CKD cardiorenal medication questions.
- Updated [[SCHEMA]], [[index]], [[_meta/topic-map]], [[_meta/aliases]], and [[comparisons/ada-kdigo-2026-evidence-strength-map]] so Hermes/LINE routes "strong recommendation", "哪些證據等級較低", ADA 11.7a/11.11a, and KDIGO 4.3.1/4.5.1 questions directly to the evidence-card page.
- Added [[comparisons/ada-kdigo-2026-evidence-strength-map]] to route LINE follow-up questions about strong recommendations, evidence grade, and lower-certainty ADA/KDIGO CKD evidence without inventing exact grade labels.
- Updated [[index]], [[_meta/topic-map]], and [[comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] to link the evidence-strength map.
- Updated answer-improvement loop policy to allow Gemini reviewer by default, with OpenAI reviewer as an optional provider.
- Added production note that Zeabur persistent storage should mount `/app/data` so synced wiki files and generated inbox records survive redeploys.
- Added post-answer self-improvement loop support: [[inbox/answer-improvements/README]] for OpenAI mini review records and [[reports/answer-improvement-analysis]] for repeated safe action patterns.
- Updated [[_meta/topic-map]], [[reports/README]], and [[index]] so Hermes can route answer-improvement records into aliases, MOC links, smoke tests, or research requests without directly changing clinical claims.
- Added [[concepts/diabetes-bone-health-osteoporosis]] after LINE QA exposed a false-negative answer for "糖尿病與骨質疏鬆治療是否與一般人不同？".
- Updated [[_meta/aliases]] and [[_meta/topic-map]] with osteoporosis, bone health, fracture risk, DXA, BMD, T-score, FRAX, 骨鬆, 骨密度, and 骨折風險 routes.
- Updated [[index]] so Hermes/LINE retrieval can answer from ADA 2026 Section 4 before falling back to raw/RAG.
- Added retrieval failure learning loop: [[inbox/retrieval-failures/README]], retrieval-failure writeback support in LINE QA, and `scripts/compile_retrieval_failures.py` for grouped reports.
- Updated [[HERMES]] and [[docs/hermes-only-research-os]] with failure-analysis rules: missing aliases/routes, missing facets, retrieval noise, verification gaps, and source gaps become safe improvement tasks.
- Added [[HERMES]] as the project-level Hermes operating instructions for this wiki.
- Added [[_meta/aliases]] as the central alias registry and [[_meta/lint-report]] as the lint/health report entry point.
- Added [[docs/hermes-only-research-os]] describing Hermes roles, custom skills, and the wiki-centered operating loop.
- Installed local Hermes skills: `wiki-query-medical`, `wiki-ingest-medical`, `wiki-lint-medical`, and `wiki-distill-medical`.
- Added daily and monthly Hermes prompts plus `scripts/hermes-ada-kdigo-operating-loop.sh`.
- Created Hermes cron jobs for daily brief (`9b47b879c772`), weekly lint (`253e1f489161`), and monthly refresh (`2cdaf6bd7471`).
- Regenerated [[reports/weekly-wiki-health]] after adding Hermes-only operating files; current report shows 0 broken links and 0 stale clinical pages.
- Added retrieval metadata (`aliases`, `entities`, `owner_agent`, `write_policy`) to core pages for CKD/eGFR, SGLT2i, GLP-1RA/dialysis, CGM/AID, ADA 2026, KDIGO 2026, ADA-KDIGO crosswalk, and medical-student teaching.
- Expanded [[_meta/topic-map]] with common LINE query terms such as SGLT2i, GLP-1RA, eGFR under 20, dialysis, CGM, 連續血糖, 排糖藥, and 糖尿病新科技.
- Added second-batch retrieval terms for metformin, finerenone, albuminuria/UACR, A1C reliability, hypoglycemia, older adults, pregnancy, and hospital steroid hyperglycemia.
- Generated [[reports/weekly-wiki-health]] with current wiki health summary: 0 broken links, 0 stale clinical pages, and remaining thin/weak-link candidates for future expansion.
- Added Hermes-only routing meta layer: [[_meta/topic-map]] and [[_meta/retrieval-policy]].
- Added inbox staging folders for [[inbox/research-requests/README]] and [[inbox/query-candidates/README]] so unanswered or reusable questions can be reviewed before canonical wiki writeback.
- Added [[reports/README]] for routine Hermes health, stale-page, duplicate, and low-confidence reports.
- Updated [[SCHEMA]] with `_meta/`, `inbox/`, and `reports/` directory roles plus optional retrieval frontmatter fields (`aliases`, `entities`, `owner_agent`, `write_policy`).
- Updated [[index]] to expose the new Hermes-alone router, retrieval policy, inbox, and report pages.

## 2026-05-19

- Stored Obsidian Local REST API token in macOS Keychain, added `/Users/ander/.codex/bin/mcp-obsidian-wrapper`, and registered `[mcp_servers.obsidian]` in `/Users/ander/.codex/config.toml`.
- Current Obsidian vault still points to the Google Drive vault, so a symlink named `ADA-KDIGO-Diabetes-Wiki` was added there to expose this wiki to the running REST API. Verified REST read of `ADA-KDIGO-Diabetes-Wiki/index.md`.
- Added MCP Obsidian setup notes and a Codex config template for `MarkusPfundstein/mcp-obsidian`. Initial check showed Local REST API was not responding, but it later became available after Obsidian Local REST API was enabled.
- Added Obsidian-oriented workflow support: `mocs/`, `docs/obsidian-graph-workflow.md`, MOC pages, and role-tag guidance inspired by Graph View grouping/local graph practices.
- Registered local ADA 2025 vs 2026 comparison corpus from `/Users/ander/openclaw-research/ada20252026`.
- Added [[raw/comparisons/ada-2025-vs-2026-comparison-registry]], [[comparisons/ada-2025-vs-2026-overview]], [[comparisons/ada-2025-vs-2026-methodology-concerns]], and [[comparisons/ada-2025-vs-2026-taiwan-impact]].
- Marked v1.3 comparison reports as preferred derived sources when present, while preserving older/base files as historical or supporting derived sources.
- Registered local Markdown guideline files from `/Users/ander/Documents/medical/guidelines/ada` and `/Users/ander/Documents/medical/guidelines/kdigo`.
- Added [[raw/guidelines/local-guideline-file-registry]] with ADA 2026 chapter file map and KDIGO 2026 local draft files.
- Added derived drug/recommendation pages for [[drugs/sglt2i-egfr-under-20-not-on-dialysis]] and [[drugs/glp1-based-therapy-on-dialysis]] based on local ADA/KDIGO synthesis files.
- Created initial LLM Wiki directory structure under `/Users/ander/Documents/hermes-agent/wiki/ada-kdigo-diabetes-wiki`.
- Added `SCHEMA.md`, `index.md`, and this `log.md`.
- Added source maps for ADA Standards of Care in Diabetes 2026 and KDIGO Diabetes Management in CKD 2026 public-review draft.
- Added first maintained guideline pages for ADA 2026 and KDIGO 2026.
- Added short alias files `guidelines/ada2026.md` and `guidelines/kdigo2026.md`.
- Added starter concept pages and an ADA-KDIGO comparison page.
- Evidence status note: ADA 2026 is published in Diabetes Care. KDIGO 2026 Diabetes Management in CKD is currently treated as a public-review draft, not a final guideline.

- Verified Obsidian MCP after Codex restart: `mcp__obsidian__` tools loaded, vault root lists `ADA-KDIGO-Diabetes-Wiki/`, and MCP read/write access was confirmed on 2026-05-19.

- Added [[docs/medical-query-knowledge-layer-strategy]] based on the user's Nexus / Agentic RAG / LLM Wiki note, defining artifact types, query flow, raw retrieval fallback, and starter evaluation questions for medical use.

- Expanded [[docs/medical-query-knowledge-layer-strategy]] with the explicit `LLM Wiki first, RAG second` retrieval hierarchy, sufficiency checks, router categories, answer format, and closed-loop update rule.
- Added [[docs/llm-wiki-retrieval-agent-prompt]] as a reusable prompt template for Hermes/OpenClaw/Codex/Obsidian MCP medical retrieval workflows.

- Added [[docs/hermes-agent-wiki-workflow]] with Hermes one-shot, interactive, ingest, artifact expansion, and weekly health-check patterns for this ADA-KDIGO Diabetes Wiki.
- Added Hermes routine maintainer prompts and script for duplicate detection, thin-page checks, metadata gaps, weak wikilinks, and safe update workflow.
- Added [[docs/hermes-routine-maintenance]] and indexed it as the entry point for routine Hermes audits.
