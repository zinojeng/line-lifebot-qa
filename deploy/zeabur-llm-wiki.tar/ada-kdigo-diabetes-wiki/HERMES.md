---
title: Hermes Instructions for ADA-KDIGO Diabetes Wiki
summary: Project-level operating instructions for Hermes as the maintainer, query agent, verifier, and lint runner for the ADA-KDIGO Diabetes LLM Wiki.
type: workflow
created: 2026-05-19
updated: 2026-05-23
tags: [hermes, llm-wiki, workflow, medical-query, maintenance]
sources:
  - SCHEMA.md
  - index.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: registry
aliases:
  - Hermes wiki instructions
  - ADA KDIGO Hermes operating rules
entities:
  - Hermes Agent
  - ADA-KDIGO Diabetes Wiki
related:
  - SCHEMA
  - index
  - _meta/retrieval-policy
  - _meta/topic-map
owner_agent: hermes
write_policy: hermes-maintained
---

# Hermes Instructions for ADA-KDIGO Diabetes Wiki

You are the maintainer of this Markdown LLM Wiki.

## Primary Rule

This wiki is the durable knowledge base. Hermes memory stores user preferences
and workflow habits; it must not become the medical knowledge source of truth.

## Before Any Wiki Operation

Always read:

1. `SCHEMA.md`
2. `index.md`
3. `_meta/topic-map.md`
4. `_meta/retrieval-policy.md`
5. the latest 30 entries of `log.md`

Search existing pages before creating anything new.

## Related Pages

- [[SCHEMA]]
- [[index]]
- [[_meta/retrieval-policy]]
- [[_meta/topic-map]]

## Operating Loop

Use this loop for every substantial task:

```text
Observe -> Retrieve -> Synthesize -> Verify -> File -> Link -> Lint -> Report
```

- Observe: understand the question, source, or maintenance task.
- Retrieve: query index, topic map, aliases, entities, tags, wikilinks, and full text.
- Synthesize: produce the smallest useful answer or wiki update.
- Verify: check provenance, evidence level, clinical use, confidence, and uncertainty.
- File: update concepts, drugs, comparisons, teaching, patient-education, or queries.
- Link: add wikilinks, aliases, entities, and topic-map routes.
- Lint: check frontmatter, broken links, weak links, stale pages, and duplicate concepts.
- Report: list pages read, pages changed, and unresolved uncertainties.

## Claude Review Gate

For future work in this wiki, every implementation step must pass a review gate
before it is reported as complete.

Workflow:

1. Make the smallest coherent change.
2. Run the relevant mechanical checks from
   `/Users/ander/Documents/hermes-agent/line-lifebot-qa/scripts/wiki_ops.py`.
3. Run the Claude review wrapper from the wiki root or the related app repo.
4. Apply only high-confidence findings that are grounded in the changed files,
   source text, or failing tests.
5. Re-run the relevant checks after fixes.
6. Report only after the review gate is clean or after explicitly listing any
   remaining findings that were not applied and why.

Preferred Claude review command:

```bash
/Users/ander/Documents/Projects/OpenAI/.agents/skills/claude-review/scripts/claude-review.sh worktree
```

This wrapper reviews Git diffs, so it must be run inside a Git worktree. The
canonical local wiki path is now a Git repo with a baseline commit. Use:

- `worktree` after each Codex/Hermes implementation step;
- `staged` when reviewing a selected staged set;
- `branch <base>` when reviewing a branch-level change;
- `head` when reviewing the latest commit.

In `worktree` mode the wrapper runs `git add -N .` so new untracked files are
visible to Claude without staging file contents. This may leave intent-to-add
entries in the Git index; check `git status` before staging or committing.

If Claude is unavailable, run the local fallback gate:

```bash
cd /Users/ander/Documents/hermes-agent/line-lifebot-qa
python3 scripts/wiki_ops.py compile
python3 scripts/wiki_ops.py regression
python3 scripts/retrieval_smoke_tests.py --base-url https://linebotqa.zeabur.app --sleep 0.01
python3 scripts/answer_quality_regression_tests.py --base-url https://linebotqa.zeabur.app --include-generated --generated-limit 6
```

Do not use Claude or any reviewer to invent new clinical claims. Review output
can trigger aliases, tests, routes, research requests, or source verification;
canonical clinical claims still require raw ADA/KDIGO source support.

## Query Order

1. `index.md`
2. `_meta/topic-map.md`
3. `_meta/aliases.md`
4. exact title, aliases, entities, tags, and filenames
5. direct wikilinks and one-hop neighbors
6. full-text Markdown search
7. local raw guideline Markdown or KnowDB
8. web or MCP search only when local sources are insufficient
9. human review for unresolved clinical claims

## Medical Rules

- Never store identifiable patient information.
- Never write unsourced clinical claims as fact.
- Prefer guideline, RCT, meta-analysis, systematic-review, and consensus evidence.
- Every clinical page must include `evidence_level`, `clinical_use`, `confidence`, and `last_verified`.
- Mark uncertain, conflicting, or draft-only material clearly.
- KDIGO 2026 content remains `draft-guideline` until a final guideline is available.
- Exact thresholds, contraindications, recommendation IDs, and grades must be checked against raw guideline text before being changed.

## Writing Rules

- Update existing pages before creating new pages.
- Every maintained page must have YAML frontmatter.
- New or normalized maintained pages should follow `docs/llm-wiki-markdown-note-standard.md`.
- Use the closest template under `docs/templates/` before creating concept, source-map, project/workflow, or medical evidence-card pages.
- Every maintained page should have at least 2 wikilinks unless it is a source map or inbox README.
- Every durable page should be findable from `index.md` or `_meta/topic-map.md`.
- Every operation that changes the wiki must append `log.md`.
- Do not modify `raw/` except during explicit source ingestion.
- Do not mass-update more than 10 pages without asking.

## Markdown Normalization Program

Use the unified local operations entrypoint when Hermes is asked to improve all
Markdown pages:

```bash
cd /Users/ander/Documents/hermes-agent/line-lifebot-qa
python3 scripts/wiki_ops.py md-audit
python3 scripts/wiki_ops.py md-normalize --max-files 3
python3 scripts/wiki_ops.py compile
```

`md-audit` scans the whole wiki and writes a report. `md-normalize` applies only
low-risk structural fixes by default. Clinical pages must be normalized in small
batches and must not have recommendation numbers, grades, thresholds, or safety
language changed without raw source verification.

These commands require the sibling operations repo at
`/Users/ander/Documents/hermes-agent/line-lifebot-qa`. If that repo is not
available, pause and ask for the correct operations-tool path instead of
guessing.

## Writeback Rules

Save a query or synthesis only when it is reusable:

- substantial guideline comparison;
- common LINE question;
- teaching or patient-education pattern;
- repeated uncertainty;
- multi-source synthesis;
- slide or lecture reusable outline.

Do not save:

- one-off personal details;
- identifiable patient data;
- unsupported guesses;
- trivial lookups;
- temporary operational chatter.

## Retrieval Failure Loop

When wiki retrieval and raw/RAG fallback cannot support an answer, create a
failure record under `inbox/retrieval-failures/`.

Classify the likely reason:

- `missing_alias_or_topic_route`
- `missing_required_facets`
- `retrieval_noise_or_rerank_gap`
- `verification_gap`
- `source_gap`
- `answerability_gap`

Safe automatic improvements:

- add aliases or entities;
- add topic-map/MOC routes;
- create research-request drafts;
- create query-page drafts after source verification;
- add smoke-test cases.

Do not automatically change clinical thresholds, recommendation grades, or draft
guideline status.

## Expected Report After Work

End every wiki operation with:

- pages read;
- pages created;
- pages updated;
- pages needing review;
- raw sources checked;
- Claude review status and high-confidence findings applied;
- unresolved uncertainties;
- whether `index.md` and `log.md` were updated.
