---
title: ADA 2025 vs 2026 Comparison Registry
type: source-map
created: 2026-05-19
updated: 2026-05-19
tags: [source, ada, standards-of-care, comparison, 2025, 2026, local-source]
sources:
  - /Users/ander/openclaw-research/ada20252026
evidence_level: source-map
clinical_use: clinical-reference
confidence: high
last_verified: 2026-05-19
status: active
obsidian_type: source
---

# ADA 2025 vs 2026 Comparison Registry

## Source Role

This directory is a derived comparison corpus, not the primary guideline source. Use it to understand changes, prepare teaching material, identify clinical impact, and prioritize source verification. For exact recommendation wording, verify against the underlying ADA 2025 and ADA 2026 Markdown files.

Local directory: `/Users/ander/openclaw-research/ada20252026`

## Preferred Round 5 / v1.3 Sources

| File | Role |
|---|---|
| `ada2025vs2026_executive_summary_v1.3.md` | Preferred executive summary |
| `ada2025vs2026_change_matrix_v1.3.md` | Preferred change matrix |
| `ada2025vs2026_quick_reference_v1.3.md` | Preferred clinician quick reference |
| `ada2025vs2026_final_report_v1.3.md` | Preferred full report |
| `ada2025vs2026_methodology_v1.3.md` | Preferred methodology report |
| `ada2025vs2026_fulltext_status_v1.3.md` | Preferred full-text status |
| `ada2025vs2026_figures_algorithms_v1.3.md` | Preferred figures and algorithms comparison |
| `ada2025vs2026_tables_comparison_v1.3.md` | Preferred table comparison |
| `ada2025vs2026_taiwan_impact_v1.3.md` | Preferred Taiwan impact report |

## Additional High-Value Source Files

| File | Role |
|---|---|
| `ada2025vs2026_methodology_concerns.md` | Evidence-quality and methodology alerts |
| `ada2025vs2026_figures_tables_comparison_zhtw.md` | Traditional Chinese figures/tables comparison |
| `ada2025vs2026_tables_s1s4_comparison.md` | Section 1-4 table comparison |
| `ada2025vs2026_S5S6_tables_comparison.md` | Section 5-6 table comparison |
| `ada2025vs2026_tables_S7-S9_comparison.md` | Section 7-9 table comparison |
| `ada2025vs2026_tables_S13-S17.md` | Section 13-17 table comparison |
| `s13_older_adults_comparison_2025vs2026.md` | Older adults section comparison |
| `s14_comparison_2025vs2026.md` | Children and adolescents section comparison |
| `s15_comparison_2025vs2026.md` | Pregnancy section comparison |
| `s16_comparison_2025vs2026.md` | Hospital care section comparison |
| `MISSING_FULLTEXT.md` | Missing full-text tracker |

## Subdirectories To Search

- `2025md/` - ADA 2025 Markdown source files.
- `2026md/` - ADA 2026 Markdown source files.
- `ch10/` - Cardiovascular chapter work products.
- `change/` - Change-focused extracted artifacts.
- `reports/` - Additional reports.
- `v5/` - Later-round artifacts.

## Wiki Links

- [[../../comparisons/ada-2025-vs-2026-overview]]
- [[../../comparisons/ada-2025-vs-2026-methodology-concerns]]
- [[../../comparisons/ada-2025-vs-2026-taiwan-impact]]
- [[../../guidelines/ada-standards-of-care-2026]]
