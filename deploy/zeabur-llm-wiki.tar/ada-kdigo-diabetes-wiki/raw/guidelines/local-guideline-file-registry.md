---
title: Local Guideline File Registry
type: source-map
created: 2026-05-19
updated: 2026-05-19
tags: [source, local-source, ada, kdigo, diabetes, ckd, markdown]
sources:
  - /Users/ander/Documents/medical/guidelines/ada
  - /Users/ander/Documents/medical/guidelines/kdigo
evidence_level: source-map
clinical_use: clinical-reference
confidence: high
last_verified: 2026-05-19
status: active
obsidian_type: source
---

# Local Guideline File Registry

## Source Policy

These files are the local Markdown source corpus for this wiki. Do not edit them from inside the wiki workflow. Use maintained wiki pages as derived knowledge, and return to these local files for exact recommendation wording, recommendation numbers, evidence grades, tables, and figures.

## ADA 2026 Local Files

Local directory: `/Users/ander/Documents/medical/guidelines/ada`

| File | Section |
|---|---|
| `dc26s001.md` | Improving Care and Promoting Health in Populations |
| `dc26s002.md` | Diagnosis and Classification of Diabetes |
| `dc26s003.md` | Prevention or Delay of Diabetes and Associated Comorbidities |
| `dc26s004.md` | Comprehensive Medical Evaluation and Assessment of Comorbidities |
| `dc26s005.md` | Facilitating Positive Health Behaviors and Well-being to Improve Health Outcomes |
| `dc26s006.md` | Glycemic Goals, Hypoglycemia, and Hyperglycemic Crises |
| `dc26s007.md` | Diabetes Technology |
| `dc26s008.md` | Obesity and Weight Management for the Prevention and Treatment of Diabetes |
| `dc26s009.md` | Pharmacologic Approaches to Glycemic Treatment |
| `dc26s010.md` | Cardiovascular Disease and Risk Management |
| `dc26s011.md` | Chronic Kidney Disease and Risk Management |
| `dc26s012.md` | Retinopathy, Neuropathy, and Foot Care |
| `dc26s013.md` | Older Adults |
| `dc26s014.md` | Children and Adolescents |
| `dc26s015.md` | Management of Diabetes in Pregnancy |
| `dc26s016.md` | Diabetes Care in the Hospital |
| `dc26s017.md` | Diabetes Advocacy |

## KDIGO 2026 Local Files

Local directory: `/Users/ander/Documents/medical/guidelines/kdigo`

| File | Role |
|---|---|
| `KDIGO-2026-Diabetes-and-CKD-Guideline-Update-Public-Review-Draft-March-2026.md` | KDIGO 2026 Diabetes and CKD public-review draft Markdown |
| `ADA-2026-11.11a-SGLT2i-eGFR-under-20.md` | Local synthesis of ADA 2026 and KDIGO 2026 draft on SGLT2i continuation when eGFR falls below 20 before dialysis/KRT |
| `ADA-2026-11.11b-GLP1-on-dialysis.md` | Local synthesis of ADA 2026 and KDIGO 2026 draft on GLP-1-based therapy in dialysis |

## Wiki Links

- [[../../guidelines/ada-standards-of-care-2026]]
- [[../../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[../../drugs/sglt2i-egfr-under-20-not-on-dialysis]]
- [[../../drugs/glp1-based-therapy-on-dialysis]]
