---
title: KDIGO Diabetes Management in CKD 2026 Source Map
type: source-map
created: 2026-05-19
updated: 2026-05-19
tags: [source, kdigo, diabetes, ckd, guideline, draft, 2026]
sources:
  - https://kdigo.org/guidelines/diabetes-ckd/
evidence_level: source-map
clinical_use: clinical-reference
confidence: high
last_verified: 2026-05-19
status: active
obsidian_type: source
---

# KDIGO Diabetes Management in CKD 2026 Source Map

## Status

KDIGO states that the draft of the 2026 Clinical Practice Guideline for Diabetes Management in Chronic Kidney Disease was made available for public review. Until the final document is published, pages derived from this source should use `evidence_level: draft-guideline` and avoid final-language claims.

## Official Entry Point

- KDIGO Diabetes and CKD page: https://kdigo.org/guidelines/diabetes-ckd/

## Local Markdown Sources

- Public-review draft: `/Users/ander/Documents/medical/guidelines/kdigo/KDIGO-2026-Diabetes-and-CKD-Guideline-Update-Public-Review-Draft-March-2026.md`
- ADA/KDIGO synthesis on SGLT2i eGFR under 20: `/Users/ander/Documents/medical/guidelines/kdigo/ADA-2026-11.11a-SGLT2i-eGFR-under-20.md`
- ADA/KDIGO synthesis on GLP-1 therapy on dialysis: `/Users/ander/Documents/medical/guidelines/kdigo/ADA-2026-11.11b-GLP1-on-dialysis.md`
- Registry: [[local-guideline-file-registry]]

## Draft Update Focus Areas Listed by KDIGO

- New Chapter 1 addressing definitions, prevention, and risk assessment.
- Chapter 2 on glycemic monitoring.
- Chapter 4 on comprehensive pharmacotherapy.

## Published Baseline Sources To Import Next

- KDIGO 2022 Diabetes in CKD Guideline.
- KDIGO 2022 executive summary.
- ADA-KDIGO 2022 Consensus Report on Diabetes Management in CKD.
- KDIGO 2025 GLP-1 receptor agonist commentary for diabetes and CKD.

## Wiki Links

- [[../../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[../../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]
