---
title: ADA Standards of Care in Diabetes 2026 Source Map
type: source-map
created: 2026-05-19
updated: 2026-05-19
tags: [source, ada, standards-of-care, diabetes, guideline, 2026]
sources:
  - https://professional.diabetes.org/standards-of-care
  - https://diabetesjournals.org/care/issue/49/Supplement_1
evidence_level: source-map
clinical_use: clinical-reference
confidence: high
last_verified: 2026-05-19
status: active
obsidian_type: source
---

# ADA Standards of Care in Diabetes 2026 Source Map

## Status

The American Diabetes Association lists the 2026 Standards of Care as current clinical practice recommendations, published in *Diabetes Care* and updated annually or more frequently online when needed.

## Official Entry Points

- ADA professional page: https://professional.diabetes.org/standards-of-care
- Diabetes Care supplement issue: https://diabetesjournals.org/care/issue/49/Supplement_1
- Summary of Revisions: https://diabetesjournals.org/care/article/49/Supplement_1/S6/163930/Summary-of-Revisions-Standards-of-Care-in-Diabetes

## Local Markdown Source

- Local directory: `/Users/ander/Documents/medical/guidelines/ada`
- Registry: [[local-guideline-file-registry]]

## Sections Listed by ADA

1. `dc26s001.md` - Improving Care and Promoting Health in Populations
2. `dc26s002.md` - Diagnosis and Classification of Diabetes
3. `dc26s003.md` - Prevention or Delay of Diabetes and Associated Comorbidities
4. `dc26s004.md` - Comprehensive Medical Evaluation and Assessment of Comorbidities
5. `dc26s005.md` - Facilitating Positive Health Behaviors and Well-being to Improve Health Outcomes
6. `dc26s006.md` - Glycemic Goals, Hypoglycemia, and Hyperglycemic Crises
7. `dc26s007.md` - Diabetes Technology
8. `dc26s008.md` - Obesity and Weight Management for the Prevention and Treatment of Diabetes
9. `dc26s009.md` - Pharmacologic Approaches to Glycemic Treatment
10. `dc26s010.md` - Cardiovascular Disease and Risk Management
11. `dc26s011.md` - Chronic Kidney Disease and Risk Management
12. `dc26s012.md` - Retinopathy, Neuropathy, and Foot Care
13. `dc26s013.md` - Older Adults
14. `dc26s014.md` - Children and Adolescents
15. `dc26s015.md` - Management of Diabetes in Pregnancy
16. `dc26s016.md` - Diabetes Care in the Hospital
17. `dc26s017.md` - Diabetes Advocacy

## Wiki Links

- [[../../guidelines/ada-standards-of-care-2026]]
- [[../../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]
