---
title: Hermes-Only Research Operating System
created: 2026-05-20
updated: 2026-05-20
type: workflow
tags: [hermes, llm-wiki, research-os, medical-wiki, operations]
sources:
  - HERMES.md
  - SCHEMA.md
  - _meta/retrieval-policy.md
  - _meta/topic-map.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-20
status: active
obsidian_type: registry
aliases:
  - Hermes research OS
  - wiki-centered autonomous research agent
  - Hermes-only operating loop
entities:
  - Hermes Agent
  - LLM Wiki
  - ADA
  - KDIGO
owner_agent: hermes
write_policy: hermes-maintained
---

# Hermes-Only Research Operating System

This wiki treats Hermes as a wiki-centered autonomous research agent.

Hermes is not only a chatbot. It is responsible for a closed loop:

```text
question/source -> wiki retrieval -> raw verification -> answer
-> query/writeback or failure analysis -> link -> lint -> report
```

## Six Roles

Hermes should switch roles by task:

| Role | Responsibility |
|---|---|
| Wiki Maintainer | Read schema/index/log, update pages, links, index, and log. |
| Ingest Agent | Preserve raw sources, compute source metadata, extract claims/entities/concepts. |
| Link Agent | Find aliases, duplicate concepts, orphan pages, and missing topic-map routes. |
| Verifier Agent | Check evidence level, confidence, stale claims, contradictions, and source support. |
| Query Agent | Answer from wiki first, then raw fallback, then write back reusable results. |
| Distiller Agent | Convert wiki knowledge into teaching, patient education, slides, or query pages. |

## Tool Choice

- Short reasoning task: Hermes skill.
- Repeated wiki operation: custom skill.
- Mechanical scan: code/script.
- Long or scheduled operation: Hermes cron or Codex automation.
- Multi-source research batch: Hermes Kanban or carefully scoped subagents.
- External source access: MCP or web, then ingest into `raw/` and compiled pages.

## Custom Skills

Installed local Hermes skills:

- `wiki-query-medical`
- `wiki-ingest-medical`
- `wiki-lint-medical`
- `wiki-distill-medical`

These skills point Hermes back to [[../HERMES]], [[../SCHEMA]],
[[_meta/retrieval-policy]], [[_meta/topic-map]], and [[_meta/aliases]].

## Maintenance Schedule

- Daily brief: recent changes, query candidates, research requests, low-confidence or open items.
- Daily self-improvement: run `scripts/wiki_self_improvement_audit.py`, then process only 1-2 open research requests with raw-source verification before canonical clinical edits.
- Weekly lint: frontmatter, weak links, broken links, stale pages, duplicate candidates.
- Monthly refresh: aliases, topic map, index structure, stale guideline status, and pages to merge/split.

## Retrieval Failure Learning Loop

If wiki and raw/RAG fallback do not support an answer:

1. Save a failure record in `inbox/retrieval-failures/`.
2. Classify the failure: missing alias, missing topic route, missing required facet, retrieval noise, verification gap, or true source gap.
3. Compile repeated failures into [[../reports/retrieval-failure-analysis]].
4. Apply only low-risk fixes automatically: aliases, entities, topic-map routes, MOC links, smoke-test cases, or research-request drafts.
5. Require human/source verification before changing clinical claims, thresholds, evidence grades, or draft/final status.

## Related Pages

- [[../HERMES]]
- [[../SCHEMA]]
- [[../_meta/retrieval-policy]]
- [[../_meta/topic-map]]
- [[../_meta/aliases]]
- [[hermes-routine-maintenance]]
