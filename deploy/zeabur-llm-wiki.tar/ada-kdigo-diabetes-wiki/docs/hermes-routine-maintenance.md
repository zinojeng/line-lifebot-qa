---
title: Hermes Routine Maintenance for ADA-KDIGO Wiki
created: 2026-05-19
updated: 2026-05-19
type: workflow
tags: [hermes, llm-wiki, maintenance, duplicate-detection, knowdb]
sources:
  - docs/hermes-agent-wiki-workflow.md
  - docs/llm-wiki-retrieval-agent-prompt.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-19
status: active
---

# Hermes Routine Maintenance for ADA-KDIGO Wiki

Hermes is best used as a routine maintainer for repeated low-risk wiki work:
duplicate detection, metadata checks, broken link checks, thin-page detection,
and recurring query capture.

It should not silently change clinical thresholds, evidence grades, or exact
recommendation wording. For those items, Hermes should use [[ada-standards-of-care-2026]],
[[kdigo-diabetes-management-in-ckd-2026]], and the local KnowDB raw guideline
map before suggesting updates.

## Commands

From `/Users/ander/Documents/hermes-agent`:

```bash
scripts/hermes-ada-kdigo-routine.sh audit
```

Use this for read-first routine QA. It should report duplicate candidates,
thin pages, missing metadata, weak links, and claims needing verification.

```bash
scripts/hermes-ada-kdigo-routine.sh update
```

Use this only after reviewing an audit. It allows safe edits such as adding
related links, obvious metadata, redirect notes, and status markers.

## Routine Checklist

- Read `SCHEMA.md`, `index.md`, and recent `log.md`.
- Check duplicate concepts across `concepts/`, `guidelines/`, `drugs/`,
  `comparisons/`, and `queries/`.
- Flag pages with missing frontmatter fields.
- Flag pages with few or no wikilinks.
- Check exact medical claims against raw guideline markdown or KnowDB.
- Update `log.md` after any edit.

## Related Pages

- [[llm-wiki-retrieval-agent-prompt]]
- [[hermes-agent-wiki-workflow]]
- [[ada-2026-vs-kdigo-2026-diabetes-ckd]]
- [[sglt2i-egfr-under-20-not-on-dialysis]]
- [[glp1-based-therapy-on-dialysis]]
