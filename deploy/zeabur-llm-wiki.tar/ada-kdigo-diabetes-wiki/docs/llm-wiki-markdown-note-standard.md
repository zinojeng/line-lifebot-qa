---
title: LLM Wiki Markdown Note Standard
summary: Defines the minimum Markdown structure, frontmatter, links, and provenance needed before a note becomes a maintained page in this ADA-KDIGO Diabetes LLM Wiki.
type: workflow
created: 2026-05-23
updated: 2026-05-23
tags: [llm-wiki, markdown, obsidian, schema, retrieval, quality]
sources:
  - SCHEMA.md
  - HERMES.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: registry
aliases:
  - markdown note standard
  - llm wiki note schema
  - md note quality standard
  - LLM Wiki 單篇模板
  - Markdown 筆記標準
entities:
  - Hermes Agent
  - Obsidian
  - LINE QA
related:
  - SCHEMA
  - HERMES
  - _meta/retrieval-policy
  - docs/hermes-md-normalization-schedule
owner_agent: hermes
write_policy: hermes-maintained
---

# LLM Wiki Markdown Note Standard

This page defines the entry standard for maintained Markdown pages in this wiki.
The goal is to make every page easy for Hermes, Obsidian, local search, and LINE
QA to find, judge, cite, and improve.

## Minimum Standard

Every maintained `.md` page should have:

- A stable, specific title.
- A 2-5 sentence `summary` in frontmatter.
- Stable `type`, `tags`, `aliases`, and `entities`.
- Clear sections instead of one long block of text.
- At least 2 meaningful `[[wikilinks]]`, unless it is a source map or inbox README.
- `sources`, `confidence`, and `last_verified` fields when the page contains medical or operational claims.

This is the 80-point standard. A page that lacks these items can still exist as
a draft, but it should not be treated as a high-confidence retrieval target.

## Preferred Frontmatter

Use the required fields in [[../SCHEMA]] plus these recommended fields when
practical:

```yaml
summary:
related:
review_cycle_days:
claim_ids:
answer_role:
contested:
```

For medical pages, `summary` should state the page scope and limits. It should
not make a clinical recommendation stronger than the cited source allows.

## Body Structure

Use a structure like this unless the page type has a stricter template:

```markdown
# Overview

## Why This Page Exists

## Core Points

## Evidence And Sources

## Retrieval Hooks

## Related Pages

## Open Questions
```

`Retrieval Hooks` can include common LINE wording, abbreviations, and phrases
that should route to this page. Put durable aliases in [[../_meta/aliases]] when
they should affect the whole wiki.

## Page-Type Expectations

Concept pages should define one reusable idea, list when it should be cited,
name common misunderstandings, and link to evidence cards or claims when
recommendation grades matter.

Source pages should preserve source identity, local file paths, source date,
version status, checksum if available, and which maintained pages depend on it.

Project or workflow pages should define goal, inputs, outputs, owner agent,
completion criteria, and review gates.

Evidence cards and claim registries should stay narrow. They are retrieval tools
for exact recommendation numbers, grades, population, action, thresholds, and
source provenance.

## Anti-Patterns

Avoid these patterns:

- No title or vague title.
- No summary.
- Tags that use multiple spellings for the same idea.
- One page mixing many unrelated topics.
- No internal links.
- Medical statements without source provenance.
- Duplicate concept pages with different names.
- Large pasted source text in maintained pages instead of `raw/` or source maps.

## Related Pages

- [[../SCHEMA]]
- [[../HERMES]]
- [[../_meta/retrieval-policy]]
- [[../docs/hermes-md-normalization-schedule]]
- [[../docs/templates/concept-page-template]]
- [[../docs/templates/source-page-template]]
- [[../docs/templates/project-page-template]]
- [[../docs/templates/medical-evidence-card-template]]
