---
title: Hermes Agent Wiki Workflow
type: teaching
created: 2026-05-19
updated: 2026-05-21
tags: [output, hermes, llm-wiki, obsidian-mcp, workflow, medical-query]
sources:
  - /Users/ander/.hermes/skills/research/llm-wiki/SKILL.md
  - /Users/ander/.hermes/skills/note-taking/obsidian/SKILL.md
  - /Users/ander/.hermes/skills/autonomous-ai-agents/hermes-agent/SKILL.md
  - medical-query-knowledge-layer-strategy.md
  - llm-wiki-retrieval-agent-prompt.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-21
status: active
obsidian_type: output
---

# Hermes Agent Wiki Workflow

## Goal

Use Hermes Agent as the maintainer and query agent for this ADA-KDIGO Diabetes Wiki.

Hermes should do four jobs:

1. Query the wiki before raw sources.
2. Ingest new guideline or paper Markdown into compiled wiki artifacts.
3. Maintain backlinks, index, and log.
4. Run periodic lint/health checks.

## Environment Variables

Recommended Hermes environment variables:

```bash
export WIKI_PATH="/Users/ander/Documents/hermes-agent/wiki/ada-kdigo-diabetes-wiki"
export OBSIDIAN_VAULT_PATH="/Users/ander/Library/CloudStorage/GoogleDrive-clawbot4ander@gmail.com/我的雲端硬碟/Obsidian Vault/Google Drive Obsidian"
```

Because the currently open Obsidian vault exposes this wiki through a symlink, Hermes/Obsidian paths can refer to:

```text
ADA-KDIGO-Diabetes-Wiki/index.md
```

## One-Shot Query Pattern

Use this for a single medical question:

```bash
cd /Users/ander/Documents/hermes-agent
WIKI_PATH="/Users/ander/Documents/hermes-agent/wiki/ada-kdigo-diabetes-wiki" \
hermes -s llm-wiki,obsidian -z '
You are maintaining my ADA-KDIGO Diabetes LLM Wiki.
First read SCHEMA.md, index.md, and the recent log.
Then answer this question using LLM Wiki first, raw sources second:

QUESTION: ADA 2026 對 T2DM 合併 CKD 的 SGLT2i 和 GLP-1RA 建議有什麼變化？

Return:
1. 簡短回答
2. Wiki 依據
3. 臨床解釋
4. 不確定或需要查證的地方
5. 是否建議更新 Wiki
'
```

## Interactive Hermes Session

Use this when doing several related wiki operations:

```bash
cd /Users/ander/Documents/hermes-agent
WIKI_PATH="/Users/ander/Documents/hermes-agent/wiki/ada-kdigo-diabetes-wiki" \
hermes -s llm-wiki,obsidian
```

Then paste:

```text
你是我的 ADA-KDIGO Diabetes Wiki maintainer。
請先讀 SCHEMA.md、index.md、log.md 最近 30 行。
接著用 LLM Wiki first, RAG second 的流程回答問題。
若答案有長期價值，請建議要更新哪個 wiki page。
```

## Ingest New Source Pattern

Use this when adding a paper, guideline section, or local report:

```text
請依照 LLM Wiki ingest 流程處理這份資料：

SOURCE_PATH: /path/to/source.md
TOPIC: [topic]

Rules:
1. 原始資料視為 raw/source of truth，不可覆寫。
2. 先讀 SCHEMA.md、index.md、log.md。
3. 查找是否已有相關概念、drug card、comparison page。
4. 優先更新既有頁面，不要重複建立。
5. 若需要新 artifact，建立在 concepts/、drugs/、comparisons/、queries/ 或 teaching/。
6. 標記 evidence_level、clinical_use、confidence、last_verified。
7. 更新 index.md 與 log.md。
8. 最後列出新增、修改、仍不確定之處。
```

## Suggested Hermes Tasks For This Wiki

### 1. ADA 2026 Section Cards

Create section-specific artifacts from local ADA files:

```text
/Users/ander/Documents/medical/guidelines/ada/dc26s006.md
/Users/ander/Documents/medical/guidelines/ada/dc26s007.md
/Users/ander/Documents/medical/guidelines/ada/dc26s009.md
/Users/ander/Documents/medical/guidelines/ada/dc26s010.md
/Users/ander/Documents/medical/guidelines/ada/dc26s011.md
```

Target pages:

```text
guidelines/ada-2026-section-6-glycemic-goals.md
guidelines/ada-2026-section-7-technology.md
guidelines/ada-2026-section-9-pharmacologic-treatment.md
guidelines/ada-2026-section-10-cvd-risk.md
guidelines/ada-2026-section-11-ckd-risk.md
```

### 2. ADA 2025 vs 2026 Section Crosswalks

Use `/Users/ander/openclaw-research/ada20252026` to create:

```text
comparisons/ada-2025-vs-2026-section-7-technology.md
comparisons/ada-2025-vs-2026-section-9-pharmacologic-treatment.md
comparisons/ada-2025-vs-2026-section-10-cvd.md
comparisons/ada-2025-vs-2026-section-11-ckd.md
```

### 3. Drug-Class Artifact Expansion

Create or expand:

```text
drugs/sglt2-inhibitors.md
drugs/glp1-receptor-agonists.md
drugs/finerenone.md
drugs/tirzepatide.md
drugs/metformin-in-ckd.md
```

### 4. Periodic Wiki Health Check

Ask Hermes weekly:

```text
請 lint ADA-KDIGO Diabetes Wiki：
1. 找出沒有 frontmatter 的頁面。
2. 找出缺少至少 2 個 wikilinks 的 maintained pages。
3. 找出 confidence: low / status: needs-source / draft pages。
4. 找出 index.md 未列出的頁面。
5. 找出可能重複概念頁。
6. 輸出修正建議，不要自動刪除任何檔案。
```

## Codex + Claude Review Gate

Use this when Codex is making wiki or app changes and the local Claude CLI on
the Mac mini should act as an independent second-pass reviewer.

```text
在 /Users/ander/Documents/hermes-agent/wiki/ada-kdigo-diabetes-wiki 工作。
每完成一個小步驟後，先跑 wiki_ops 檢查，再跑 Claude review worktree diff。
只採納 high-confidence findings；修正後再重跑檢查，最後更新 log.md。
```

Commands:

```bash
cd /Users/ander/Documents/hermes-agent/wiki/ada-kdigo-diabetes-wiki
python3 /Users/ander/Documents/hermes-agent/line-lifebot-qa/scripts/wiki_ops.py compile --wiki .
/Users/ander/Documents/Projects/OpenAI/.agents/skills/claude-review/scripts/claude-review.sh worktree
```

Use `branch main` for a branch-level review when working from a feature branch,
`staged` for selected staged changes, and `head` after a commit.

## Cron Idea

After the workflow is stable, create a Hermes cron job for weekly maintenance:

```bash
hermes cron create '0 8 * * 1'
```

Prompt:

```text
Use the llm-wiki skill. Run a weekly health check on WIKI_PATH=/Users/ander/Documents/hermes-agent/wiki/ada-kdigo-diabetes-wiki. Check index coverage, frontmatter, duplicate concepts, draft/low-confidence pages, and recent log consistency. Do not delete files. Append a concise report to log.md and create a query page only if findings are substantial.
```

## Best Use Pattern

Hermes is best for longer maintenance loops:

```text
source arrives → ingest → create/update artifacts → link pages → update index/log → lint
```

Codex is best for local engineering and precise file edits.

Obsidian MCP is best for fast note search/read/write inside the active vault.

Use all three together:

```text
Hermes = autonomous wiki maintainer
Codex = engineering/editorial control
Obsidian = human-readable graph and MCP note layer
```
