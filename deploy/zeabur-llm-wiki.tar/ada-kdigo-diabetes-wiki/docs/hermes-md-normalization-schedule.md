---
title: Hermes Markdown Normalization Schedule
summary: A staged schedule for Hermes to normalize every Markdown file in this wiki using the LLM Wiki note standard, small batches, mechanical checks, and Claude review gates.
type: workflow
created: 2026-05-23
updated: 2026-05-23
tags: [llm-wiki, hermes, markdown, maintenance, schedule, claude-review]
sources:
  - SCHEMA.md
  - HERMES.md
  - docs/llm-wiki-markdown-note-standard.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: registry
aliases:
  - md normalization schedule
  - all markdown cleanup schedule
  - Hermes Markdown cleanup
  - 全庫 Markdown 整理排程
entities:
  - Hermes Agent
  - Claude Review
  - Obsidian
related:
  - docs/llm-wiki-markdown-note-standard
  - SCHEMA
  - HERMES
  - reports/markdown-normalization-audit
owner_agent: hermes
write_policy: hermes-maintained
---

# Hermes Markdown Normalization Schedule

This schedule lets Hermes improve all Markdown pages without creating a large,
risky rewrite. Current scope is about 101 `.md` files.

## Batch Rule

Each batch must be small:

- Routine batch: 3-5 nonclinical pages.
- Clinical batch: 1-2 pages when recommendation numbers, grades, thresholds, or safety language may change.
- Never update more than 10 maintained pages without explicit user approval.

Every batch must pass the Claude review gate in [[../HERMES]] before being
reported complete.

## Per-File Checklist

For each `.md` file:

1. Classify page type: concept, source-map, evidence-card, claim, MOC, workflow, report, or inbox note.
2. Add or repair frontmatter according to [[llm-wiki-markdown-note-standard]].
3. Add a concise `summary`.
4. Normalize `tags`, `aliases`, and `entities`.
5. Split long text into clear sections.
6. Add 2-5 meaningful `[[wikilinks]]` when appropriate.
7. Preserve source provenance; do not strengthen medical claims without checking source text.
8. Update [[../index]], [[../_meta/topic-map]], or [[../_meta/aliases]] only if discoverability changes.
9. Append [[../log]].
10. Run mechanical checks and Claude review.

## Phase 0 - Baseline

Goal: confirm the wiki can be scanned before edits.

Commands:

```bash
cd /Users/ander/Documents/hermes-agent/line-lifebot-qa
python3 scripts/wiki_ops.py md-audit
python3 scripts/wiki_ops.py compile

cd /Users/ander/Documents/hermes-agent/wiki/ada-kdigo-diabetes-wiki
/Users/ander/Documents/Projects/OpenAI/.agents/skills/claude-review/scripts/claude-review.sh worktree
```

This command block depends on the sibling operations repo
`/Users/ander/Documents/hermes-agent/line-lifebot-qa`. If Hermes is running in a
different checkout, first locate or install the operations scripts instead of
rewriting wiki pages manually.

Exit criteria:

- Registries compile.
- Review findings are either fixed or explicitly deferred.

## Phase 1 - Operating And Navigation Pages

Scope:

- `SCHEMA.md`
- `HERMES.md`
- `index.md`
- `_meta/*.md`
- `mocs/*.md`
- `docs/*.md`

Purpose:

- Make the wiki's map, rules, aliases, and retrieval policies consistent before clinical pages are mass-normalized.

## Phase 2 - Evidence Infrastructure

Scope:

- `evidence-cards/*.md`
- `claims/*.md`
- `evidence-ledger/*.md`
- `evals/*.md`

Purpose:

- Ensure recommendation-grade answers use exact source-backed cards and stable claim IDs.

Special rule:

- Do not change a clinical grade, threshold, or recommendation ID unless the raw ADA/KDIGO source has been checked.

## Phase 3 - Core Clinical Concepts

Scope:

- `concepts/*.md`
- `drugs/*.md`
- `comparisons/*.md`
- `guidelines/*.md`
- `teaching/*.md`
- `patient-education/*.md`
- `queries/*.md`

Purpose:

- Improve LINE QA retrieval by making every reusable clinical concept searchable by title, aliases, entities, wikilinks, and source provenance.

## Phase 4 - Source Maps And Inbox

Scope:

- `raw/**/*.md`
- `inbox/**/*.md`
- `reports/*.md`

Purpose:

- Keep source maps auditable and ensure inbox/report files do not masquerade as high-confidence clinical pages.

Special rule:

- Do not rewrite immutable raw source content. Source maps may be structured; original source text should remain unchanged.

## Daily Hermes Routine

Daily target:

- Normalize 1 clinical file or 3 workflow/meta files.
- Process at most 1-2 research requests.
- Generate a short report with pages read, updated, deferred, and findings.

Commands:

```bash
cd /Users/ander/Documents/hermes-agent/line-lifebot-qa
python3 scripts/wiki_ops.py md-audit
python3 scripts/wiki_ops.py md-normalize --max-files 3
python3 scripts/wiki_ops.py compile
```

Suggested prompt:

```text
Use the ADA-KDIGO Diabetes LLM Wiki. Normalize the next small batch of Markdown
files according to docs/llm-wiki-markdown-note-standard.md and
docs/hermes-md-normalization-schedule.md. Do not modify raw source text. For
clinical claims, do not change thresholds, recommendation grades, or safety
language unless raw source text supports it. Run mechanical checks and Claude
review after the batch. Apply only high-confidence correctness, security,
data-loss, broken-reference, or regression findings.
```

## Weekly Review

Once per week:

- Rebuild registries.
- Review `_meta/INDEX.json`, `_meta/page-registry.json`, and `_meta/claim-registry.json`.
- Run synthetic QA/regression smoke tests for recently normalized topics.
- Create or update a report under `reports/`.

## Done Definition

The all-file normalization project is done when:

- Every maintained page has valid frontmatter.
- Every maintained page has a useful summary.
- Clinical pages have source provenance, confidence, and last-verified fields.
- Core pages have aliases/entities for common LINE wording.
- Broken wikilinks are resolved or documented.
- Obsidian graph has useful MOC routes instead of many orphan pages.
- Claude review has no unapplied high-confidence findings for the final batch.

## Related Pages

- [[llm-wiki-markdown-note-standard]]
- [[../SCHEMA]]
- [[../HERMES]]
- [[../_meta/retrieval-policy]]
- [[../_meta/topic-map]]
- [[../_meta/aliases]]
