---
title: LLM Wiki Self-Improvement Loop
created: 2026-05-20
updated: 2026-05-21
type: workflow
tags: [llm-wiki, self-improvement, lint, search, synthetic-data, hermes]
sources:
  - https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f
  - https://abmedia.io/karpathy-llm-knowledge-base-personal-wiki-obsidian-method-2026
  - reports/wiki-self-improvement-audit.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-21
status: active
obsidian_type: registry
aliases:
  - self improving llm wiki
  - wiki lint loop
  - autonomous wiki maintenance
  - synthetic QA loop
entities:
  - Hermes Agent
  - LLM Wiki
  - Obsidian
  - LINE QA
owner_agent: hermes
write_policy: hermes-maintained
summary: "LLM Wiki Self-Improvement Loop Goal: make the ADA-KDIGO LLM Wiki improve before a LINE user asks a failing question. Operating Model Use four loops: 1. **Mechanical lint**: code checks frontmatter, links, stale pages, th..."
related: []
---

# LLM Wiki Self-Improvement Loop

Goal: make the ADA-KDIGO LLM Wiki improve before a LINE user asks a failing
question.

## Operating Model

Use four loops:

1. **Mechanical lint**: code checks frontmatter, links, stale pages, thin pages,
   duplicate candidates, and open inbox items.
2. **Semantic lint**: Hermes reviews likely contradictions, missing source
   coverage, under-routed concepts, and pages that need splitting or merging.
3. **Search/tool loop**: Hermes uses `scripts/wiki_search.py` as a local
   wiki-search engine before reading many files.
4. **Synthetic QA loop**: generate representative questions from each page, run
   retrieval smoke tests, and promote repeated failures into aliases, topic-map
   routes, or research requests.

## Commands

From `/Users/ander/Documents/hermes-agent/line-lifebot-qa`:

```bash
python3 scripts/wiki_search.py "SGLT2i eGFR 20 KDIGO 4.3.1" --limit 8
python3 scripts/wiki_ops.py compile
python3 scripts/wiki_ops.py daily --request-limit 2
python3 scripts/wiki_fts_search.py "哪些證據等級較低" --rebuild
python3 scripts/wiki_self_improvement_audit.py --write-requests --request-limit 4
python3 scripts/generate_synthetic_qa.py
python3 scripts/answer_quality_regression_tests.py --base-url https://linebotqa.zeabur.app
python3 scripts/source_freshness_watch.py --no-network
python3 scripts/hermes_daily_wiki_self_improvement.py --request-limit 2
python3 scripts/weekly_wiki_health_report.py
python3 scripts/retrieval_smoke_tests.py --base-url https://linebotqa.zeabur.app
```

## Review Gate

After each implementation step, run the Claude review wrapper before reporting
the step as complete:

```bash
/Users/ander/Documents/Projects/OpenAI/.agents/skills/claude-review/scripts/claude-review.sh worktree
```

The wrapper reviews Git diffs, so it must run inside the canonical ADA-KDIGO
guideline wiki repo or the related app repo. The canonical local wiki now has a
Git baseline, so the default `worktree` mode is the normal per-step gate.

Use these modes when needed:

```bash
/Users/ander/Documents/Projects/OpenAI/.agents/skills/claude-review/scripts/claude-review.sh worktree
/Users/ander/Documents/Projects/OpenAI/.agents/skills/claude-review/scripts/claude-review.sh staged
/Users/ander/Documents/Projects/OpenAI/.agents/skills/claude-review/scripts/claude-review.sh branch main  # from a feature branch
/Users/ander/Documents/Projects/OpenAI/.agents/skills/claude-review/scripts/claude-review.sh head
```

Apply only high-confidence findings that are grounded in changed files, raw
ADA/KDIGO sources, or failing tests. Then re-run the relevant `wiki_ops.py`
checks. If Claude is unavailable, use the local fallback gate:

```bash
cd /Users/ander/Documents/hermes-agent/line-lifebot-qa
python3 scripts/wiki_ops.py compile
python3 scripts/wiki_ops.py regression
python3 scripts/retrieval_smoke_tests.py --base-url https://linebotqa.zeabur.app --sleep 0.01
python3 scripts/answer_quality_regression_tests.py --base-url https://linebotqa.zeabur.app --include-generated --generated-limit 6
```

## Daily Hermes Cron

Hermes daily automation should run:

```bash
hermes cron create "15 7 * * *" \
  --name "ADA-KDIGO Wiki Daily Self Improvement" \
  --deliver local \
  --workdir /Users/ander/Documents/hermes-agent/line-lifebot-qa \
  --script /Users/ander/Documents/hermes-agent/line-lifebot-qa/scripts/hermes_daily_wiki_self_improvement.py \
  --skill llm-wiki \
  --skill wiki-query-medical \
  --skill wiki-lint-medical \
  --skill wiki-ingest-medical \
  "Use the script output as today's self-improvement queue. Process only the selected 1-2 research requests. Prefer safe routing/draft/proposal edits; verify clinical thresholds, grades, medication indications, and diagnostic cutoffs against raw ADA/KDIGO Markdown before canonical edits. Update log.md after edits."
```

This job complements the 07:00 daily brief. It is intentionally limited to 1-2
requests per day so the wiki evolves steadily without large unreviewed changes.

## Autonomous Safety Levels

Safe to auto-apply:

- add aliases for repeated query terms;
- add topic-map routes to existing canonical pages;
- create `inbox/research-requests/` records;
- create smoke-test candidates;
- regenerate reports.

Require raw-source verification before canonical edits:

- exact recommendation numbers;
- evidence grades;
- medication thresholds;
- diagnosis cutoffs;
- contraindications;
- claims that alter clinical advice.

Human review preferred:

- conflicting guideline interpretation;
- local Taiwan policy or reimbursement conclusions;
- changes to patient-facing medication advice.

## Current Self-Audit Outputs

- [[../reports/wiki-self-improvement-audit]]
- [[../reports/weekly-wiki-health]]
- [[../reports/retrieval-failure-analysis]]
- [[../reports/answer-improvement-analysis]]
- [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]]
- [[../_meta/typed-relationships]]
- [[../evals/synthetic-qa-registry]]
- `_meta/INDEX.json`
- `_meta/page-registry.json`
- `_meta/claim-registry.json`
- `_meta/wiki-search.sqlite3`

## Next Research Queue

The self-audit currently creates open requests for under-built topics such as
retinopathy screening, foot care/PAD, pregnancy/GDM/CGM, and hospital steroid
hyperglycemia. Hermes should process these one at a time by reading raw ADA
Markdown first, then updating concepts, aliases, topic-map routes, and smoke
tests.
