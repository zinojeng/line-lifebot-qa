---
title: Obsidian Graph Workflow For Complex Medical Queries
type: teaching
created: 2026-05-19
updated: 2026-05-19
tags: [obsidian, graph-view, workflow, medical-query, moc]
sources:
  - https://chuhenry.medium.com/obsidian-%E4%BD%BF%E7%94%A8%E6%95%99%E5%AD%B8-%E5%9C%96%E5%83%8F%E7%AF%87-01-obsidian-graph-view-%E9%97%9C%E8%81%AF%E5%9C%96-%E6%80%8E%E9%BA%BC%E7%94%A8-b9b158bb30c4
  - ../SCHEMA.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-19
status: active
obsidian_type: output
summary: "Obsidian Graph Workflow For Complex Medical Queries Why Use Obsidian Here Complex medical questions often fail when all sources are treated as flat chunks. Obsidian helps because you can see whether a query is connected..."
aliases: []
entities: []
related: []
owner_agent: "hermes"
write_policy: "hermes-maintained"
---

# Obsidian Graph Workflow For Complex Medical Queries

## Why Use Obsidian Here

Complex medical questions often fail when all sources are treated as flat chunks. Obsidian helps because you can see whether a query is connected to raw guideline sources, comparison pages, concept pages, methodology cautions, and Taiwan implementation notes.

The useful idea from the Graph View reference is simple: graph view becomes readable only after notes are grouped and filtered. For this wiki, grouping should use stable role tags plus MOC pages.

## Role Tags

Use one primary role tag per page:

- `#moc` - Map of Content.
- `#source` - source maps, registries, or imported source notes.
- `#concept` - reusable medical concepts.
- `#relationship` - comparisons, crosswalks, and synthesis pages.
- `#output` - teaching, query, slide, or patient-education outputs.
- `#report` - generated maintenance, audit, freshness, and regression reports.

Suggested Obsidian Graph View group colors:

| Role | Search query | Suggested color |
|---|---|---|
| MOC | `tag:#moc` | Blue |
| Source | `tag:#source` | Green |
| Concept | `tag:#concept` | Yellow |
| Relationship | `tag:#relationship` | Pink |
| Output | `tag:#output` | Purple |
| Report | `tag:#report` | Gray |

## Local Graph Workflow

1. Start from [[../mocs/diabetes-guidelines-moc]] or [[../mocs/ada-2025-vs-2026-moc]].
2. Open Local Graph.
3. Set depth to 1 when checking direct source provenance.
4. Set depth to 2 when planning a teaching answer or complex clinical synthesis.
5. Filter by `tag:#source` when you need raw evidence.
6. Filter by `tag:#relationship` when you need comparisons.
7. Filter by `tag:#concept` when you need reusable explanatory pages.

## Query Pattern

For a complex question such as "ADA 2026 changed CKD drug therapy; how should Taiwan clinics teach this?":

1. Open [[../mocs/diabetes-guidelines-moc]].
2. Follow links to [[../comparisons/ada-2025-vs-2026-overview]].
3. Check [[../comparisons/ada-2025-vs-2026-methodology-concerns]].
4. Check [[../comparisons/ada-2025-vs-2026-taiwan-impact]].
5. Open relevant drug cards such as [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] and [[../drugs/glp1-based-therapy-on-dialysis]].
6. Verify exact wording through [[../raw/guidelines/local-guideline-file-registry]].
7. Save durable answers in `queries/` or `teaching/`.

## Duplicate Concept Check

Before creating a concept page:

1. Search the vault for the concept and synonyms.
2. Open local graph for nearby pages.
3. If two pages explain the same idea, merge into the stronger page and leave a short alias page only if needed.
4. Update [[../index]] and [[../log]].

## Links

- [[mcp-obsidian-setup]]
- [[../mocs/diabetes-guidelines-moc]]
- [[../mocs/ada-2025-vs-2026-moc]]
- [[../SCHEMA]]
- [[../index]]
