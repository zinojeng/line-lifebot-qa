---
title: MCP Obsidian Setup
type: teaching
created: 2026-05-19
updated: 2026-05-19
tags: [output, obsidian, mcp, local-rest-api, setup, codex]
sources:
  - https://github.com/MarkusPfundstein/mcp-obsidian
  - https://www.vista.tw/blog/mcp-second-brain-obsidian-anytype
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-19
status: active
obsidian_type: output
summary: "MCP Obsidian Setup Goal Connect this ADA-KDIGO Diabetes Wiki vault to an MCP-enabled agent through `MarkusPfundstein/mcp-obsidian`, so the agent can list, search, read, append, and patch Obsidian notes through the Obsidi..."
aliases: []
entities: []
related: []
owner_agent: "hermes"
write_policy: "hermes-maintained"
---

# MCP Obsidian Setup

## Goal

Connect this ADA-KDIGO Diabetes Wiki vault to an MCP-enabled agent through `MarkusPfundstein/mcp-obsidian`, so the agent can list, search, read, append, and patch Obsidian notes through the Obsidian Local REST API plugin.

## Current Status

- `uvx` is available at `/Users/ander/.local/bin/uvx`.
- Obsidian is installed on this Mac.
- The default Obsidian Local REST API endpoint `https://127.0.0.1:27124` is responding as of 2026-05-19.
- The API key is stored in macOS Keychain under:
  - account: `obsidian-local-rest-api`
  - service: `codex-obsidian-api-key`
- Codex config includes an `obsidian` MCP server that calls `/Users/ander/.codex/bin/mcp-obsidian-wrapper`.
- The currently open Obsidian vault exposes this wiki through a symlink:
  `/Users/ander/Library/CloudStorage/GoogleDrive-clawbot4ander@gmail.com/我的雲端硬碟/Obsidian Vault/Google Drive Obsidian/ADA-KDIGO-Diabetes-Wiki`
- REST API verified readable path:
  `ADA-KDIGO-Diabetes-Wiki/index.md`

## Required Obsidian Setup

1. Open Obsidian.
2. Open the vault folder:
   `/Users/ander/Documents/hermes-agent/wiki/ada-kdigo-diabetes-wiki`
3. Install the community plugin:
   `Local REST API`
4. Enable the plugin.
5. Copy the plugin API key.
6. Confirm the plugin host and port:
   - Host: `127.0.0.1`
   - Port: `27124`

Do not store the API key inside wiki notes.

## Codex MCP Config

Current configured pattern:

```toml
[mcp_servers.obsidian]
command = "/Users/ander/.codex/bin/mcp-obsidian-wrapper"
```

The wrapper reads the API key from macOS Keychain and then runs:

```bash
/Users/ander/.local/bin/uvx mcp-obsidian
```

Restart Codex so the MCP server is loaded into the tool list.

## Verify The REST API Before Restarting Codex

Run:

```bash
curl -k https://127.0.0.1:27124/
```

If the endpoint is protected, test with the API key:

```bash
TOKEN="$(security find-generic-password -a obsidian-local-rest-api -s codex-obsidian-api-key -w)"
curl -k \
  -H "Authorization: Bearer $TOKEN" \
  https://127.0.0.1:27124/vault/ADA-KDIGO-Diabetes-Wiki/index.md
```

## Expected MCP Tools

According to the `mcp-obsidian` README, the MCP server provides tools such as:

- `list_files_in_vault`
- `list_files_in_dir`
- `get_file_contents`
- `search`
- `patch_content`
- `append_content`
- `delete_file`

For this medical wiki, avoid `delete_file` unless explicitly requested.

## Safe Use Rules For Medical Wiki

- Use MCP to read/search source maps and maintained pages before answering complex medical questions.
- Use `patch_content` or `append_content` only after checking `SCHEMA.md`, `index.md`, and `log.md`.
- Never write identifiable patient data into the vault.
- Preserve raw guideline files and source registries.
- For clinical thresholds and recommendation wording, verify against local source files listed in [[../raw/guidelines/local-guideline-file-registry]].
- For ADA 2025 vs 2026 claims, check [[../comparisons/ada-2025-vs-2026-methodology-concerns]] before presenting strong conclusions.

## Useful Query Pattern

Ask the agent:

```text
Use Obsidian MCP. Start from mocs/diabetes-guidelines-moc.md.
Find pages linked to ADA 2026 CKD drug therapy, check source maps,
then summarize what is guideline-backed, what is draft KDIGO, and what needs verification.
```

If using the currently open vault through the symlink, refer to:

```text
ADA-KDIGO-Diabetes-Wiki/mocs/diabetes-guidelines-moc.md
```

## Links

- [[obsidian-graph-workflow]]
- [[../mocs/diabetes-guidelines-moc]]
- [[../mocs/ada-2025-vs-2026-moc]]
- [[../SCHEMA]]
