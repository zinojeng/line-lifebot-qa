---
title: Concept Page Template
summary: Copyable template for creating or normalizing reusable concept pages in the ADA-KDIGO Diabetes LLM Wiki.
type: workflow
created: 2026-05-23
updated: 2026-05-23
tags: [llm-wiki, template, concept, markdown]
sources:
  - docs/llm-wiki-markdown-note-standard.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: registry
aliases:
  - concept template
  - concept page schema
entities:
  - Hermes Agent
related:
  - docs/llm-wiki-markdown-note-standard
  - SCHEMA
  - _meta/aliases
owner_agent: hermes
write_policy: hermes-maintained
---

# Concept Page Template

Copy this structure for reusable concept pages.

```markdown
---
title:
summary:
type: concept
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: []
sources: []
evidence_level:
clinical_use:
confidence:
last_verified: YYYY-MM-DD
status: draft
obsidian_type: concept
aliases: []
entities: []
related: []
owner_agent: hermes
write_policy: hermes-maintained
---

# Overview

## Why This Page Exists

## Core Points

## Clinical Or Teaching Use

## Evidence And Sources

## Retrieval Hooks

## Common Misunderstandings

## Related Pages

- related-page-1
- related-page-2

## Open Questions
```

## Related Pages

- [[../llm-wiki-markdown-note-standard]]
- [[../../SCHEMA]]
- [[../../_meta/aliases]]
