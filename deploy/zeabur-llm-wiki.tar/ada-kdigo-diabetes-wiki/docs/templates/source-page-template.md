---
title: Source Page Template
summary: Copyable template for source maps and source-grounded import notes that preserve provenance before knowledge is synthesized into maintained wiki pages.
type: workflow
created: 2026-05-23
updated: 2026-05-23
tags: [llm-wiki, template, source-map, provenance]
sources:
  - docs/llm-wiki-markdown-note-standard.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: registry
aliases:
  - source template
  - source map template
entities:
  - Hermes Agent
related:
  - docs/llm-wiki-markdown-note-standard
  - SCHEMA
  - raw/guidelines/local-guideline-file-registry
owner_agent: hermes
write_policy: hermes-maintained
---

# Source Page Template

Copy this structure for source maps or import notes. Do not use it to rewrite
immutable raw source text.

```markdown
---
title:
summary:
type: source-map
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: []
sources: []
evidence_level: source-map
clinical_use: workflow
confidence:
last_verified: YYYY-MM-DD
status: active
obsidian_type: source
aliases: []
entities: []
related: []
owner_agent: hermes
write_policy: hermes-maintained
---

# Source Identity

## Local Files

## Source Version And Status

## Key Sections

## Pages That Depend On This Source

## Known Limits

## Related Pages

- related-page-1
- related-page-2
```

## Related Pages

- [[../llm-wiki-markdown-note-standard]]
- [[../../SCHEMA]]
- [[../../raw/guidelines/local-guideline-file-registry]]
