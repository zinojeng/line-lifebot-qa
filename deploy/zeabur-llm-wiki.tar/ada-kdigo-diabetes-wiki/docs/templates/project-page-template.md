---
title: Project Page Template
summary: Copyable template for project, workflow, and maintenance pages that coordinate Hermes work across the wiki.
type: workflow
created: 2026-05-23
updated: 2026-05-23
tags: [llm-wiki, template, project, workflow]
sources:
  - docs/llm-wiki-markdown-note-standard.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: registry
aliases:
  - project template
  - workflow template
entities:
  - Hermes Agent
related:
  - docs/llm-wiki-markdown-note-standard
  - HERMES
  - SCHEMA
owner_agent: hermes
write_policy: hermes-maintained
---

# Project Page Template

Copy this structure for workflow, maintenance, or implementation pages.

```markdown
---
title:
summary:
type: workflow
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: []
sources: []
evidence_level: local-practice
clinical_use: workflow
confidence:
last_verified: YYYY-MM-DD
status: draft
obsidian_type: registry
aliases: []
entities: []
related: []
owner_agent: hermes
write_policy: hermes-maintained
---

# Goal

## Why This Matters

## Scope

## Inputs

## Outputs

## Procedure

## Review Gate

## Done Definition

## Related Pages

- related-page-1
- related-page-2
```

## Related Pages

- [[../llm-wiki-markdown-note-standard]]
- [[../../HERMES]]
- [[../../SCHEMA]]
