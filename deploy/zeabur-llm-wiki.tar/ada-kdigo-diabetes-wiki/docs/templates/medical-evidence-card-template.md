---
title: Medical Evidence Card Template
summary: Copyable template for narrow medical evidence cards that store exact recommendation numbers, grades, thresholds, and provenance for LINE QA retrieval.
type: workflow
created: 2026-05-23
updated: 2026-05-23
tags: [llm-wiki, template, evidence-card, medical, guideline]
sources:
  - docs/llm-wiki-markdown-note-standard.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: registry
aliases:
  - evidence card template
  - recommendation grade template
entities:
  - Hermes Agent
  - LINE QA
related:
  - docs/llm-wiki-markdown-note-standard
  - SCHEMA
  - mocs/evidence-grade-router-moc
owner_agent: hermes
write_policy: hermes-maintained
---

# Medical Evidence Card Template

Copy this structure when exact recommendation numbers, grades, and thresholds
matter. Evidence cards should be narrow and source-grounded.

```markdown
---
title:
summary:
type: evidence-card
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: []
sources: []
evidence_level:
clinical_use: clinical-reference
confidence:
last_verified: YYYY-MM-DD
status: draft
obsidian_type: relationship
aliases: []
entities: []
related: []
owner_agent: hermes
write_policy: hermes-maintained
---

# Overview

## Scope

## Recommendation Cards

| Source | Recommendation ID | Population | Action | Threshold | Grade | Certainty Bucket | Notes |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |

## Lower-Certainty Or Caveat Areas

## LINE Answer Rules

## Source Verification Notes

## Related Pages

- related-page-1
- related-page-2
```

## Related Pages

- [[../llm-wiki-markdown-note-standard]]
- [[../../SCHEMA]]
- [[../../mocs/evidence-grade-router-moc]]
