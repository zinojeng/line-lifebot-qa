---
title: Medical Query Knowledge Layer Strategy
type: teaching
created: 2026-05-19
updated: 2026-05-19
tags: [output, medical-query, knowledge-layer, rag, llm-wiki, obsidian-mcp]
sources:
  - user-provided-note-on-nexus-agentic-rag-llm-wiki-2026-05-19
  - ../SCHEMA.md
  - ../docs/obsidian-graph-workflow.md
  - ../docs/mcp-obsidian-setup.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-19
status: active
obsidian_type: output
summary: "Medical Query Knowledge Layer Strategy Core Principle For repeated medical questions, do not let the agent rediscover the answer from raw guideline chunks every time. Move expensive reasoning to the ingestion and mainten..."
aliases: []
entities: []
related: []
owner_agent: "hermes"
write_policy: "hermes-maintained"
---

# Medical Query Knowledge Layer Strategy

## Core Principle

For repeated medical questions, do not let the agent rediscover the answer from raw guideline chunks every time. Move expensive reasoning to the ingestion and maintenance stage, then query a maintained knowledge layer.

Use this hierarchy:

1. Raw source Markdown and PDFs remain the source of truth.
2. Source maps and registries locate exact guideline files.
3. Compiled wiki artifacts preserve reusable knowledge.
4. Query pages and teaching pages store durable outputs.
5. Raw retrieval is used as fallback or verification, not as the first move for every query.

## Artifact Types For This Wiki

Build these artifact types before relying on free-form query-time retrieval:

| Artifact | Directory | Purpose |
|---|---|---|
| Guideline hub | `guidelines/` | Navigation, status, scope, source links |
| Recommendation card | `drugs/` or `concepts/` | One clinical recommendation or drug decision with source provenance |
| Concept page | `concepts/` | Stable reusable explanation |
| Crosswalk | `comparisons/` | ADA vs KDIGO or ADA 2025 vs 2026 comparison |
| Methodology caution | `comparisons/` | Evidence-quality warnings |
| Taiwan implementation note | `comparisons/` or `teaching/` | Local availability, reimbursement, workflow impact |
| Query answer | `queries/` | Reusable answer to a high-value question |
| Teaching output | `teaching/` | Student/resident/slide-ready material |

## Recommended Medical Query Flow

For a complex query:

1. Start from [[../mocs/diabetes-guidelines-moc]].
2. Read [[../SCHEMA]] and [[../index]] when doing a maintenance task.
3. Use Obsidian MCP search for existing concept, drug, comparison, and query pages.
4. Prefer compiled artifacts over raw chunk search.
5. Verify exact thresholds, recommendation numbers, and evidence grades from source registries.
6. Label draft material, especially KDIGO 2026, as draft.
7. If the answer is reusable, write it back to `queries/`, `teaching/`, or the relevant concept/drug page.
8. Update [[../log]].

## When To Use Raw Retrieval

Use raw guideline retrieval when:

- The wiki lacks the needed artifact.
- The question asks for exact wording, recommendation number, threshold, dose, contraindication, or evidence grade.
- There is a disagreement between artifacts.
- A page has `confidence: low`, `status: needs-source`, or draft-source caveats.
- The question is rare, open-ended, or outside the current compiled layer.

## Medical Safety Rules

- Never answer a clinical threshold from memory alone.
- Never treat a derived comparison report as stronger than the original guideline.
- Always separate published guideline, draft guideline, review, inference, and local practice.
- Preserve methodology cautions for high-impact ADA 2026 changes.
- For Taiwan implementation, distinguish clinical evidence from local drug availability and reimbursement.

## Evaluation Set For Future Improvement

Maintain a small test set of representative questions. Suggested starter questions:

1. What changed in ADA 2026 Section 11 compared with ADA 2025?
2. Can SGLT2 inhibitors be continued when eGFR falls below 20 before dialysis?
3. Can GLP-1-based therapy be used in dialysis patients?
4. What ADA 2026 technology changes affect T2D?
5. Which ADA 2026 changes are most relevant but hard to implement in Taiwan?
6. Which ADA 2026 recommendations have important methodology cautions?
7. How should medical students understand organ-centric diabetes care?

## Links

- [[../mocs/diabetes-guidelines-moc]]
- [[../mocs/ada-2025-vs-2026-moc]]
- [[../comparisons/ada-2025-vs-2026-overview]]
- [[../comparisons/ada-2025-vs-2026-methodology-concerns]]
- [[../comparisons/ada-2025-vs-2026-taiwan-impact]]
- [[../raw/guidelines/local-guideline-file-registry]]

## LLM Wiki First, RAG Second

This wiki does not replace RAG entirely. It changes the default retrieval order.

Preferred order:

```text
1. index.md + MOC pages
2. maintained wiki pages
3. local raw Markdown / source registries
4. vector RAG or full-text search
5. web / paper search
6. human confirmation for high-stakes uncertainty
```

In short:

```text
LLM Wiki = first-line knowledge layer
RAG = fallback verification layer
```

## Sufficiency Check

After reading candidate wiki pages, explicitly decide whether the wiki context is sufficient.

The wiki is sufficient when:

- the relevant page exists;
- the page has source links;
- the answer does not require exact wording beyond what the page preserves;
- the evidence status is clear;
- no linked methodology caution contradicts the answer.

The wiki is insufficient when:

- exact recommendation wording, dose, threshold, contraindication, or evidence grade is needed;
- the page is marked `draft`, `needs-source`, `low`, or `uncertain`;
- the question asks for a comparison not yet represented in `comparisons/`;
- the answer depends on a new paper or updated policy;
- Taiwan availability or reimbursement may have changed.

## Default Answer Format

For complex medical questions, use this shape:

```markdown
## 簡短回答

## Wiki 依據
- [[...]]

## 臨床解釋

## 需要查證或限制

## 是否建議更新 Wiki
```

## Router Categories

Classify questions before retrieval:

- `guideline_comparison`
- `drug_recommendation`
- `teaching_explanation`
- `patient_education`
- `literature_review`
- `clinical_decision_support`
- `taiwan_implementation`
- `methodology_review`

## Closed Loop Rule

If raw/RAG/web retrieval finds reusable knowledge, do not leave it only in the answer. Add or update a wiki artifact, then update [[../index]] and [[../log]].
