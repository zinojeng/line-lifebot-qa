---
title: GLP-1-Based Therapy On Dialysis
type: drug
created: 2026-05-19
updated: 2026-05-20
tags: [concept, glp1-receptor-agonist, diabetes, dialysis, ckd, transplant, ada-2026, kdigo-2026]
sources:
  - /Users/ander/Documents/medical/guidelines/kdigo/ADA-2026-11.11b-GLP1-on-dialysis.md
  - /Users/ander/Documents/medical/guidelines/ada/dc26s011.md
  - /Users/ander/Documents/medical/guidelines/kdigo/KDIGO-2026-Diabetes-and-CKD-Guideline-Update-Public-Review-Draft-March-2026.md
evidence_level: draft-guideline
clinical_use: clinical-reference
confidence: medium
last_verified: 2026-05-19
status: draft
obsidian_type: concept
aliases:
  - GLP-1 therapy on dialysis
  - GLP-1RA dialysis
  - GLP-1 receptor agonist dialysis
  - GLP-1-based therapy in kidney failure
  - GLP-1 on hemodialysis
  - GLP-1 for transplant listing weight loss
  - ADA 2026 recommendation 11.11b
  - GLP-1 洗腎
  - GLP-1 透析
  - GLP-1 腎衰竭
  - 洗腎病人 GLP-1
entities:
  - GLP-1 receptor agonist
  - GLP-1RA
  - GLP-1-based therapy
  - semaglutide
  - liraglutide
  - dulaglutide
  - dialysis
  - hemodialysis
  - kidney failure
  - ESKD
  - ESRD
  - transplant listing
  - obesity
  - cardiovascular risk
  - ADA 2026
  - KDIGO 2026
  - Recommendation 11.11b
owner_agent: hermes
write_policy: hermes-maintained
---

# GLP-1-Based Therapy On Dialysis

## Bottom Line

ADA 2026 and the KDIGO 2026 public-review draft both support a more permissive, evidence-aware approach to selected GLP-1-based therapy in people on dialysis, especially when weight loss may improve transplant listing eligibility and when cardiovascular risk reduction is a priority.

The evidence base is still limited for dialysis-specific randomized trial data, so this page should be used as a source-grounded teaching and clinical-reference card, not as a standalone protocol.

## Clinical Use

- Prefer agents that are not dependent on kidney clearance.
- Avoid kidney-cleared GLP-1 agents in dialysis when source guidance says not to use them.
- Consider transplant-listing goals, obesity, cardiovascular risk, frailty, sarcopenia risk, gastrointestinal tolerability, retinopathy risk, and shared decision-making.
- Coordinate with nephrology, endocrinology, transplant clinic, nutrition, and dialysis teams when used as bridge therapy.

## Teaching Pearl

The key teaching sentence is: "Dialysis is no longer an automatic stop sign for every GLP-1-based therapy, but agent selection and evidence limitations matter."

## Links

- [[../guidelines/ada-standards-of-care-2026]]
- [[../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[../concepts/organ-centric-diabetes-care]]
- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]

## Source Notes

- Primary local synthesis: `/Users/ander/Documents/medical/guidelines/kdigo/ADA-2026-11.11b-GLP1-on-dialysis.md`
- ADA source chapter: `/Users/ander/Documents/medical/guidelines/ada/dc26s011.md`
- KDIGO source draft: `/Users/ander/Documents/medical/guidelines/kdigo/KDIGO-2026-Diabetes-and-CKD-Guideline-Update-Public-Review-Draft-March-2026.md`
