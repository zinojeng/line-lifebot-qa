---
title: SGLT2i Continuation When eGFR Falls Below 20 Before Dialysis
type: drug
created: 2026-05-19
updated: 2026-05-20
tags: [concept, sglt2-inhibitor, diabetes, ckd, egfr-under-20, ada-2026, kdigo-2026]
sources:
  - /Users/ander/Documents/medical/guidelines/kdigo/ADA-2026-11.11a-SGLT2i-eGFR-under-20.md
  - /Users/ander/Documents/medical/guidelines/ada/dc26s011.md
  - /Users/ander/Documents/medical/guidelines/kdigo/KDIGO-2026-Diabetes-and-CKD-Guideline-Update-Public-Review-Draft-March-2026.md
evidence_level: draft-guideline
clinical_use: clinical-reference
confidence: medium
last_verified: 2026-05-19
status: draft
obsidian_type: concept
aliases:
  - SGLT2i eGFR under 20
  - SGLT2 inhibitor eGFR below 20
  - continue SGLT2i below eGFR 20
  - SGLT2i before dialysis
  - SGLT2i not on dialysis
  - SGLT2i continuation in advanced CKD
  - ADA 2026 recommendation 11.11a
  - 排糖藥 eGFR 小於 20
  - SGLT2 抑制劑 腎功能 20 以下
  - 洗腎前 SGLT2i
entities:
  - SGLT2 inhibitor
  - SGLT2i
  - eGFR
  - eGFR <20
  - CKD
  - diabetic kidney disease
  - DKD
  - albuminuria
  - UACR
  - dialysis
  - kidney replacement therapy
  - KRT
  - ADA 2026
  - KDIGO 2026
  - Recommendation 11.11a
owner_agent: hermes
write_policy: hermes-maintained
---

# SGLT2i Continuation When eGFR Falls Below 20 Before Dialysis

## Bottom Line

For a patient with T2D and CKD already taking an SGLT2 inhibitor, ADA 2026 and the KDIGO 2026 public-review draft align on a practical point: initiation generally requires eGFR at or above 20, but continuation may be reasonable after eGFR falls below 20 if the patient is tolerating therapy and has not started kidney replacement therapy.

Because KDIGO 2026 is still a public-review draft, treat KDIGO-specific statements here as draft until final publication.

## Clinical Use

- Do not confuse initiation threshold with continuation logic.
- Reassess volume status, acute illness, prolonged fasting, surgery, ketosis risk, genital infection risk, and tolerability.
- Stop or hold therapy when clinically indicated, including kidney replacement therapy initiation or significant intolerance.
- Use the local source file for exact ADA recommendation numbers, evidence grades, and KDIGO practice point wording.

## Teaching Pearl

The key teaching sentence is: "Do not stop an SGLT2 inhibitor only because eGFR crossed below 20 if the patient is stable, tolerating treatment, and not yet on dialysis; check the source wording and clinical context."

## Links

- [[../guidelines/ada-standards-of-care-2026]]
- [[../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[../concepts/diabetes-ckd-risk-stratification]]
- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]

## Source Notes

- Primary local synthesis: `/Users/ander/Documents/medical/guidelines/kdigo/ADA-2026-11.11a-SGLT2i-eGFR-under-20.md`
- ADA source chapter: `/Users/ander/Documents/medical/guidelines/ada/dc26s011.md`
- KDIGO source draft: `/Users/ander/Documents/medical/guidelines/kdigo/KDIGO-2026-Diabetes-and-CKD-Guideline-Update-Public-Review-Draft-March-2026.md`
