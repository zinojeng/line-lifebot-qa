---
title: ADA 2026 vs KDIGO 2026 Diabetes CKD Crosswalk
type: comparison
created: 2026-05-19
updated: 2026-05-20
tags: [relationship, ada, kdigo, diabetes, ckd, comparison, 2026]
sources:
  - ../guidelines/ada-standards-of-care-2026.md
  - ../guidelines/kdigo-diabetes-management-in-ckd-2026.md
evidence_level: draft-guideline
clinical_use: teaching
confidence: medium
last_verified: 2026-05-19
status: draft
obsidian_type: relationship
aliases:
  - ADA KDIGO diabetes CKD crosswalk
  - ADA 2026 KDIGO 2026 CKD comparison
  - ADA vs KDIGO diabetes kidney disease
  - ADA KDIGO SGLT2i GLP-1 CKD comparison
  - diabetes CKD guideline comparison
  - ADA KDIGO 腎病變比較
  - 糖尿病 CKD 指引比較
  - metformin finerenone CKD comparison
  - A1C reliability CKD guideline comparison
  - hypoglycemia advanced CKD
entities:
  - ADA 2026
  - KDIGO 2026
  - CKD
  - diabetic kidney disease
  - DKD
  - eGFR
  - UACR
  - albuminuria
  - SGLT2 inhibitor
  - GLP-1 receptor agonist
  - finerenone
  - metformin
  - A1C reliability
  - hypoglycemia
  - glycemic monitoring
  - dialysis
  - KRT
  - glycemic monitoring
owner_agent: hermes
write_policy: hermes-maintained
summary: "Source-aware comparison page for ADA 2026 vs KDIGO 2026 Diabetes CKD Crosswalk; use it for ADA/KDIGO diabetes wiki retrieval, then verify exact clinical claims against 2 listed source(s) before changing recommendations."
related: 
  - "concepts/diabetes-ckd-risk-stratification"
  - "drugs/sglt2i-egfr-under-20-not-on-dialysis"
  - "drugs/glp1-based-therapy-on-dialysis"
  - "guidelines/ada-standards-of-care-2026"
  - "guidelines/kdigo-diabetes-management-in-ckd-2026"
  - "concepts/organ-centric-diabetes-care"
  - evidence-ledger/ckd-cardiorenal-ledger
---

# ADA 2026 vs KDIGO 2026 Diabetes CKD Crosswalk

## Scope

This comparison links ADA 2026 with the KDIGO 2026 Diabetes Management in CKD public-review draft. KDIGO 2026 material remains draft until final publication.

## Quick Crosswalk

| Topic | ADA 2026 | KDIGO 2026 draft | Wiki action |
|---|---|---|---|
| Overall diabetes care | Broad annual Standards of Care across diabetes lifespan and care settings | CKD-specific diabetes guideline update | Use ADA as broad diabetes frame and KDIGO for kidney-specific depth |
| CKD risk | ADA includes a CKD and risk management section | Draft update includes definitions, prevention, and risk assessment | Build [[../concepts/diabetes-ckd-risk-stratification]] |
| Glycemic monitoring | ADA includes glycemic goals and diabetes technology sections | Draft update includes glycemic monitoring | Build CGM/A1C/CKD monitoring cards |
| Pharmacotherapy | ADA includes pharmacologic treatment and cardiorenal risk sections | Draft update includes comprehensive pharmacotherapy | Build drug-class pages and recommendation cards |
| SGLT2i at very low eGFR before dialysis | ADA 2026 local synthesis tracks continuation when eGFR falls below 20 before dialysis | KDIGO draft aligns with continuation logic after initiation until intolerance or KRT | See [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| GLP-1-based therapy on dialysis | ADA 2026 local synthesis tracks dialysis use for selected non-kidney-cleared agents | KDIGO draft frames dialysis use around weight loss and transplant listing | See [[../drugs/glp1-based-therapy-on-dialysis]] |
| Evidence status | Published guideline | Public-review draft as of 2026-05-19 | Mark KDIGO 2026 claims as draft |

## Evidence Strength Routing

For follow-up questions about "strong recommendation," "recommendation grade,"
or "which evidence is lower certainty," start with
[[ada-kdigo-2026-evidence-strength-map]], then verify exact grade labels against
the retrieved raw ADA/KDIGO snippets.

## Teaching Message

ADA 2026 is the broad diabetes care map. KDIGO 2026 is the kidney-specific update track. For diabetes with CKD, the useful workflow is to start with ADA's whole-person diabetes framework, then deepen kidney-risk decisions with KDIGO and the ADA-KDIGO consensus baseline.

## Links

- [[../guidelines/ada-standards-of-care-2026]]
- [[../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[../concepts/organ-centric-diabetes-care]]
- [[../concepts/diabetes-ckd-risk-stratification]]

## Pending Work

- Import ADA 2026 Section 11 recommendation cards.
- Import KDIGO 2022 baseline recommendation cards.
- Replace KDIGO 2026 draft fields after final publication.
- Add drug-specific comparison rows for SGLT2 inhibitors, GLP-1 receptor agonists, finerenone, insulin, and antihypertensives.
