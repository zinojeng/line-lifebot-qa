---
title: ADA KDIGO 2026 Evidence Strength Map
type: comparison
created: 2026-05-20
updated: 2026-05-20
tags: [ada, kdigo, diabetes, ckd, evidence-grade, recommendation-strength, line-qa]
sources:
  - ../guidelines/ada-standards-of-care-2026.md
  - ../guidelines/kdigo-diabetes-management-in-ckd-2026.md
  - ../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd.md
evidence_level: local-synthesis
clinical_use: [clinical-reference, teaching, line-qa]
confidence: medium
last_verified: 2026-05-20
status: draft
obsidian_type: relationship
aliases:
  - ADA KDIGO evidence grade
  - ADA KDIGO recommendation strength
  - strong recommendation diabetes CKD
  - lower certainty evidence diabetes CKD
  - 哪些證據等級較低
  - 哪些是 strong recommendation
  - 建議等級
  - 證據等級
entities:
  - ADA 2026
  - KDIGO 2026
  - recommendation strength
  - evidence grade
  - SGLT2 inhibitor
  - GLP-1 receptor agonist
  - metformin
  - finerenone
  - eGFR
  - UACR
  - albuminuria
  - ASCVD
owner_agent: hermes
write_policy: hermes-maintained
---

# ADA KDIGO 2026 Evidence Strength Map

## Purpose

Use this page as a retrieval map for LINE follow-up questions such as "哪些是
strong recommendation" or "哪些證據等級較低" after a diabetes + CKD scenario.
It does not replace the source guideline text. Exact recommendation numbers,
grade labels, and evidence quality must be verified against the retrieved
ADA/KDIGO raw Markdown snippets before final wording.

For the fine-grained recommendation number and grade layer, read
[[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]]
before answering LINE follow-up questions about "strong recommendation" or
"哪些證據等級較低".

## High-Priority / Strongly Aligned Topics

These topics should be routed first because ADA 2026 and KDIGO CKD guidance are
usually aligned around cardiorenal risk reduction:

- SGLT2 inhibitor use in T2DM with CKD, especially when eGFR and albuminuria
  suggest kidney and cardiovascular risk. Route to
  [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] and
  [[ada-2026-vs-kdigo-2026-diabetes-ckd]].
- ACE inhibitor or ARB background therapy for albuminuria/hypertension context
  when the raw guideline snippets support it. Route to
  [[../concepts/diabetes-ckd-risk-stratification]] and KDIGO source snippets.
- ASCVD risk reduction framing, where ADA provides broad cardiovascular risk
  management and KDIGO provides CKD-specific risk context. Route to
  [[../guidelines/ada-standards-of-care-2026]] and
  [[../guidelines/kdigo-diabetes-management-in-ckd-2026]].

## Conditional / Lower-Certainty Or More Individualized Topics

These topics should not be presented as a single universal strong recommendation
unless the selected raw snippets explicitly provide a grade:

- GLP-1 receptor agonist or GLP-1-based therapy for kidney-specific outcomes or
  dialysis contexts. It may be important for ASCVD, weight, and glycemic goals,
  but kidney-specific or dialysis wording should be checked against
  [[../drugs/glp1-based-therapy-on-dialysis]] and raw KDIGO/ADA snippets.
- Glycemic targets and HbA1c goals in CKD. These are often individualized by
  hypoglycemia risk, comorbidity, age, CKD stage, and A1C reliability. Route to
  [[../concepts/diabetes-ckd-risk-stratification]] before answering.
- Metformin in CKD. Treat eGFR thresholds and dose/stop guidance as safety and
  eligibility rules that require exact source snippets, not as a general
  "strong recommendation" without the retrieved grade.
- Finerenone or nonsteroidal MRA use. Route to albuminuria, potassium, eGFR, and
  background ACEi/ARB context; do not answer from the drug name alone.
- Insulin adjustment in CKD. The usual issue is hypoglycemia risk and renal
  clearance/monitoring, so answer should be individualized and source-limited.

## LINE Answer Pattern

When the user asks only "哪些證據等級較低" after a previous case, answer by
carrying forward the prior context:

1. State that the answer is based on the previous diabetes + CKD + ASCVD
   scenario.
2. Separate "strong/high-priority or strongly aligned" from "conditional,
   individualized, or lower-certainty."
3. If the selected snippets do not show exact ADA/KDIGO grade labels, say:
   "目前已載入資料未標出精確 grade，因此不硬寫 1A/1B/2C。"
4. Keep the scope to ADA/KDIGO unless the user explicitly asks for another
   mounted source.

## Related Pages

- [[ada-2026-vs-kdigo-2026-diabetes-ckd]]
- [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]]
- [[../concepts/diabetes-ckd-risk-stratification]]
- [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]]
- [[../drugs/glp1-based-therapy-on-dialysis]]
