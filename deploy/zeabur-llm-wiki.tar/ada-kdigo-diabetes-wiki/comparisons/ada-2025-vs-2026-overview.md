---
title: ADA 2025 vs 2026 Overview
type: comparison
created: 2026-05-19
updated: 2026-05-19
tags: [relationship, ada, standards-of-care, comparison, 2025, 2026, teaching]
sources:
  - ../raw/comparisons/ada-2025-vs-2026-comparison-registry.md
  - /Users/ander/openclaw-research/ada20252026/ada2025vs2026_executive_summary_v1.3.md
  - /Users/ander/openclaw-research/ada20252026/ada2025vs2026_change_matrix_v1.3.md
  - /Users/ander/openclaw-research/ada20252026/ada2025vs2026_quick_reference_v1.3.md
evidence_level: review
clinical_use: teaching
confidence: medium
last_verified: 2026-05-19
status: active
obsidian_type: relationship
---

# ADA 2025 vs 2026 Overview

## Summary

The local ADA 2025 vs 2026 comparison corpus frames ADA 2026 as a shift from a glucose-centered guideline toward multi-organ risk management, broader diabetes technology use, earlier intervention, and more explicit handling of real-world clinical complexity.

The preferred source set is the v1.3 Round 5 report family registered in [[../raw/comparisons/ada-2025-vs-2026-comparison-registry]].

## Major Themes

- GLP-1-based therapy expands from glucose and weight treatment toward cardiovascular, kidney, liver, and obesity-related care.
- CGM and automated insulin delivery are treated as more routine diabetes-management tools, including expansion beyond classic type 1 diabetes use cases.
- Earlier and more precise intervention appears across glycemic goals, obesity management, CKD/cardiovascular risk, and special clinical contexts.
- ADA 2026 adds or strengthens special-situation guidance, including medication-induced hyperglycemia, perioperative care, hospitalized patients, older adults, children and adolescents, and CKD/dialysis drug decisions.

## High-Impact Areas To Read First

- Section 7: diabetes technology and AID/CGM expansion.
- Section 8: obesity and metabolic surgery thresholds.
- Section 9: pharmacologic treatment and GLP-1-based therapy positioning.
- Section 10: cardiovascular risk and HFpEF therapy.
- Section 11: CKD risk management, SGLT2 inhibitors, finerenone, and GLP-1-based therapy on dialysis.
- Section 13-16: older adults, pediatric care, pregnancy, and inpatient care.

## Evidence Caution

Use [[ada-2025-vs-2026-methodology-concerns]] before presenting strong claims. The local comparison corpus flags several methodology issues, including single-trial dependence, industry sponsorship concentration, trial endpoint interpretation, and population extrapolation.

## Links

- [[../guidelines/ada-standards-of-care-2026]]
- [[ada-2025-vs-2026-methodology-concerns]]
- [[ada-2025-vs-2026-taiwan-impact]]
- [[ada-2026-vs-kdigo-2026-diabetes-ckd]]
- [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]]
- [[../drugs/glp1-based-therapy-on-dialysis]]

## Next Extraction Targets

- Section-specific pages for S7, S8, S9, S10, S11, S13, S14, S15, and S16.
- Recommendation cards for AID in T2D, tirzepatide in HFpEF with obesity, metabolic surgery thresholds, GLP-1 before insulin, SGLT2i continuation, GLP-1 therapy on dialysis, and finerenone combination therapy.
