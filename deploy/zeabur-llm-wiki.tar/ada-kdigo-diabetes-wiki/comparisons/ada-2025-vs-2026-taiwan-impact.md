---
title: ADA 2025 vs 2026 Taiwan Clinical Impact
type: comparison
created: 2026-05-19
updated: 2026-05-19
tags: [relationship, ada, taiwan, clinical-practice, reimbursement, implementation, 2025, 2026]
sources:
  - /Users/ander/openclaw-research/ada20252026/ada2025vs2026_taiwan_impact_v1.3.md
  - /Users/ander/openclaw-research/ada20252026/ada2025vs2026_taiwan_impact.md
evidence_level: review
clinical_use: clinical-reference
confidence: medium
last_verified: 2026-05-19
status: active
obsidian_type: relationship
---

# ADA 2025 vs 2026 Taiwan Clinical Impact

## Purpose

This page is the Taiwan implementation entry point for ADA 2025 vs 2026 changes. Use it when adapting ADA 2026 to Taiwan clinic workflows, reimbursement constraints, drug availability, patient education, and advocacy.

## Implementation Themes

- Some ADA 2026 recommendations are conceptually ready but blocked by Taiwan drug availability or reimbursement rules.
- CGM and AID recommendations may be limited by coverage and device access, especially for T2D.
- GLP-1-based therapy recommendations need local checks for approved products, dose availability, and National Health Insurance criteria.
- Metabolic surgery thresholds in ADA 2026 may be lower than Taiwan reimbursement thresholds.
- Blood pressure target evidence from East Asian populations may be especially relevant, but individual tolerability remains essential.

## Links

- [[ada-2025-vs-2026-overview]]
- [[ada-2025-vs-2026-methodology-concerns]]
- [[../guidelines/ada-standards-of-care-2026]]
- [[../concepts/organ-centric-diabetes-care]]
- [[../concepts/diabetes-technology-cgm-aid]]

## Source Notes

- Preferred local source: `/Users/ander/openclaw-research/ada20252026/ada2025vs2026_taiwan_impact_v1.3.md`
- Earlier detailed source: `/Users/ander/openclaw-research/ada20252026/ada2025vs2026_taiwan_impact.md`
