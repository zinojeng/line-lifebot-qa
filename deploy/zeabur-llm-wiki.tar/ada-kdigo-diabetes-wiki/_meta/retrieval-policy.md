---
title: ADA-KDIGO Wiki Retrieval Policy
created: 2026-05-20
updated: 2026-05-24
type: meta
tags: [llm-wiki, retrieval, ranking, medical-safety, hermes]
sources:
  - SCHEMA.md
  - _meta/topic-map.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-24
status: active
obsidian_type: registry
aliases:
  - retrieval policy
  - wiki search policy
  - medical QA routing policy
entities:
  - Hermes Agent
  - ADA
  - KDIGO
owner_agent: hermes
write_policy: hermes-maintained
summary: "ADA-KDIGO Wiki Retrieval Policy This policy makes Hermes behave like a lightweight router while using this wiki alone. It applies to ADA/KDIGO guideline lookup, medical teaching, patient education drafting, and LINE chat..."
related: []
---

# ADA-KDIGO Wiki Retrieval Policy

This policy makes Hermes behave like a lightweight router while using this wiki
alone. It applies to ADA/KDIGO guideline lookup, medical teaching, patient
education drafting, and LINE chatbot guideline QA.

## Retrieval Order

For medical guideline questions:

1. Read [[../SCHEMA]].
2. Read [[../index]].
3. Read [[topic-map]].
4. Read [[aliases]].
5. Search exact titles, aliases, entities, tags, and filenames.
6. Read the top candidate pages.
7. Expand one-hop wikilinks when the question asks for synthesis.
8. Decide whether wiki context is sufficient.
9. If insufficient, search `raw/` guideline maps and mounted Markdown sources.
10. If still insufficient, create a research request in `inbox/research-requests/`.
11. If the answer has durable value, save it to `queries/` or update an existing page.

## Ranking Priority

Rank candidate pages by:

1. Exact title or alias match.
2. Entity match.
3. Tag match.
4. Topic-map neighborhood.
5. Direct wikilink relationship.
6. Evidence level.
7. Confidence.
8. Recency of `last_verified`.
9. Page type fit for the task.

Suggested scoring model:

```text
score =
  5 * exact_title_or_alias_match
+ 4 * entity_match
+ 3 * tag_match
+ 2 * topic_map_match
+ 2 * wikilink_neighbor
+ 2 * evidence_level_weight
+ 1 * recent_last_verified
+ 1 * correct_page_type
- 4 * stale_clinical_page
- 3 * low_confidence
- 3 * contested_unless_question_asks_for_controversy
- 5 * retired_or_archived
```

## Page Type Fit

- `guideline`: broad source navigation and section routing.
- `concept`: reusable explanation or clinical frame.
- `drug`: medication class, threshold, safety, or indication.
- `comparison`: cross-version or cross-guideline synthesis.
- `evidence-card`: exact recommendation number, grade, threshold, or source-provenance card.
- `claim`: smallest reusable statement for recommendation-grade and evidence-strength answers.
- `teaching`: educational structure, not the final source for exact thresholds.
- `patient-education`: plain-language output, not the final source for exact thresholds.
- `query`: reusable answer pattern.
- `meta`: routing, policy, and maintenance rules.

## Evidence Grade Router 2.0

When the user asks `證據等級`, `建議等級`, `strong recommendation`, or `哪些證據等級較低`, route by chapter context before ranking generic claim pages.

1. If current or recent LINE context mentions retinopathy, severe eye disease, DME/PDR/NPDR, anti-VEGF, neuropathy, neuropathic pain medication, diabetic foot, or PAD, route to [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] and [[../claims/ada-2026-retinopathy-foot-pad-claims]].
2. If context mentions MASLD, MASH, fatty liver, FIB-4, liver fibrosis, resmetirom, pioglitazone, or liver-focused GLP-1 RA/tirzepatide questions, route to [[../claims/ada-2026-masld-mash-claims]] and [[../evidence-ledger/masld-mash-ledger]].
3. Route to CKD/cardiorenal claim pages only when the current or recent context contains CKD, kidney disease, eGFR, UACR, albuminuria, KDIGO, finerenone, ACEi/ARB, or a clearly kidney-focused SGLT2i/GLP-1RA question.
4. For mixed questions, answer in separate buckets instead of blending grades across chapters.

Penalize CKD/cardiorenal claim pages for Section 12 or MASLD/MASH evidence-grade questions unless kidney context is explicit. Do not boost all `claim` pages just because the user asks for a grade; boost only the claim registry that matches the routed chapter.

## Sufficiency Check

Wiki context is sufficient only when it covers:

- the correct guideline year or draft status;
- the relevant population;
- the requested intervention or concept;
- exact thresholds when the question asks about thresholds;
- exact recommendation number and grade when the question asks about strength or certainty;
- source provenance;
- uncertainty or conflict when present.

If any of these are missing, answer with a gap note or search raw sources before
answering.

## Medical Safety Penalties

Penalize or avoid:

- `confidence: low` pages unless no better page exists;
- stale clinical pages where `last_verified` is older than 180 days;
- `status: draft` pages when the user needs final guidance;
- `evidence_level: expert-opinion` for clinical threshold answers;
- output pages when exact source pages are available;
- pages marked `contested: true` unless controversy is the topic.

## Fallback Rule

Use this hierarchy:

```text
LLM Wiki page
→ raw local Markdown / KnowDB / mounted guideline files
→ web or paper search
→ human review
```

Never fill a clinical gap from model memory.

## Writeback Rule

Write back only when the result is reusable:

- common clinical Q&A;
- chapter or guideline comparison;
- repeated recommendation-grade or lower-certainty follow-up that should become a claim;
- teaching explanation;
- patient education framing;
- recurrent uncertainty or open question.

Do not store identifiable patient information. For patient-specific questions,
save only the generalized clinical pattern if useful.
