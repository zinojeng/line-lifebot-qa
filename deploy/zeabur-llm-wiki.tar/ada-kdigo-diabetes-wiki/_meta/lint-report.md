---
title: ADA-KDIGO Wiki Lint Report
created: 2026-05-20
updated: 2026-05-20
type: meta
tags: [lint, wiki-health, hermes, maintenance]
sources:
  - reports/weekly-wiki-health.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-20
status: active
obsidian_type: registry
aliases:
  - lint report
  - wiki health report
  - maintenance report
entities:
  - Hermes Agent
owner_agent: hermes
write_policy: hermes-maintained
---

# ADA-KDIGO Wiki Lint Report

The active generated report is [[../reports/weekly-wiki-health]].

## Current Policy

- Use code-based lint for mechanical checks.
- Use Hermes review for medical judgment, duplicate concepts, and claim verification.
- Do not change exact clinical thresholds from lint output alone.

## Report Targets

- missing frontmatter;
- broken wikilinks;
- weak links;
- stale clinical pages;
- low or uncertain confidence pages;
- thin pages needing expansion;
- open query candidates and research requests.

## Related Pages

- [[retrieval-policy]]
- [[topic-map]]
- [[aliases]]
- [[../docs/hermes-routine-maintenance]]
