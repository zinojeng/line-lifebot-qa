---
title: Deferred Topic Register
summary: Register of self-improvement topic seeds that should not recreate research requests because they are intentionally deferred, routed through an existing page, or awaiting a source-aware extraction pass.
type: meta
created: 2026-05-23
updated: 2026-05-23
tags: [llm-wiki, self-improvement, audit, deferred-topics]
sources:
  - reports/wiki-self-improvement-audit.md
  - log.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: registry
aliases:
  - deferred topics
  - self-audit exclusions
entities:
  - Hermes Agent
related:
  - reports/wiki-self-improvement-audit
  - _meta/topic-map
  - guidelines/ada-standards-of-care-2026
owner_agent: hermes
write_policy: hermes-maintained
---

# Deferred Topic Register

This page prevents the self-improvement auditor from recreating research requests that were already reviewed and intentionally deferred.

## Deferred Seeds

### Older Adults Diabetes Frailty And Hypoglycemia

- slug: `older-adults-frailty`
- status: deferred
- current route: [[../guidelines/ada-standards-of-care-2026]]
- reason: The prior self-audit request was removed after review because this topic is currently routed to the ADA 2026 guideline page pending a dedicated source-aware extraction.
- revisit trigger: Create a standalone concept page only after a source-aware pass extracts ADA 2026 older-adults recommendations, hypoglycemia risk, frailty considerations, and exact recommendation numbers or grades.

## Operating Rule

Do not convert a deferred seed into a new research request unless the route above becomes broken, the source-aware extraction is started, or a LINE regression shows that the current route fails.

## Related Pages

- [[../reports/wiki-self-improvement-audit]]
- [[topic-map]]
- [[../guidelines/ada-standards-of-care-2026]]
