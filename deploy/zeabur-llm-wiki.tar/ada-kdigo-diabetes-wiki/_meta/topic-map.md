---
title: ADA-KDIGO Wiki Topic Map
created: 2026-05-20
updated: 2026-05-23
type: meta
tags: [llm-wiki, retrieval, topic-map, ada, kdigo, diabetes, ckd]
sources:
  - SCHEMA.md
  - index.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: registry
aliases:
  - topic map
  - wiki navigation map
  - retrieval map
entities:
  - ADA
  - KDIGO
  - Hermes Agent
owner_agent: hermes
write_policy: hermes-maintained
summary: "ADA-KDIGO Wiki Topic Map Use this page after ../index and before full-text search. It is a routing map for Hermes-only workflows: identify the likely topic neighborhood, read the listed pages, then decide whether raw gui..."
related:
  - reports/link-strength-report
  - mocs/diabetes-guidelines-moc
  - mocs/ada-2025-vs-2026-moc
  - evidence-ledger/ckd-cardiorenal-ledger
  - evidence-ledger/cgm-diabetes-technology-ledger
  - evidence-ledger/bone-health-osteoporosis-ledger
  - evidence-ledger/glp1-muscle-sarcopenia-ledger
  - concepts/hospital-steroid-hyperglycemia
  - queries/hospital-steroid-hyperglycemia-line-questions
---

# ADA-KDIGO Wiki Topic Map

Use this page after [[../index]] and before full-text search. It is a routing
map for Hermes-only workflows: identify the likely topic neighborhood, read the
listed pages, then decide whether raw guideline retrieval is needed.

## Diabetes With CKD

Primary pages:

- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]
- [[../concepts/diabetes-ckd-risk-stratification]]
- [[../guidelines/ada-standards-of-care-2026]]
- [[../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[../comparisons/ada-kdigo-2026-evidence-strength-map]]
- [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]]
- [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]]
- [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]]
- [[../evidence-ledger/ckd-cardiorenal-ledger]]
- [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]]
- [[../drugs/glp1-based-therapy-on-dialysis]]

Common entities and aliases:

- CKD, diabetic kidney disease, DKD
- eGFR, UACR, albuminuria
- blood pressure target, BP goal, hypertension, ACEi, ARB
- SGLT2 inhibitor, SGLT2i
- GLP-1 receptor agonist, GLP-1RA, GLP-1-based therapy
- finerenone, nsMRA
- dialysis, kidney failure, KRT
- recommendation strength, evidence grade, strong recommendation
- 排糖藥, 洗腎, 透析, 腎功能 20 以下
- 哪些證據等級較低, 哪些是 strong recommendation, 建議等級 when the recent context is CKD/cardiorenal

Fallback raw sources:

- [[../raw/guidelines/local-guideline-file-registry]]
- [[../raw/guidelines/ada-standards-of-care-2026-source-map]]
- [[../raw/guidelines/kdigo-diabetes-ckd-2026-source-map]]

## Lipids ASCVD And Statins

Primary pages:

- [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]]
- [[../guidelines/ada-standards-of-care-2026]]
- [[../concepts/organ-centric-diabetes-care]]

Common entities and aliases:

- ASCVD, LDL cholesterol, LDL-C, lipid target
- statin, high-intensity statin, moderate-intensity statin
- ezetimibe, PCSK9 inhibitor, bempedoic acid, inclisiran
- LDL <70, LDL <55, ADA 10.20, ADA 10.27
- 糖尿病 ASCVD LDL 目標, 糖尿病 statin 建議等級

Fallback raw sources:

- ADA 2026 Section 10 (`dc26s010.md`) via [[../raw/guidelines/local-guideline-file-registry]]
- KDIGO 2026 public-review draft lipid-management practice points via [[../raw/guidelines/local-guideline-file-registry]]

## ADA 2025 vs 2026 Change Review

Primary pages:

- [[../mocs/ada-2025-vs-2026-moc]]
- [[../comparisons/ada-2025-vs-2026-overview]]
- [[../comparisons/ada-2025-vs-2026-methodology-concerns]]
- [[../comparisons/ada-2025-vs-2026-taiwan-impact]]
- [[../raw/comparisons/ada-2025-vs-2026-comparison-registry]]

Common tasks:

- executive summary
- chapter-specific change review
- table or algorithm comparison
- Taiwan practice impact
- methodology or evidence-quality concerns

## Diabetes Technology

Primary pages:

- [[../concepts/diabetes-technology-cgm-aid]]
- [[../claims/ada-2026-cgm-diabetes-technology-claims]]
- [[../evidence-ledger/cgm-diabetes-technology-ledger]]
- [[../guidelines/ada-standards-of-care-2026]]
- [[../teaching/ada-kdigo-2026-medical-student-brief]]

Common entities and aliases:

- CGM, continuous glucose monitoring, rtCGM, isCGM
- BGM, SMBG
- time in range, TIR, GMI
- automated insulin delivery, AID
- 連續血糖監測, 糖尿病新科技, 血糖機, 自動胰島素輸注

Fallback raw sources:

- ADA 2026 Section 7 in [[../raw/guidelines/local-guideline-file-registry]]

## Diabetes Bone Health And Osteoporosis

Primary pages:

- [[../concepts/diabetes-bone-health-osteoporosis]]
- [[../concepts/glp1-weight-loss-muscle-sarcopenia]]
- [[../claims/ada-2026-bone-health-osteoporosis-claims]]
- [[../claims/glp1-weight-loss-muscle-sarcopenia-claims]]
- [[../evidence-ledger/bone-health-osteoporosis-ledger]]
- [[../evidence-ledger/glp1-muscle-sarcopenia-ledger]]
- [[../guidelines/ada-standards-of-care-2026]]
- [[../comparisons/ada-2025-vs-2026-overview]]

Common entities and aliases:

- osteoporosis, bone health, fracture risk
- DXA, BMD, T-score, FRAX
- calcium, vitamin D
- thiazolidinediones, TZD, sulfonylureas, hypoglycemia
- sarcopenia, SMI, lean mass, muscle loss, grip strength, chair stand
- 骨質疏鬆, 骨鬆, 骨折風險, 骨密度
- 肌少症, 肌肉質量指數, 握力下降, 腿沒力, GLP1 減重 肌肉

Fallback raw sources:

- ADA 2026 Section 4 in [[../raw/guidelines/local-guideline-file-registry]]
- Local ADA 2025 vs 2026 comparison corpus in [[../raw/comparisons/ada-2025-vs-2026-comparison-registry]]

## Diabetes MASLD And MASH

Primary pages:

- [[../concepts/diabetes-masld-mash]]
- [[../claims/ada-2026-masld-mash-claims]]
- [[../evidence-ledger/masld-mash-ledger]]
- [[../guidelines/ada-standards-of-care-2026]]
- [[../concepts/organ-centric-diabetes-care]]

Common entities and aliases:

- MASLD, MASH, NAFLD, NASH, fatty liver, steatotic liver disease
- FIB-4, liver stiffness measurement, LSM, ELF test, liver fibrosis
- GLP-1 RA, dual GIP and GLP-1 RA, pioglitazone, semaglutide, resmetirom
- ADA 4.22a, ADA 4.23, ADA 4.24, ADA 4.25, ADA 4.26, ADA 4.27a, ADA 4.27b, ADA 4.28, ADA 4.30a, ADA 4.30b, ADA 4.31a, ADA 4.31b, ADA 4.32a, ADA 4.32b
- 糖尿病脂肪肝, 糖尿病 MASH, 糖尿病 MASLD, 糖尿病肝纖維化, 脂肪肝 GLP-1, 脂肪肝 pioglitazone

Fallback raw sources:

- ADA 2026 Section 4 (`dc26s004.md`) via [[../raw/guidelines/local-guideline-file-registry]]
- [[../raw/guidelines/ada-standards-of-care-2026-source-map]]

## Retinopathy Foot And PAD

Primary pages:

- [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]]
- [[../concepts/diabetes-retinopathy-screening]]
- [[../concepts/diabetes-foot-care-pad]]
- [[../claims/ada-2026-retinopathy-foot-pad-claims]]
- [[../evidence-ledger/retinopathy-foot-pad-ledger]]
- [[../guidelines/ada-standards-of-care-2026]]

Common entities and aliases:

- diabetic retinopathy, retinopathy screening, eye exam interval
- retinal photography, FDA-approved AI retinal screening
- severe diabetic retinopathy, DME, NPDR, PDR, anti-VEGF, panretinal laser photocoagulation, vitrectomy
- diabetic foot care, foot exam, PAD screening, peripheral artery disease
- LOPS, loss of protective sensation, foot ulcer, amputation risk
- 視網膜病變篩檢, 糖尿病眼底檢查, 嚴重眼病變治療, 糖尿病足, 周邊動脈疾病
- Section 12 evidence grade, retinopathy treatment grade, foot PAD recommendation grade

Fallback raw sources:

- ADA 2026 Section 12 (`dc26s012.md`) via [[../raw/guidelines/local-guideline-file-registry]]
- [[../raw/guidelines/ada-standards-of-care-2026-source-map]]

## Neuropathy And Neuropathic Pain

Primary pages:

- [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]]
- [[../claims/ada-2026-retinopathy-foot-pad-claims]]
- [[../guidelines/ada-standards-of-care-2026]]

Common entities and aliases:

- diabetic neuropathy, DPN, painful diabetic peripheral neuropathy
- autonomic neuropathy, gastroparesis, orthostatic hypotension
- gabapentinoids, SNRI, TCA, sodium channel blocker, opioids, tramadol, tapentadol
- neuropathy treatment grade, DPN medication evidence grade
- 神經病變, 糖尿病周邊神經病變, 神經痛藥物, 藥物的證據等級

Fallback raw sources:

- ADA 2026 Section 12 (`dc26s012.md`) via [[../raw/guidelines/local-guideline-file-registry]]
- [[../raw/guidelines/ada-standards-of-care-2026-source-map]]

## Evidence Grade Follow-Up Router

Primary pages:

- [[../mocs/evidence-grade-router-moc]]
- [[aliases]]
- [[typed-relationships]]

Use [[../mocs/evidence-grade-router-moc]] when the user asks a short evidence-grade follow-up and the right clinical topic must be restored from recent LINE context.

## Markdown Page Normalization

Primary pages:

- [[../docs/llm-wiki-markdown-note-standard]]
- [[../docs/hermes-md-normalization-schedule]]
- [[../reports/markdown-normalization-audit]]
- [[../reports/wiki-graph-rebuild-audit]]
- [[../docs/templates/concept-page-template]]
- [[../docs/templates/source-page-template]]
- [[../docs/templates/project-page-template]]
- [[../docs/templates/medical-evidence-card-template]]
- [[../reports/markdown-normalization-audit]]

Common tasks:

- audit all Markdown files before wiki ingestion
- add summaries, aliases, entities, and related links
- normalize a small batch of `.md` files
- create a concept/source/project/evidence-card page from template
- run `wiki_ops.py md-audit` or `wiki_ops.py md-normalize`

## Obsidian Graph And Relationship Rebuild

Primary pages:

- [[../reports/wiki-graph-rebuild-audit]]
- [[../_meta/typed-relationships]]
- [[../_meta/aliases]]
- [[../_meta/topic-map]]
- [[../mocs/diabetes-guidelines-moc]]
- [[../mocs/ada-2025-vs-2026-moc]]
- [[../mocs/evidence-grade-router-moc]]
- [[../reports/link-strength-report]] (draft/advisory only; use for review queues until repeated runs are stable)

Common tasks:

- find orphan pages, weak-link pages, and broken wikilinks
- identify pages missing MOC, alias, or typed relationship routes
- update MOC and relationship edges before creating duplicate pages
- rebuild Obsidian local graph neighborhoods after Markdown normalization

## Pregnancy GDM CGM And Hospital Steroid Hyperglycemia

Primary pages:

- [[../concepts/diabetes-pregnancy-gdm-cgm]]
- [[../claims/ada-2026-gdm-pharmacotherapy-claims]]
- [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]]
- [[../evidence-ledger/gdm-pharmacotherapy-ledger]]
- [[../concepts/hospital-steroid-hyperglycemia]]
- [[../concepts/diabetes-technology-cgm-aid]]
- [[../guidelines/ada-standards-of-care-2026]]

Common entities and aliases:

- pregnancy diabetes, gestational diabetes, GDM, CGM in pregnancy
- GDM pharmacotherapy, Metformin in GDM evidence, gestational diabetes medication
- insulin preferred agent for GDM, metformin/glyburide not first-line, placenta crossing
- fasting/preprandial/postprandial glucose targets, TIR in pregnancy, pregnancy GMI caution
- hospital steroid hyperglycemia, glucocorticoid hyperglycemia, prednisone, prednisone NPH insulin, dexamethasone, NPH insulin
- 妊娠糖尿病, 妊娠糖尿病 metformin, 妊娠糖尿病 口服藥, 懷孕連續血糖, 類固醇高血糖, 住院 steroid 高血糖

Fallback raw sources:

- ADA 2026 Section 15 (`dc26s015.md`) via [[../raw/guidelines/local-guideline-file-registry]]
- ADA 2026 Section 16 (`dc26s016.md`) via [[../raw/guidelines/local-guideline-file-registry]]
- ADA 2026 Section 7 (`dc26s007.md`) via [[../raw/guidelines/local-guideline-file-registry]]

## Organ-Centric Diabetes Care

Primary pages:

- [[../concepts/organ-centric-diabetes-care]]
- [[../concepts/diabetes-ckd-risk-stratification]]
- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]
- [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]]
- [[../drugs/glp1-based-therapy-on-dialysis]]

Common tasks:

- explain shift from glucose-only care to organ protection
- teach cardiorenal-metabolic framing
- build medical student or resident slides
- create patient-friendly explanation without overclaiming

## Common LINE Query Terms

Use these terms as first-pass aliases before full-text search:

| User wording | Route to |
|---|---|
| SGLT2i, SGLT2, SGLT-2, 排糖藥 | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| eGFR 小於 20, 腎功能 20 以下, 洗腎前 | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| GLP-1, GLP-1RA, 洗腎 GLP-1, 透析 GLP-1 | [[../drugs/glp1-based-therapy-on-dialysis]] |
| CKD, DKD, 尿蛋白, UACR, 白蛋白尿 | [[../concepts/diabetes-ckd-risk-stratification]] |
| CGM, 連續血糖, 糖尿病新科技, 血糖機 | [[../concepts/diabetes-technology-cgm-aid]] |
| ADA KDIGO 比較, 糖尿病 CKD 指引比較 | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| strong recommendation, recommendation grade, evidence grade, 哪些證據等級較低, 建議等級 | [[../mocs/evidence-grade-router-moc]] |
| diabetes CKD blood pressure target, BP goal, 血壓目標, 130/80 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| diabetes ASCVD lipid targets, LDL target, statin grade, LDL 55, LDL 70 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| metformin, eGFR metformin, metformin CKD | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| finerenone, nsMRA, albuminuria finerenone | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| A1C reliability, A1C CKD, 洗腎 A1C 準不準 | [[../concepts/diabetes-ckd-risk-stratification]] |
| hypoglycemia, 低血糖, advanced CKD low sugar | [[../concepts/diabetes-ckd-risk-stratification]] |
| older adults, 老人, 長者, frailty | [[../guidelines/ada-standards-of-care-2026]] |
| pregnancy, gestational diabetes, GDM CGM, 懷孕, 妊娠糖尿病 | [[../concepts/diabetes-pregnancy-gdm-cgm]] |
| metformin GDM, Metformin in GDM evidence, GDM pharmacotherapy, 妊娠糖尿病 metformin, 妊娠糖尿病 口服藥 | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| hospital steroid hyperglycemia, glucocorticoid, steroid hyperglycemia, prednisone NPH insulin, 住院 steroid 高血糖, 類固醇高血糖 | [[../concepts/hospital-steroid-hyperglycemia]] |
| osteoporosis, bone health, fracture risk, 骨質疏鬆, 骨鬆, 骨折風險 | [[../concepts/diabetes-bone-health-osteoporosis]] |
| sarcopenia, muscle loss, SMI, lean mass, 握力下降, 腿沒力, 肌少症, 肌肉質量指數, GLP1 減重 肌肉 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| retinopathy screening, eye exam interval, 視網膜病變篩檢, 糖尿病眼底檢查 | [[../concepts/diabetes-retinopathy-screening]] |
| diabetic foot care, diabetes foot exam, PAD screening, 糖尿病足, 周邊動脈疾病 | [[../concepts/diabetes-foot-care-pad]] |

## Durable Query Pages

Use durable query pages when a recurring LINE wording needs a stable answer
shape before opening concept, claim, or raw-source pages.

- [[../queries/gdm-pharmacotherapy-line-questions]] for GDM metformin, glyburide, insulin, and pregnancy medication evidence questions.
- [[../queries/masld-mash-line-questions]] for diabetes MASLD/MASH, fatty liver, FIB-4, GLP-1/pioglitazone, resmetirom, and cirrhosis safety questions.
- [[../queries/section12-evidence-grade-followups]] for short "證據等級是？" follow-ups after retinopathy, neuropathy, foot-care, or PAD context.
- [[../queries/hospital-steroid-hyperglycemia-line-questions]] for inpatient steroid/glucocorticoid hyperglycemia questions.
- [[../queries/bone-glp1-muscle-line-questions]] for diabetes osteoporosis, GLP-1 muscle loss, SMI, handgrip, and sarcopenia assessment questions.

## Teaching And Output

Primary pages:

- [[../teaching/ada-kdigo-2026-medical-student-brief]]
- [[../queries/how-to-use-this-wiki-for-ada-kdigo-questions]]
- [[../queries/gdm-pharmacotherapy-line-questions]]
- [[../queries/masld-mash-line-questions]]
- [[../queries/section12-evidence-grade-followups]]
- [[../queries/hospital-steroid-hyperglycemia-line-questions]]
- [[../queries/bone-glp1-muscle-line-questions]]
- [[../docs/llm-wiki-retrieval-agent-prompt]]
- [[../docs/hermes-agent-wiki-workflow]]

Use teaching pages for explanation structure. Use guideline, comparison, drug,
and concept pages for clinical facts.

## Maintenance And Routing

Primary pages:

- [[retrieval-policy]]
- [[typed-relationships]]
- [[../docs/hermes-routine-maintenance]]
- [[../docs/hermes-agent-wiki-workflow]]
- [[../docs/medical-query-knowledge-layer-strategy]]
- [[../docs/obsidian-graph-workflow]]
- [[../inbox/retrieval-failures/README]]
- [[../inbox/answer-improvements/README]]
- [[../reports/retrieval-failure-analysis]]
- [[../reports/answer-improvement-analysis]]
- [[../reports/link-strength-report]]
- [[../reports/synthetic-qa-candidates]]
- [[../reports/source-freshness-watch]]
- [[deferred-topics]]

Routine rule:

1. Read [[../SCHEMA]], [[../index]], this topic map, and recent [[../log]].
2. Read `_meta/INDEX.json`, `_meta/page-registry.json`, and `_meta/claim-registry.json` when available.
3. Read [[aliases]] for common abbreviations and LINE wording.
4. Read [[typed-relationships]] when the failure may be a missing route, claim,
   regression test, or source-verification edge.
5. Select candidate pages by topic neighborhood.
6. Search with `scripts/wiki_fts_search.py` when title/alias search is not enough.
7. Read candidate pages.
8. If insufficient, search raw sources.
9. If still insufficient, create a request in `inbox/research-requests/`.
10. Compile repeated answer-improvement records into safe aliases, topic routes,
   MOC links, smoke tests, or research requests.
