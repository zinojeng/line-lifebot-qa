---
title: ADA-KDIGO Wiki Topic Map
created: 2026-05-20
updated: 2026-05-22
type: meta
tags: [llm-wiki, retrieval, topic-map, ada, kdigo, diabetes, ckd]
sources:
  - SCHEMA.md
  - index.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-22
status: active
obsidian_type: registry
aliases:
  - topic map
  - wiki navigation map
  - retrieval map
entities:
  - ADA
  - KDIGO
  - Hermes Agent
owner_agent: hermes
write_policy: hermes-maintained
---

# ADA-KDIGO Wiki Topic Map

Use this page after [[../index]] and before full-text search. It is a routing
map for Hermes-only workflows: identify the likely topic neighborhood, read the
listed pages, then decide whether raw guideline retrieval is needed.

## Diabetes With CKD

Primary pages:

- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]
- [[../concepts/diabetes-ckd-risk-stratification]]
- [[../guidelines/ada-standards-of-care-2026]]
- [[../guidelines/kdigo-diabetes-management-in-ckd-2026]]
- [[../comparisons/ada-kdigo-2026-evidence-strength-map]]
- [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]]
- [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]]
- [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]]
- [[../drugs/glp1-based-therapy-on-dialysis]]

Common entities and aliases:

- CKD, diabetic kidney disease, DKD
- eGFR, UACR, albuminuria
- SGLT2 inhibitor, SGLT2i
- GLP-1 receptor agonist, GLP-1RA, GLP-1-based therapy
- finerenone, nsMRA
- dialysis, kidney failure, KRT
- recommendation strength, evidence grade, strong recommendation
- 排糖藥, 洗腎, 透析, 腎功能 20 以下
- 哪些證據等級較低, 哪些是 strong recommendation, 建議等級

Fallback raw sources:

- [[../raw/guidelines/local-guideline-file-registry]]
- [[../raw/guidelines/ada-standards-of-care-2026-source-map]]
- [[../raw/guidelines/kdigo-diabetes-ckd-2026-source-map]]

## ADA 2025 vs 2026 Change Review

Primary pages:

- [[../mocs/ada-2025-vs-2026-moc]]
- [[../comparisons/ada-2025-vs-2026-overview]]
- [[../comparisons/ada-2025-vs-2026-methodology-concerns]]
- [[../comparisons/ada-2025-vs-2026-taiwan-impact]]
- [[../raw/comparisons/ada-2025-vs-2026-comparison-registry]]

Common tasks:

- executive summary
- chapter-specific change review
- table or algorithm comparison
- Taiwan practice impact
- methodology or evidence-quality concerns

## Diabetes Technology

Primary pages:

- [[../concepts/diabetes-technology-cgm-aid]]
- [[../claims/ada-2026-cgm-diabetes-technology-claims]]
- [[../evidence-ledger/cgm-diabetes-technology-ledger]]
- [[../guidelines/ada-standards-of-care-2026]]
- [[../teaching/ada-kdigo-2026-medical-student-brief]]

Common entities and aliases:

- CGM, continuous glucose monitoring, rtCGM, isCGM
- BGM, SMBG
- time in range, TIR, GMI
- automated insulin delivery, AID
- 連續血糖監測, 糖尿病新科技, 血糖機, 自動胰島素輸注

Fallback raw sources:

- ADA 2026 Section 7 in [[../raw/guidelines/local-guideline-file-registry]]

## Diabetes Bone Health And Osteoporosis

Primary pages:

- [[../concepts/diabetes-bone-health-osteoporosis]]
- [[../concepts/glp1-weight-loss-muscle-sarcopenia]]
- [[../claims/ada-2026-bone-health-osteoporosis-claims]]
- [[../claims/glp1-weight-loss-muscle-sarcopenia-claims]]
- [[../evidence-ledger/bone-health-osteoporosis-ledger]]
- [[../evidence-ledger/glp1-muscle-sarcopenia-ledger]]
- [[../guidelines/ada-standards-of-care-2026]]
- [[../comparisons/ada-2025-vs-2026-overview]]

Common entities and aliases:

- osteoporosis, bone health, fracture risk
- DXA, BMD, T-score, FRAX
- calcium, vitamin D
- thiazolidinediones, TZD, sulfonylureas, hypoglycemia
- sarcopenia, SMI, lean mass, muscle loss, grip strength, chair stand
- 骨質疏鬆, 骨鬆, 骨折風險, 骨密度
- 肌少症, 肌肉質量指數, 握力下降, 腿沒力, GLP1 減重 肌肉

Fallback raw sources:

- ADA 2026 Section 4 in [[../raw/guidelines/local-guideline-file-registry]]
- Local ADA 2025 vs 2026 comparison corpus in [[../raw/comparisons/ada-2025-vs-2026-comparison-registry]]

## Retinopathy Foot And PAD

Primary pages:

- [[../concepts/diabetes-retinopathy-screening]]
- [[../concepts/diabetes-foot-care-pad]]
- [[../claims/ada-2026-retinopathy-foot-pad-claims]]
- [[../evidence-ledger/retinopathy-foot-pad-ledger]]
- [[../guidelines/ada-standards-of-care-2026]]

Common entities and aliases:

- diabetic retinopathy, retinopathy screening, eye exam interval
- retinal photography, FDA-approved AI retinal screening
- diabetic foot care, foot exam, PAD screening, peripheral artery disease
- LOPS, loss of protective sensation, foot ulcer, amputation risk
- 視網膜病變篩檢, 糖尿病眼底檢查, 糖尿病足, 周邊動脈疾病

Fallback raw sources:

- ADA 2026 Section 12 (`dc26s012.md`) via [[../raw/guidelines/local-guideline-file-registry]]
- [[../raw/guidelines/ada-standards-of-care-2026-source-map]]

## Pregnancy GDM CGM And Hospital Steroid Hyperglycemia

Primary pages:

- [[../concepts/diabetes-pregnancy-gdm-cgm]]
- [[../claims/ada-2026-gdm-pharmacotherapy-claims]]
- [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]]
- [[../evidence-ledger/gdm-pharmacotherapy-ledger]]
- [[../concepts/hospital-steroid-hyperglycemia]]
- [[../concepts/diabetes-technology-cgm-aid]]
- [[../guidelines/ada-standards-of-care-2026]]

Common entities and aliases:

- pregnancy diabetes, gestational diabetes, GDM, CGM in pregnancy
- GDM pharmacotherapy, Metformin in GDM evidence, gestational diabetes medication
- insulin preferred agent for GDM, metformin/glyburide not first-line, placenta crossing
- fasting/preprandial/postprandial glucose targets, TIR in pregnancy, pregnancy GMI caution
- hospital steroid hyperglycemia, glucocorticoid hyperglycemia, prednisone, prednisone NPH insulin, dexamethasone, NPH insulin
- 妊娠糖尿病, 妊娠糖尿病 metformin, 妊娠糖尿病 口服藥, 懷孕連續血糖, 類固醇高血糖, 住院 steroid 高血糖

Fallback raw sources:

- ADA 2026 Section 15 (`dc26s015.md`) via [[../raw/guidelines/local-guideline-file-registry]]
- ADA 2026 Section 16 (`dc26s016.md`) via [[../raw/guidelines/local-guideline-file-registry]]
- ADA 2026 Section 7 (`dc26s007.md`) via [[../raw/guidelines/local-guideline-file-registry]]

## Organ-Centric Diabetes Care

Primary pages:

- [[../concepts/organ-centric-diabetes-care]]
- [[../concepts/diabetes-ckd-risk-stratification]]
- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]
- [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]]
- [[../drugs/glp1-based-therapy-on-dialysis]]

Common tasks:

- explain shift from glucose-only care to organ protection
- teach cardiorenal-metabolic framing
- build medical student or resident slides
- create patient-friendly explanation without overclaiming

## Common LINE Query Terms

Use these terms as first-pass aliases before full-text search:

| User wording | Route to |
|---|---|
| SGLT2i, SGLT2, SGLT-2, 排糖藥 | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| eGFR 小於 20, 腎功能 20 以下, 洗腎前 | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| GLP-1, GLP-1RA, 洗腎 GLP-1, 透析 GLP-1 | [[../drugs/glp1-based-therapy-on-dialysis]] |
| CKD, DKD, 尿蛋白, UACR, 白蛋白尿 | [[../concepts/diabetes-ckd-risk-stratification]] |
| CGM, 連續血糖, 糖尿病新科技, 血糖機 | [[../concepts/diabetes-technology-cgm-aid]] |
| ADA KDIGO 比較, 糖尿病 CKD 指引比較 | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| strong recommendation, recommendation grade, evidence grade, 哪些證據等級較低, 建議等級 | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| metformin, eGFR metformin, metformin CKD | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| finerenone, nsMRA, albuminuria finerenone | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| A1C reliability, A1C CKD, 洗腎 A1C 準不準 | [[../concepts/diabetes-ckd-risk-stratification]] |
| hypoglycemia, 低血糖, advanced CKD low sugar | [[../concepts/diabetes-ckd-risk-stratification]] |
| older adults, 老人, 長者, frailty | [[../guidelines/ada-standards-of-care-2026]] |
| pregnancy, gestational diabetes, GDM CGM, 懷孕, 妊娠糖尿病 | [[../concepts/diabetes-pregnancy-gdm-cgm]] |
| metformin GDM, Metformin in GDM evidence, GDM pharmacotherapy, 妊娠糖尿病 metformin, 妊娠糖尿病 口服藥 | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| hospital steroid hyperglycemia, glucocorticoid, steroid hyperglycemia, prednisone NPH insulin, 住院 steroid 高血糖, 類固醇高血糖 | [[../concepts/hospital-steroid-hyperglycemia]] |
| osteoporosis, bone health, fracture risk, 骨質疏鬆, 骨鬆, 骨折風險 | [[../concepts/diabetes-bone-health-osteoporosis]] |
| sarcopenia, muscle loss, SMI, lean mass, 握力下降, 腿沒力, 肌少症, 肌肉質量指數, GLP1 減重 肌肉 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| retinopathy screening, eye exam interval, 視網膜病變篩檢, 糖尿病眼底檢查 | [[../concepts/diabetes-retinopathy-screening]] |
| diabetic foot care, diabetes foot exam, PAD screening, 糖尿病足, 周邊動脈疾病 | [[../concepts/diabetes-foot-care-pad]] |

## Teaching And Output

Primary pages:

- [[../teaching/ada-kdigo-2026-medical-student-brief]]
- [[../queries/how-to-use-this-wiki-for-ada-kdigo-questions]]
- [[../docs/llm-wiki-retrieval-agent-prompt]]
- [[../docs/hermes-agent-wiki-workflow]]

Use teaching pages for explanation structure. Use guideline, comparison, drug,
and concept pages for clinical facts.

## Maintenance And Routing

Primary pages:

- [[retrieval-policy]]
- [[typed-relationships]]
- [[../docs/hermes-routine-maintenance]]
- [[../docs/hermes-agent-wiki-workflow]]
- [[../docs/medical-query-knowledge-layer-strategy]]
- [[../docs/obsidian-graph-workflow]]
- [[../inbox/retrieval-failures/README]]
- [[../inbox/answer-improvements/README]]
- [[../reports/retrieval-failure-analysis]]
- [[../reports/answer-improvement-analysis]]
- [[../reports/synthetic-qa-candidates]]
- [[../reports/source-freshness-watch]]
- [[typed-relationships]]

Routine rule:

1. Read [[../SCHEMA]], [[../index]], this topic map, and recent [[../log]].
2. Read `_meta/INDEX.json`, `_meta/page-registry.json`, and `_meta/claim-registry.json` when available.
3. Read [[aliases]] for common abbreviations and LINE wording.
4. Read [[typed-relationships]] when the failure may be a missing route, claim,
   regression test, or source-verification edge.
5. Select candidate pages by topic neighborhood.
6. Search with `scripts/wiki_fts_search.py` when title/alias search is not enough.
7. Read candidate pages.
8. If insufficient, search raw sources.
9. If still insufficient, create a request in `inbox/research-requests/`.
10. Compile repeated answer-improvement records into safe aliases, topic routes,
   MOC links, smoke tests, or research requests.
