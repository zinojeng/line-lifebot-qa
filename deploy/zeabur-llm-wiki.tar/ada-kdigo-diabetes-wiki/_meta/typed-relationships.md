---
title: ADA-KDIGO Wiki Typed Relationships
type: meta
created: 2026-05-20
updated: 2026-05-24
tags: [llm-wiki, relationships, graph, obsidian, retrieval, hermes]
sources:
  - SCHEMA.md
  - index.md
  - _meta/topic-map.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-24
status: active
obsidian_type: registry
aliases:
  - typed relationships
  - knowledge graph relationships
  - Obsidian graph relationship policy
entities:
  - Hermes Agent
  - Obsidian
  - LINE QA
owner_agent: hermes
write_policy: hermes-maintained
summary: "ADA-KDIGO Wiki Typed Relationships This page gives Hermes a map of relation types. Obsidian can still use normal `wikilinks`, but agents should also think in these typed edges when routing, checking consistency, and deci..."
related: []
---

# ADA-KDIGO Wiki Typed Relationships

This page gives Hermes a map of relation types. Obsidian can still use normal
`[[wikilinks]]`, but agents should also think in these typed edges when routing,
checking consistency, and deciding what to update.

## Relationship Types

| relationship | Meaning | Example |
|---|---|---|
| `supports_claim` | A source or evidence card supports a claim registry item. | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] supports [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]]. |
| `canonicalizes` | Alias or topic-map entry points to the canonical page. | [[aliases]] canonicalizes "哪些證據等級較低" to [[../mocs/evidence-grade-router-moc]]. |
| `routes_to` | A MOC/topic page routes a query family to a page. | [[topic-map]] routes CKD grade questions to [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]]. |
| `requires_raw_verification` | A page can answer broadly but exact thresholds/grades should be checked against raw source maps or source Markdown. | [[../concepts/diabetes-ckd-risk-stratification]] requires raw verification for exact KDIGO practice points. |
| `lower_certainty_than` | One recommendation is explicitly lower certainty than another. | ADA 11.11a continuation below eGFR 20 is lower-certainty than ADA 11.7a initiation at eGFR at least 20. |
| `teaches_from` | A teaching/output page derives explanation structure from clinical pages. | [[../teaching/ada-kdigo-2026-medical-student-brief]] teaches from CKD concept and claim pages. |
| `compares_with` | A comparison page should be read alongside related comparison, methodology, or implementation pages. | [[../comparisons/ada-2025-vs-2026-overview]] compares with methodology and Taiwan-impact comparison pages. |
| `gap_generates_request` | A repeated query gap generates an inbox research request. | Reports generate `inbox/research-requests/`. |
| `regression_tests` | A synthetic QA or smoke test protects a routing behavior. | Synthetic CKD grade questions regression-test the claim registry. |

## High-Value Current Edges

- [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]]
  `supports_claim` <- [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]]
- [[aliases]]
  `canonicalizes` -> [[../mocs/evidence-grade-router-moc]] for generic "strong recommendation", "證據等級", "建議等級", and "哪些證據等級較低" follow-ups.
- [[topic-map]]
  `routes_to` -> [[../mocs/evidence-grade-router-moc]] for generic evidence-grade follow-up; the router then dispatches to CKD, BP, lipid, GDM, Section 12, CGM, or bone pages by current and recent LINE context.
- [[../mocs/evidence-grade-router-moc]]
  `routes_to` -> [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] for retinopathy, neuropathy, foot-care, and PAD Section 12 evidence-grade follow-ups.
- [[../mocs/evidence-grade-router-moc]]
  `routes_to` -> [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] only when current or recent context is CKD/cardiorenal, eGFR, UACR, SGLT2i, GLP-1RA, finerenone, ACEi/ARB, or KDIGO.

- [[../mocs/evidence-grade-router-moc]]
  `penalizes_unless_context` -> [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] for Section 12 or MASLD/MASH evidence-grade questions without explicit kidney context.
- [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]]
  `supports_claim` -> [[../claims/ada-2026-retinopathy-foot-pad-claims]].
- [[aliases]]
  `canonicalizes` -> [[../claims/ada-2026-gdm-pharmacotherapy-claims]] for "Metformin in GDM evidence", "metformin GDM", and "妊娠糖尿病 metformin".
- [[topic-map]]
  `routes_to` -> [[../claims/ada-2026-gdm-pharmacotherapy-claims]] for GDM pharmacotherapy and oral-agent questions.
- [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]]
  `supports_claim` -> [[../claims/ada-2026-gdm-pharmacotherapy-claims]].
- [[aliases]]
  `canonicalizes` -> [[../claims/ada-2026-masld-mash-claims]] for "MASH 建議等級", "糖尿病 MASH 建議等級", "糖尿病脂肪肝 建議等級", and MASLD/MASH medication-grade questions.
- [[topic-map]]
  `routes_to` -> [[../concepts/diabetes-masld-mash]], [[../claims/ada-2026-masld-mash-claims]], and [[../evidence-ledger/masld-mash-ledger]] for diabetes MASLD/MASH, fatty-liver, FIB-4, GLP-1 RA, pioglitazone, resmetirom, and hepatology-referral questions.
- [[../claims/ada-2026-masld-mash-claims]]
  `supports_claim` <- [[../concepts/diabetes-masld-mash]] and [[../evidence-ledger/masld-mash-ledger]] by preserving ADA 2026 Section 4 recommendation numbers, grade splits, and verification provenance.
- [[../concepts/diabetes-masld-mash]]
  `requires_raw_verification` for exact ADA 2026 Section 4 recommendation wording, grade splits, FIB-4/LSM/ELF thresholds, cirrhosis cautions, and resmetirom referral wording.
- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]
  `requires_raw_verification` for exact thresholds, dosing limits, and final KDIGO publication status.
- [[../concepts/glp1-weight-loss-muscle-sarcopenia]]
  `requires_raw_verification` for diagnostic cutoffs outside ADA/KDIGO because sarcopenia cutoffs come from AWGS/EWGSOP rather than ADA/KDIGO.

## Graph Rebuild Edges

These edges exist to keep Obsidian graph and Hermes retrieval navigation
complete after Markdown normalization. They do not create new medical claims.

- [[../reports/wiki-graph-rebuild-audit]]
  `routes_to` -> [[../_meta/topic-map]], [[../_meta/aliases]], and [[../_meta/typed-relationships]] for graph repair.
- [[../reports/wiki-graph-rebuild-audit]]
  `regression_tests` -> [[../reports/markdown-normalization-audit]] for weak-link and missing-route drift.
- [[topic-map]]
  `routes_to` -> [[../concepts/diabetes-bone-health-osteoporosis]], [[../claims/ada-2026-bone-health-osteoporosis-claims]], and [[../evidence-ledger/bone-health-osteoporosis-ledger]].
- [[topic-map]]
  `routes_to` -> [[../concepts/glp1-weight-loss-muscle-sarcopenia]], [[../claims/glp1-weight-loss-muscle-sarcopenia-claims]], and [[../evidence-ledger/glp1-muscle-sarcopenia-ledger]].
- [[topic-map]]
  `routes_to` -> [[../concepts/diabetes-technology-cgm-aid]], [[../claims/ada-2026-cgm-diabetes-technology-claims]], and [[../evidence-ledger/cgm-diabetes-technology-ledger]].
- [[topic-map]]
  `routes_to` -> [[../concepts/diabetes-pregnancy-gdm-cgm]], [[../claims/ada-2026-gdm-pharmacotherapy-claims]], [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]], and [[../evidence-ledger/gdm-pharmacotherapy-ledger]].
- [[topic-map]]
  `routes_to` -> [[../concepts/hospital-steroid-hyperglycemia]] for inpatient steroid/glucocorticoid hyperglycemia questions.
- [[topic-map]]
  `routes_to` -> [[../concepts/diabetes-retinopathy-screening]], [[../concepts/diabetes-foot-care-pad]], [[../claims/ada-2026-retinopathy-foot-pad-claims]], [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]], and [[../evidence-ledger/retinopathy-foot-pad-ledger]].
- [[topic-map]]
  `routes_to` -> [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] and [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]].
- [[topic-map]]
  `routes_to` -> [[../concepts/organ-centric-diabetes-care]], [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]], and [[../drugs/glp1-based-therapy-on-dialysis]].
- [[../evidence-ledger/ckd-cardiorenal-ledger]]
  `supports_claim` -> [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] by recording claim-change provenance over time.
- [[../guidelines/ada-standards-of-care-2026]]
  `supports_claim` -> [[../guidelines/ada2026]] as a short alias page.
- [[../guidelines/kdigo-diabetes-management-in-ckd-2026]]
  `supports_claim` -> [[../guidelines/kdigo2026]] as a short alias page.
- [[../comparisons/ada-2025-vs-2026-overview]]
  `compares_with` -> [[../comparisons/ada-2025-vs-2026-methodology-concerns]] and [[../comparisons/ada-2025-vs-2026-taiwan-impact]].
- [[../comparisons/ada-kdigo-2026-evidence-strength-map]]
  `routes_to` -> [[../mocs/evidence-grade-router-moc]] for recommendation-grade follow-ups.
- [[../queries/how-to-use-this-wiki-for-ada-kdigo-questions]]
  `teaches_from` -> [[../_meta/retrieval-policy]], [[../_meta/topic-map]], and [[../_meta/aliases]].
- [[../queries/gdm-pharmacotherapy-line-questions]]
  `routes_to` -> [[../claims/ada-2026-gdm-pharmacotherapy-claims]], [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]], and [[../concepts/diabetes-pregnancy-gdm-cgm]] for GDM medication questions.
- [[../queries/masld-mash-line-questions]]
  `routes_to` -> [[../concepts/diabetes-masld-mash]], [[../claims/ada-2026-masld-mash-claims]], and [[../evidence-ledger/masld-mash-ledger]] for diabetes fatty-liver/MASLD/MASH questions.
- [[../queries/section12-evidence-grade-followups]]
  `routes_to` -> [[../mocs/evidence-grade-router-moc]], [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]], and [[../claims/ada-2026-retinopathy-foot-pad-claims]] for retinopathy, neuropathy, foot-care, and PAD evidence-grade follow-ups.
- [[../queries/hospital-steroid-hyperglycemia-line-questions]]
  `routes_to` -> [[../concepts/hospital-steroid-hyperglycemia]] and [[../guidelines/ada-standards-of-care-2026]] for inpatient glucocorticoid/steroid hyperglycemia questions.
- [[../queries/bone-glp1-muscle-line-questions]]
  `routes_to` -> [[../concepts/diabetes-bone-health-osteoporosis]], [[../claims/ada-2026-bone-health-osteoporosis-claims]], [[../concepts/glp1-weight-loss-muscle-sarcopenia]], and [[../claims/glp1-weight-loss-muscle-sarcopenia-claims]] for bone, GLP-1 weight-loss, SMI, handgrip, and sarcopenia questions.

## Agent Rule

During self-improvement audits, Hermes should propose edge updates before page
rewrites. If an answer fails because the right page exists but was not found, add
`canonicalizes`, `routes_to`, or `regression_tests` support before creating a new
clinical page.
