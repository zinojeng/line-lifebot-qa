---
title: ADA-KDIGO Wiki Typed Relationships
type: meta
created: 2026-05-20
updated: 2026-05-22
tags: [llm-wiki, relationships, graph, obsidian, retrieval, hermes]
sources:
  - SCHEMA.md
  - index.md
  - _meta/topic-map.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-22
status: active
obsidian_type: registry
aliases:
  - typed relationships
  - knowledge graph relationships
  - Obsidian graph relationship policy
entities:
  - Hermes Agent
  - Obsidian
  - LINE QA
owner_agent: hermes
write_policy: hermes-maintained
---

# ADA-KDIGO Wiki Typed Relationships

This page gives Hermes a map of relation types. Obsidian can still use normal
`[[wikilinks]]`, but agents should also think in these typed edges when routing,
checking consistency, and deciding what to update.

## Relationship Types

| relationship | Meaning | Example |
|---|---|---|
| `supports_claim` | A source or evidence card supports a claim registry item. | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] supports [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]]. |
| `canonicalizes` | Alias or topic-map entry points to the canonical page. | [[aliases]] canonicalizes "哪些證據等級較低" to [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]]. |
| `routes_to` | A MOC/topic page routes a query family to a page. | [[topic-map]] routes CKD grade questions to [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]]. |
| `requires_raw_verification` | A page can answer broadly but exact thresholds/grades should be checked against raw source maps or source Markdown. | [[../concepts/diabetes-ckd-risk-stratification]] requires raw verification for exact KDIGO practice points. |
| `lower_certainty_than` | One recommendation is explicitly lower certainty than another. | ADA 11.11a continuation below eGFR 20 is lower-certainty than ADA 11.7a initiation at eGFR at least 20. |
| `teaches_from` | A teaching/output page derives explanation structure from clinical pages. | [[../teaching/ada-kdigo-2026-medical-student-brief]] teaches from CKD concept and claim pages. |
| `gap_generates_request` | A repeated query gap generates an inbox research request. | Reports generate `inbox/research-requests/`. |
| `regression_tests` | A synthetic QA or smoke test protects a routing behavior. | Synthetic CKD grade questions regression-test the claim registry. |

## High-Value Current Edges

- [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]]
  `supports_claim` <- [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]]
- [[aliases]]
  `canonicalizes` -> [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] for "strong recommendation", "證據等級", and "哪些證據等級較低".
- [[topic-map]]
  `routes_to` -> [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] for ADA/KDIGO evidence-grade follow-up.
- [[aliases]]
  `canonicalizes` -> [[../claims/ada-2026-gdm-pharmacotherapy-claims]] for "Metformin in GDM evidence", "metformin GDM", and "妊娠糖尿病 metformin".
- [[topic-map]]
  `routes_to` -> [[../claims/ada-2026-gdm-pharmacotherapy-claims]] for GDM pharmacotherapy and oral-agent questions.
- [[../evidence-cards/ada-2026-gdm-pharmacotherapy-recommendation-grades]]
  `supports_claim` -> [[../claims/ada-2026-gdm-pharmacotherapy-claims]].
- [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]]
  `requires_raw_verification` for exact thresholds, dosing limits, and final KDIGO publication status.
- [[../concepts/glp1-weight-loss-muscle-sarcopenia]]
  `requires_raw_verification` for diagnostic cutoffs outside ADA/KDIGO because sarcopenia cutoffs come from AWGS/EWGSOP rather than ADA/KDIGO.

## Agent Rule

During self-improvement audits, Hermes should propose edge updates before page
rewrites. If an answer fails because the right page exists but was not found, add
`canonicalizes`, `routes_to`, or `regression_tests` support before creating a new
clinical page.
