---
title: ADA-KDIGO Wiki Alias Registry
created: 2026-05-20
updated: 2026-05-23
type: meta
tags: [aliases, retrieval, line, diabetes, ckd, hermes]
sources:
  - _meta/topic-map.md
  - _meta/retrieval-policy.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-23
status: active
obsidian_type: registry
aliases:
  - alias registry
  - LINE query alias map
  - medical retrieval aliases
entities:
  - Hermes Agent
  - LINE QA
  - ADA
  - KDIGO
owner_agent: hermes
write_policy: hermes-maintained
summary: "ADA-KDIGO Wiki Alias Registry Use this page before full-text search. It maps common user wording, LINE phrasing, and abbreviation variants to canonical wiki pages. Diabetes With CKD | Alias or phrase | Canonical page | |..."
related: []
---

# ADA-KDIGO Wiki Alias Registry

Use this page before full-text search. It maps common user wording, LINE phrasing,
and abbreviation variants to canonical wiki pages.

## Diabetes With CKD

| Alias or phrase | Canonical page |
|---|---|
| CKD | [[../concepts/diabetes-ckd-risk-stratification]] |
| DKD | [[../concepts/diabetes-ckd-risk-stratification]] |
| diabetic kidney disease | [[../concepts/diabetes-ckd-risk-stratification]] |
| 糖尿病腎病變 | [[../concepts/diabetes-ckd-risk-stratification]] |
| eGFR | [[../concepts/diabetes-ckd-risk-stratification]] |
| UACR | [[../concepts/diabetes-ckd-risk-stratification]] |
| albuminuria | [[../concepts/diabetes-ckd-risk-stratification]] |
| 白蛋白尿 | [[../concepts/diabetes-ckd-risk-stratification]] |
| 尿蛋白 | [[../concepts/diabetes-ckd-risk-stratification]] |
| A1C reliability in CKD | [[../concepts/diabetes-ckd-risk-stratification]] |
| 洗腎 A1C 準不準 | [[../concepts/diabetes-ckd-risk-stratification]] |

## SGLT2 Inhibitors

| Alias or phrase | Canonical page |
|---|---|
| SGLT2i | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| SGLT2 inhibitor | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| SGLT-2 inhibitor | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| 排糖藥 | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| eGFR under 20 | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| eGFR 小於 20 | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| 腎功能 20 以下 | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| 洗腎前 SGLT2i | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| ADA 2026 11.11a | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |

## GLP-1-Based Therapy

| Alias or phrase | Canonical page |
|---|---|
| GLP-1RA | [[../drugs/glp1-based-therapy-on-dialysis]] |
| GLP-1 receptor agonist | [[../drugs/glp1-based-therapy-on-dialysis]] |
| GLP-1-based therapy | [[../drugs/glp1-based-therapy-on-dialysis]] |
| GLP-1 dialysis | [[../drugs/glp1-based-therapy-on-dialysis]] |
| GLP-1 洗腎 | [[../drugs/glp1-based-therapy-on-dialysis]] |
| GLP-1 透析 | [[../drugs/glp1-based-therapy-on-dialysis]] |
| 洗腎病人 GLP-1 | [[../drugs/glp1-based-therapy-on-dialysis]] |
| transplant listing weight loss | [[../drugs/glp1-based-therapy-on-dialysis]] |
| ADA 2026 11.11b | [[../drugs/glp1-based-therapy-on-dialysis]] |

## Diabetes Technology

| Alias or phrase | Canonical page |
|---|---|
| CGM | [[../concepts/diabetes-technology-cgm-aid]] |
| CGM claim | [[../claims/ada-2026-cgm-diabetes-technology-claims]] |
| continuous glucose monitoring | [[../concepts/diabetes-technology-cgm-aid]] |
| 連續血糖監測 | [[../concepts/diabetes-technology-cgm-aid]] |
| 連續血糖 | [[../concepts/diabetes-technology-cgm-aid]] |
| 糖尿病新科技 | [[../concepts/diabetes-technology-cgm-aid]] |
| 血糖機 | [[../concepts/diabetes-technology-cgm-aid]] |
| AID | [[../concepts/diabetes-technology-cgm-aid]] |
| automated insulin delivery | [[../concepts/diabetes-technology-cgm-aid]] |
| time in range | [[../concepts/diabetes-technology-cgm-aid]] |
| TIR | [[../concepts/diabetes-technology-cgm-aid]] |

## Guideline Hubs

| Alias or phrase | Canonical page |
|---|---|
| ADA 2026 | [[../guidelines/ada-standards-of-care-2026]] |
| ADA Standards 2026 | [[../guidelines/ada-standards-of-care-2026]] |
| ADA S7 | [[../guidelines/ada-standards-of-care-2026]] |
| ADA S9 | [[../guidelines/ada-standards-of-care-2026]] |
| ADA S10 | [[../guidelines/ada-standards-of-care-2026]] |
| ADA S11 | [[../guidelines/ada-standards-of-care-2026]] |
| KDIGO 2026 | [[../guidelines/kdigo-diabetes-management-in-ckd-2026]] |
| KDIGO Diabetes CKD | [[../guidelines/kdigo-diabetes-management-in-ckd-2026]] |
| ADA KDIGO comparison | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| 糖尿病 CKD 指引比較 | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |

## Lipids ASCVD And Statins

| Alias or phrase | Canonical page |
|---|---|
| diabetes ASCVD lipid targets | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 2026 LDL target diabetes ASCVD | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| LDL cholesterol goal diabetes ASCVD | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| statin recommendation grade diabetes | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.17 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.18 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.19 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.20 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.21 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.22 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.23 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.24 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.25 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.26 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.27 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.28a | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| ADA 10.28b | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| 糖尿病 ASCVD LDL 目標 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |
| 糖尿病 statin 建議等級 | [[../evidence-cards/ada-2026-lipid-ascvd-recommendation-grades]] |

## CKD Blood Pressure Targets

| Alias or phrase | Canonical page |
|---|---|
| diabetes CKD blood pressure target | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| diabetic kidney disease BP target | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| ADA 2026 CKD blood pressure goal | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| KDIGO diabetes CKD BP target | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| ADA 10.1 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| ADA 10.2 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| ADA 10.3 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| ADA 10.4 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| ADA 10.6 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| ADA 10.7 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| ADA 10.8 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| ADA 10.10 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| ADA 11.5 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| ADA 11.6a | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| KDIGO 4.2.1 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| 糖尿病 CKD 血壓目標 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |
| 糖尿病腎病變 血壓 130/80 | [[../evidence-cards/ada-kdigo-2026-bp-ckd-targets]] |

## Evidence Strength Follow-Up

Generic evidence-grade aliases route to [[../mocs/evidence-grade-router-moc]] first. CKD/cardiorenal claim pages remain canonical only after the current or recent LINE context is CKD, eGFR, UACR, SGLT2i, GLP-1RA, finerenone, ACEi/ARB, or KDIGO.

| Alias or phrase | Canonical page |
|---|---|
| strong recommendation | [[../mocs/evidence-grade-router-moc]] |
| recommendation strength | [[../mocs/evidence-grade-router-moc]] |
| evidence grade | [[../mocs/evidence-grade-router-moc]] |
| lower certainty evidence | [[../mocs/evidence-grade-router-moc]] |
| claim registry | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| recommendation claim | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| ADA 11.7a | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| ADA 11.7b | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| ADA 11.11a | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| ADA 11.11b | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| KDIGO 4.3.1 | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| KDIGO 4.4.1 | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| KDIGO 4.5.1 | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| 哪些證據等級較低 | [[../mocs/evidence-grade-router-moc]] |
| 哪些是 strong recommendation | [[../mocs/evidence-grade-router-moc]] |
| 建議等級 | [[../mocs/evidence-grade-router-moc]] |
| 證據等級 | [[../mocs/evidence-grade-router-moc]] |
| recommendation grade router | [[../mocs/evidence-grade-router-moc]] |
| 證據等級 router | [[../mocs/evidence-grade-router-moc]] |
| 建議等級 router | [[../mocs/evidence-grade-router-moc]] |

## Markdown Normalization And Templates

| Alias or phrase | Canonical page |
|---|---|
| markdown note standard | [[../docs/llm-wiki-markdown-note-standard]] |
| md note quality standard | [[../docs/llm-wiki-markdown-note-standard]] |
| LLM Wiki 單篇模板 | [[../docs/llm-wiki-markdown-note-standard]] |
| Markdown 筆記標準 | [[../docs/llm-wiki-markdown-note-standard]] |
| all markdown cleanup schedule | [[../docs/hermes-md-normalization-schedule]] |
| 全庫 Markdown 整理排程 | [[../docs/hermes-md-normalization-schedule]] |
| md-audit | [[../docs/hermes-md-normalization-schedule]] |
| md-normalize | [[../docs/hermes-md-normalization-schedule]] |
| concept page template | [[../docs/templates/concept-page-template]] |
| source map template | [[../docs/templates/source-page-template]] |
| project workflow template | [[../docs/templates/project-page-template]] |
| evidence card template | [[../docs/templates/medical-evidence-card-template]] |
| graph rebuild audit | [[../reports/wiki-graph-rebuild-audit]] |
| Obsidian graph audit | [[../reports/wiki-graph-rebuild-audit]] |
| relationship edge audit | [[../reports/wiki-graph-rebuild-audit]] |
| orphan pages | [[../reports/wiki-graph-rebuild-audit]] |

## Comparison And Workflow Shortcuts

| Alias or phrase | Canonical page |
|---|---|
| ADA 2025 vs 2026 overview | [[../comparisons/ada-2025-vs-2026-overview]] |
| ADA 2025 vs 2026 methodology concerns | [[../comparisons/ada-2025-vs-2026-methodology-concerns]] |
| ADA 2025 vs 2026 Taiwan impact | [[../comparisons/ada-2025-vs-2026-taiwan-impact]] |
| ADA 2026 short alias | [[../guidelines/ada2026]] |
| KDIGO 2026 short alias | [[../guidelines/kdigo2026]] |
| how to use this wiki | [[../queries/how-to-use-this-wiki-for-ada-kdigo-questions]] |
| LLM Wiki query workflow | [[../queries/how-to-use-this-wiki-for-ada-kdigo-questions]] |

## Second-Batch Clinical Terms

| Alias or phrase | Canonical page |
|---|---|
| metformin CKD | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| finerenone | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| nsMRA | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| hypoglycemia advanced CKD | [[../concepts/diabetes-ckd-risk-stratification]] |
| 低血糖 腎功能 | [[../concepts/diabetes-ckd-risk-stratification]] |
| older adults | [[../guidelines/ada-standards-of-care-2026]] |
| 長者糖尿病 | [[../guidelines/ada-standards-of-care-2026]] |
| pregnancy diabetes | [[../concepts/diabetes-pregnancy-gdm-cgm]] |
| gestational diabetes CGM | [[../concepts/diabetes-pregnancy-gdm-cgm]] |
| GDM CGM | [[../concepts/diabetes-pregnancy-gdm-cgm]] |
| Metformin in GDM evidence | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| metformin GDM | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| metformin in gestational diabetes | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| GDM pharmacotherapy | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| gestational diabetes medication | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| diabetes in pregnancy medication | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| diabetes in pregnancy glucose targets | [[../concepts/diabetes-pregnancy-gdm-cgm]] |
| 妊娠糖尿病 | [[../concepts/diabetes-pregnancy-gdm-cgm]] |
| 孕期糖尿病 | [[../concepts/diabetes-pregnancy-gdm-cgm]] |
| 妊娠糖尿病 CGM | [[../concepts/diabetes-pregnancy-gdm-cgm]] |
| 妊娠糖尿病 metformin | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| 妊娠糖尿病 口服藥 | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| 懷孕糖尿病 用藥 | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| 懷孕糖尿病用藥 | [[../claims/ada-2026-gdm-pharmacotherapy-claims]] |
| 懷孕 連續血糖 | [[../concepts/diabetes-pregnancy-gdm-cgm]] |
| hospital steroid hyperglycemia | [[../concepts/hospital-steroid-hyperglycemia]] |
| glucocorticoid hyperglycemia | [[../concepts/hospital-steroid-hyperglycemia]] |
| steroid hyperglycemia | [[../concepts/hospital-steroid-hyperglycemia]] |
| prednisone NPH insulin | [[../concepts/hospital-steroid-hyperglycemia]] |
| 住院 steroid 高血糖 | [[../concepts/hospital-steroid-hyperglycemia]] |
| 類固醇高血糖 | [[../concepts/hospital-steroid-hyperglycemia]] |

## Diabetes MASLD And MASH

| Alias or phrase | Canonical page |
|---|---|
| MASLD | [[../concepts/diabetes-masld-mash]] |
| MASH | [[../concepts/diabetes-masld-mash]] |
| NAFLD diabetes | [[../concepts/diabetes-masld-mash]] |
| NASH diabetes | [[../concepts/diabetes-masld-mash]] |
| fatty liver diabetes | [[../concepts/diabetes-masld-mash]] |
| diabetes fatty liver | [[../concepts/diabetes-masld-mash]] |
| steatotic liver disease diabetes | [[../concepts/diabetes-masld-mash]] |
| diabetes liver fibrosis | [[../claims/ada-2026-masld-mash-claims]] |
| FIB-4 diabetes | [[../claims/ada-2026-masld-mash-claims]] |
| ELF liver diabetes | [[../claims/ada-2026-masld-mash-claims]] |
| ADA 4.22a | [[../claims/ada-2026-masld-mash-claims]] |
| ADA 4.23 | [[../claims/ada-2026-masld-mash-claims]] |
| ADA 4.24 | [[../claims/ada-2026-masld-mash-claims]] |
| ADA 4.25 | [[../claims/ada-2026-masld-mash-claims]] |
| ADA 4.26 | [[../claims/ada-2026-masld-mash-claims]] |
| ADA 4.27a | [[../claims/ada-2026-masld-mash-claims]] |
| ADA 4.27b | [[../claims/ada-2026-masld-mash-claims]] |
| ADA 4.28 | [[../claims/ada-2026-masld-mash-claims]] |
| diabetes MASH GLP-1 | [[../claims/ada-2026-masld-mash-claims]] |
| diabetes MASH pioglitazone | [[../claims/ada-2026-masld-mash-claims]] |
| semaglutide MASH diabetes | [[../claims/ada-2026-masld-mash-claims]] |
| resmetirom diabetes MASLD | [[../claims/ada-2026-masld-mash-claims]] |
| 糖尿病脂肪肝 | [[../concepts/diabetes-masld-mash]] |
| 糖尿病 MASLD | [[../concepts/diabetes-masld-mash]] |
| 糖尿病 MASH | [[../concepts/diabetes-masld-mash]] |
| 糖尿病脂肪性肝炎 | [[../concepts/diabetes-masld-mash]] |
| 糖尿病肝纖維化 | [[../claims/ada-2026-masld-mash-claims]] |
| 脂肪肝 GLP-1 | [[../claims/ada-2026-masld-mash-claims]] |
| 脂肪肝 pioglitazone | [[../claims/ada-2026-masld-mash-claims]] |
| 糖尿病 MASH 建議等級 | [[../claims/ada-2026-masld-mash-claims]] |
| 糖尿病脂肪肝 建議等級 | [[../claims/ada-2026-masld-mash-claims]] |
| 脂肪肝 GLP-1 證據等級 | [[../claims/ada-2026-masld-mash-claims]] |

## Bone Health And Osteoporosis

| Alias or phrase | Canonical page |
|---|---|
| 糖尿病與骨質疏鬆 | [[../concepts/diabetes-bone-health-osteoporosis]] |
| 骨質疏鬆 claim | [[../claims/ada-2026-bone-health-osteoporosis-claims]] |
| 糖尿病骨鬆 | [[../concepts/diabetes-bone-health-osteoporosis]] |
| 骨質疏鬆治療是否不同 | [[../concepts/diabetes-bone-health-osteoporosis]] |
| 糖尿病骨折風險 | [[../concepts/diabetes-bone-health-osteoporosis]] |
| 糖尿病骨密度 | [[../concepts/diabetes-bone-health-osteoporosis]] |
| osteoporosis in diabetes | [[../concepts/diabetes-bone-health-osteoporosis]] |
| diabetes bone health | [[../concepts/diabetes-bone-health-osteoporosis]] |
| fracture risk in diabetes | [[../concepts/diabetes-bone-health-osteoporosis]] |
| DXA diabetes | [[../concepts/diabetes-bone-health-osteoporosis]] |
| FRAX diabetes | [[../concepts/diabetes-bone-health-osteoporosis]] |
| T-score diabetes | [[../concepts/diabetes-bone-health-osteoporosis]] |

## Muscle Loss And Sarcopenia

| Alias or phrase | Canonical page |
|---|---|
| GLP1 減重 肌肉 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| GLP-1 sarcopenia claim | [[../claims/glp1-weight-loss-muscle-sarcopenia-claims]] |
| GLP-1 減重 肌肉 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| GLP1 肌少症 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| GLP-1 sarcopenia | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| GLP-1 muscle loss | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| SMI 降低 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| skeletal muscle mass index | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| 肌肉質量指數 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| 握力下降 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| 腿沒力 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| 肌少症 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| lean mass loss | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| handgrip weakness | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| chair stand test | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |

## Retinopathy Foot And PAD

| Alias or phrase | Canonical page |
|---|---|
| retinopathy screening | [[../concepts/diabetes-retinopathy-screening]] |
| diabetic retinopathy screening | [[../concepts/diabetes-retinopathy-screening]] |
| diabetes eye exam interval | [[../concepts/diabetes-retinopathy-screening]] |
| AI retinal screening | [[../concepts/diabetes-retinopathy-screening]] |
| 視網膜病變篩檢 | [[../concepts/diabetes-retinopathy-screening]] |
| 糖尿病眼底檢查 | [[../concepts/diabetes-retinopathy-screening]] |
| retinopathy claim | [[../claims/ada-2026-retinopathy-foot-pad-claims]] |
| 視網膜 claim | [[../claims/ada-2026-retinopathy-foot-pad-claims]] |
| retinopathy treatment evidence grade | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| diabetic retinopathy treatment grade | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| severe diabetic retinopathy treatment grade | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| diabetic macular edema evidence grade | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| PDR treatment grade | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| anti-VEGF evidence grade diabetes | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| 嚴重眼病變治療 證據等級 | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| 視網膜病變治療 建議等級 | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| 眼病變治療 證據等級 | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| 糖尿病黃斑水腫 證據等級 | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| diabetic neuropathy treatment grade | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| DPN medication evidence grade | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| neuropathic pain medication grade diabetes | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| 糖尿病神經病變藥物的證據等級 | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| 神經病變藥物 證據等級 | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| 神經痛藥物 建議等級 | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| diabetic foot care | [[../concepts/diabetes-foot-care-pad]] |
| diabetes foot exam | [[../concepts/diabetes-foot-care-pad]] |
| PAD screening diabetes | [[../concepts/diabetes-foot-care-pad]] |
| peripheral artery disease foot risk | [[../concepts/diabetes-foot-care-pad]] |
| 糖尿病足 | [[../concepts/diabetes-foot-care-pad]] |
| 糖尿病周邊動脈疾病 | [[../concepts/diabetes-foot-care-pad]] |
| foot care claim | [[../claims/ada-2026-retinopathy-foot-pad-claims]] |
| PAD claim | [[../claims/ada-2026-retinopathy-foot-pad-claims]] |
| 糖尿病足 claim | [[../claims/ada-2026-retinopathy-foot-pad-claims]] |
| foot PAD recommendation grade | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| 糖尿病足 建議等級 | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |
| PAD 篩檢 證據等級 | [[../evidence-cards/ada-2026-section-12-retinopathy-neuropathy-foot-pad-recommendation-grades]] |

## Maintenance Rule

When a LINE question uses a repeated phrase that is not listed here, add it to
this registry after confirming the canonical page. Do not add patient-specific
phrases or identifiable details.
