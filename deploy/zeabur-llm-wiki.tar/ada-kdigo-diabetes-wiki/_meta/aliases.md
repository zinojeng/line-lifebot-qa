---
title: ADA-KDIGO Wiki Alias Registry
created: 2026-05-20
updated: 2026-05-20
type: meta
tags: [aliases, retrieval, line, diabetes, ckd, hermes]
sources:
  - _meta/topic-map.md
  - _meta/retrieval-policy.md
evidence_level: local-practice
clinical_use: workflow
confidence: high
last_verified: 2026-05-20
status: active
obsidian_type: registry
aliases:
  - alias registry
  - LINE query alias map
  - medical retrieval aliases
entities:
  - Hermes Agent
  - LINE QA
  - ADA
  - KDIGO
owner_agent: hermes
write_policy: hermes-maintained
---

# ADA-KDIGO Wiki Alias Registry

Use this page before full-text search. It maps common user wording, LINE phrasing,
and abbreviation variants to canonical wiki pages.

## Diabetes With CKD

| Alias or phrase | Canonical page |
|---|---|
| CKD | [[../concepts/diabetes-ckd-risk-stratification]] |
| DKD | [[../concepts/diabetes-ckd-risk-stratification]] |
| diabetic kidney disease | [[../concepts/diabetes-ckd-risk-stratification]] |
| 糖尿病腎病變 | [[../concepts/diabetes-ckd-risk-stratification]] |
| eGFR | [[../concepts/diabetes-ckd-risk-stratification]] |
| UACR | [[../concepts/diabetes-ckd-risk-stratification]] |
| albuminuria | [[../concepts/diabetes-ckd-risk-stratification]] |
| 白蛋白尿 | [[../concepts/diabetes-ckd-risk-stratification]] |
| 尿蛋白 | [[../concepts/diabetes-ckd-risk-stratification]] |
| A1C reliability in CKD | [[../concepts/diabetes-ckd-risk-stratification]] |
| 洗腎 A1C 準不準 | [[../concepts/diabetes-ckd-risk-stratification]] |

## SGLT2 Inhibitors

| Alias or phrase | Canonical page |
|---|---|
| SGLT2i | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| SGLT2 inhibitor | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| SGLT-2 inhibitor | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| 排糖藥 | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| eGFR under 20 | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| eGFR 小於 20 | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| 腎功能 20 以下 | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| 洗腎前 SGLT2i | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |
| ADA 2026 11.11a | [[../drugs/sglt2i-egfr-under-20-not-on-dialysis]] |

## GLP-1-Based Therapy

| Alias or phrase | Canonical page |
|---|---|
| GLP-1RA | [[../drugs/glp1-based-therapy-on-dialysis]] |
| GLP-1 receptor agonist | [[../drugs/glp1-based-therapy-on-dialysis]] |
| GLP-1-based therapy | [[../drugs/glp1-based-therapy-on-dialysis]] |
| GLP-1 dialysis | [[../drugs/glp1-based-therapy-on-dialysis]] |
| GLP-1 洗腎 | [[../drugs/glp1-based-therapy-on-dialysis]] |
| GLP-1 透析 | [[../drugs/glp1-based-therapy-on-dialysis]] |
| 洗腎病人 GLP-1 | [[../drugs/glp1-based-therapy-on-dialysis]] |
| transplant listing weight loss | [[../drugs/glp1-based-therapy-on-dialysis]] |
| ADA 2026 11.11b | [[../drugs/glp1-based-therapy-on-dialysis]] |

## Diabetes Technology

| Alias or phrase | Canonical page |
|---|---|
| CGM | [[../concepts/diabetes-technology-cgm-aid]] |
| CGM claim | [[../claims/ada-2026-cgm-diabetes-technology-claims]] |
| continuous glucose monitoring | [[../concepts/diabetes-technology-cgm-aid]] |
| 連續血糖監測 | [[../concepts/diabetes-technology-cgm-aid]] |
| 連續血糖 | [[../concepts/diabetes-technology-cgm-aid]] |
| 糖尿病新科技 | [[../concepts/diabetes-technology-cgm-aid]] |
| 血糖機 | [[../concepts/diabetes-technology-cgm-aid]] |
| AID | [[../concepts/diabetes-technology-cgm-aid]] |
| automated insulin delivery | [[../concepts/diabetes-technology-cgm-aid]] |
| time in range | [[../concepts/diabetes-technology-cgm-aid]] |
| TIR | [[../concepts/diabetes-technology-cgm-aid]] |

## Guideline Hubs

| Alias or phrase | Canonical page |
|---|---|
| ADA 2026 | [[../guidelines/ada-standards-of-care-2026]] |
| ADA Standards 2026 | [[../guidelines/ada-standards-of-care-2026]] |
| ADA S7 | [[../guidelines/ada-standards-of-care-2026]] |
| ADA S9 | [[../guidelines/ada-standards-of-care-2026]] |
| ADA S10 | [[../guidelines/ada-standards-of-care-2026]] |
| ADA S11 | [[../guidelines/ada-standards-of-care-2026]] |
| KDIGO 2026 | [[../guidelines/kdigo-diabetes-management-in-ckd-2026]] |
| KDIGO Diabetes CKD | [[../guidelines/kdigo-diabetes-management-in-ckd-2026]] |
| ADA KDIGO comparison | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| 糖尿病 CKD 指引比較 | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |

## Evidence Strength Follow-Up

| Alias or phrase | Canonical page |
|---|---|
| strong recommendation | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| recommendation strength | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| evidence grade | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| lower certainty evidence | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| claim registry | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| recommendation claim | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| ADA 11.7a | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| ADA 11.7b | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| ADA 11.11a | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| ADA 11.11b | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| KDIGO 4.3.1 | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| KDIGO 4.4.1 | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| KDIGO 4.5.1 | [[../evidence-cards/ada-kdigo-2026-ckd-cardiorenal-recommendation-grades]] |
| 哪些證據等級較低 | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| 哪些是 strong recommendation | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| 建議等級 | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |
| 證據等級 | [[../claims/ada-kdigo-2026-ckd-cardiorenal-claims]] |

## Second-Batch Clinical Terms

| Alias or phrase | Canonical page |
|---|---|
| metformin CKD | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| finerenone | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| nsMRA | [[../comparisons/ada-2026-vs-kdigo-2026-diabetes-ckd]] |
| hypoglycemia advanced CKD | [[../concepts/diabetes-ckd-risk-stratification]] |
| 低血糖 腎功能 | [[../concepts/diabetes-ckd-risk-stratification]] |
| older adults | [[../guidelines/ada-standards-of-care-2026]] |
| 長者糖尿病 | [[../guidelines/ada-standards-of-care-2026]] |
| pregnancy diabetes | [[../guidelines/ada-standards-of-care-2026]] |
| 妊娠糖尿病 | [[../guidelines/ada-standards-of-care-2026]] |
| hospital steroid hyperglycemia | [[../guidelines/ada-standards-of-care-2026]] |
| glucocorticoid hyperglycemia | [[../guidelines/ada-standards-of-care-2026]] |

## Bone Health And Osteoporosis

| Alias or phrase | Canonical page |
|---|---|
| 糖尿病與骨質疏鬆 | [[../concepts/diabetes-bone-health-osteoporosis]] |
| 骨質疏鬆 claim | [[../claims/ada-2026-bone-health-osteoporosis-claims]] |
| 糖尿病骨鬆 | [[../concepts/diabetes-bone-health-osteoporosis]] |
| 骨質疏鬆治療是否不同 | [[../concepts/diabetes-bone-health-osteoporosis]] |
| 糖尿病骨折風險 | [[../concepts/diabetes-bone-health-osteoporosis]] |
| 糖尿病骨密度 | [[../concepts/diabetes-bone-health-osteoporosis]] |
| osteoporosis in diabetes | [[../concepts/diabetes-bone-health-osteoporosis]] |
| diabetes bone health | [[../concepts/diabetes-bone-health-osteoporosis]] |
| fracture risk in diabetes | [[../concepts/diabetes-bone-health-osteoporosis]] |
| DXA diabetes | [[../concepts/diabetes-bone-health-osteoporosis]] |
| FRAX diabetes | [[../concepts/diabetes-bone-health-osteoporosis]] |
| T-score diabetes | [[../concepts/diabetes-bone-health-osteoporosis]] |

## Muscle Loss And Sarcopenia

| Alias or phrase | Canonical page |
|---|---|
| GLP1 減重 肌肉 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| GLP-1 sarcopenia claim | [[../claims/glp1-weight-loss-muscle-sarcopenia-claims]] |
| GLP-1 減重 肌肉 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| GLP1 肌少症 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| GLP-1 sarcopenia | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| GLP-1 muscle loss | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| SMI 降低 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| skeletal muscle mass index | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| 肌肉質量指數 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| 握力下降 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| 腿沒力 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| 肌少症 | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| lean mass loss | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| handgrip weakness | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |
| chair stand test | [[../concepts/glp1-weight-loss-muscle-sarcopenia]] |

## Retinopathy Foot And PAD Pending Claims

| Alias or phrase | Canonical page |
|---|---|
| retinopathy claim | [[../claims/ada-2026-retinopathy-foot-pad-claims]] |
| 視網膜 claim | [[../claims/ada-2026-retinopathy-foot-pad-claims]] |
| foot care claim | [[../claims/ada-2026-retinopathy-foot-pad-claims]] |
| PAD claim | [[../claims/ada-2026-retinopathy-foot-pad-claims]] |
| 糖尿病足 claim | [[../claims/ada-2026-retinopathy-foot-pad-claims]] |

## Maintenance Rule

When a LINE question uses a repeated phrase that is not listed here, add it to
this registry after confirming the canonical page. Do not add patient-specific
phrases or identifiable details.
